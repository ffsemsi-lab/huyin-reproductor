export interface NativeDirectoryItem {
  name: string;
  path: string;
  mediaCount: number;
}

export interface NativeMediaFile {
  name: string;
  path: string;
  size: number;
  lastModified: number;
  kind: 'audio' | 'video';
}

export interface NativeDirListing {
  currentPath: string;
  parentPath: string | null;
  rootPath: string;
  directories: NativeDirectoryItem[];
  files?: NativeMediaFile[];
  mediaCountHere: number;
  shortcuts: Array<{ name: string; path: string }>;
}

interface LocalMediaPluginBridge {
  ensurePermissions(): Promise<{ granted: boolean }>;
  listDirectory(options?: { path?: string }): Promise<NativeDirListing>;
  scanDirectory(options: { path: string; maxFiles?: number }): Promise<{
    files: NativeMediaFile[];
  }>;
  setOrientation?(options: { mode: 'landscape' | 'portrait' | 'unspecified' }): Promise<void>;
  openNativeVideo?(options: { path: string; title?: string }): Promise<void>;
  ensureNotificationPermission?(): Promise<{ granted: boolean }>;
  updateMediaNotification?(options: {
    title: string;
    artist: string;
    album?: string;
    isPlaying: boolean;
    durationSec: number;
    positionSec: number;
    playbackRate?: number;
  }): Promise<void>;
  clearMediaNotification?(): Promise<void>;
  addListener?(
    eventName: 'mediaControlAction',
    listenerFunc: (event: { action: string; positionSec?: number }) => void
  ): Promise<{ remove: () => Promise<void> }> | { remove: () => void };
}

interface CapacitorWindow {
  Capacitor?: {
    isNativePlatform?: () => boolean;
    getPlatform?: () => string;
    convertFileSrc?: (filePath: string) => string;
    Plugins?: {
      LocalMedia?: LocalMediaPluginBridge;
    };
  };
}

function getCap(): CapacitorWindow['Capacitor'] | undefined {
  if (typeof window === 'undefined') return undefined;
  return (window as unknown as CapacitorWindow).Capacitor;
}

export function isCapacitorNative(): boolean {
  const cap = getCap();
  if (!cap) return false;
  if (typeof cap.isNativePlatform === 'function') {
    return Boolean(cap.isNativePlatform());
  }
  return Boolean(cap.Plugins?.LocalMedia);
}

export function isNativeAndroidMediaAvailable(): boolean {
  const cap = getCap();
  return Boolean(cap?.Plugins?.LocalMedia);
}

export function convertNativeFileSrc(filePath: string): string {
  const cap = getCap();
  if (cap && typeof cap.convertFileSrc === 'function') {
    return cap.convertFileSrc(filePath);
  }
  return filePath;
}

export async function ensureNativeMediaPermissions(): Promise<boolean> {
  const plugin = getCap()?.Plugins?.LocalMedia;
  if (!plugin) return false;
  try {
    const res = await plugin.ensurePermissions();
    return Boolean(res?.granted);
  } catch {
    return false;
  }
}

export async function listNativeDirectory(path?: string): Promise<NativeDirListing> {
  const plugin = getCap()?.Plugins?.LocalMedia;
  if (!plugin) {
    throw new Error('LocalMedia plugin not available');
  }
  return await plugin.listDirectory(path ? { path } : {});
}

export async function scanNativeDirectory(
  path: string,
  maxFiles = 500
): Promise<NativeMediaFile[]> {
  const plugin = getCap()?.Plugins?.LocalMedia;
  if (!plugin) return [];
  const res = await plugin.scanDirectory({ path, maxFiles });
  return Array.isArray(res?.files) ? res.files : [];
}

export async function setNativeOrientation(
  mode: 'landscape' | 'portrait' | 'unspecified'
): Promise<void> {
  const plugin = getCap()?.Plugins?.LocalMedia;
  if (plugin?.setOrientation) {
    try {
      await plugin.setOrientation({ mode });
    } catch {
      // Ignorar si no está disponible
    }
    return;
  }
  try {
    const orientation = (screen as unknown as { orientation?: { lock?: (m: string) => Promise<void>; unlock?: () => void } }).orientation;
    if (mode === 'landscape' && orientation?.lock) {
      await orientation.lock('landscape');
    } else if (mode === 'unspecified' && orientation?.unlock) {
      orientation.unlock();
    }
  } catch {
    // Ignorar en navegadores sin bloqueo de orientación
  }
}

export async function openNativeAndroidVideo(path: string, title?: string): Promise<boolean> {
  const plugin = getCap()?.Plugins?.LocalMedia;
  if (!plugin?.openNativeVideo) return false;
  try {
    await plugin.openNativeVideo({ path, title });
    return true;
  } catch {
    return false;
  }
}

export interface NativeMediaNotificationPayload {
  title: string;
  artist: string;
  album?: string;
  isPlaying: boolean;
  durationSec: number;
  positionSec: number;
  playbackRate?: number;
}

export async function ensureNativeNotificationPermission(): Promise<boolean> {
  const plugin = getCap()?.Plugins?.LocalMedia;
  if (!plugin?.ensureNotificationPermission) return false;
  try {
    const res = await plugin.ensureNotificationPermission();
    return Boolean(res?.granted);
  } catch {
    return false;
  }
}

export async function updateNativeMediaNotification(
  payload: NativeMediaNotificationPayload
): Promise<void> {
  const plugin = getCap()?.Plugins?.LocalMedia;
  if (!plugin?.updateMediaNotification) return;
  try {
    await plugin.updateMediaNotification(payload);
  } catch {
    // Ignorar si no está disponible
  }
}

export async function clearNativeMediaNotification(): Promise<void> {
  const plugin = getCap()?.Plugins?.LocalMedia;
  if (!plugin?.clearMediaNotification) return;
  try {
    await plugin.clearMediaNotification();
  } catch {
    // Ignorar si no está disponible
  }
}

export function addNativeMediaControlListener(
  handler: (event: { action: string; positionSec?: number }) => void
): () => void {
  const plugin = getCap()?.Plugins?.LocalMedia;
  if (!plugin?.addListener) return () => {};
  let removed = false;
  let handleRef: { remove: () => void | Promise<void> } | null = null;
  try {
    const maybePromise = plugin.addListener('mediaControlAction', handler);
    if (maybePromise && typeof (maybePromise as Promise<unknown>).then === 'function') {
      void (maybePromise as Promise<{ remove: () => Promise<void> }>).then((handle) => {
        if (removed) {
          void handle.remove();
        } else {
          handleRef = handle;
        }
      });
    } else if (maybePromise && 'remove' in maybePromise) {
      handleRef = maybePromise;
    }
  } catch {
    return () => {};
  }
  return () => {
    removed = true;
    if (handleRef) {
      void handleRef.remove();
    }
  };
}
