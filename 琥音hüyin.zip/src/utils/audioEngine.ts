import { EQ_FREQUENCIES } from '../constants/presets';
import type { EqualizerSettings, HeadphoneModeId } from '../types/media';

function createImpulseResponse(
  ctx: AudioContext,
  durationSec: number,
  decay: number,
  preDelaySec = 0.015
): AudioBuffer {
  const sampleRate = ctx.sampleRate;
  const length = Math.floor(sampleRate * durationSec);
  const impulse = ctx.createBuffer(2, length, sampleRate);
  const preDelaySamples = Math.floor(preDelaySec * sampleRate);

  for (let ch = 0; ch < 2; ch++) {
    const channelData = impulse.getChannelData(ch);
    for (let i = preDelaySamples; i < length; i++) {
      const n = i - preDelaySamples;
      const env = Math.pow(1 - n / (length - preDelaySamples), decay);
      const white = Math.random() * 2 - 1;
      const prev = i > 0 ? channelData[i - 1] : 0;
      channelData[i] = (prev * 0.45 + white * 0.55) * env * 0.45;
    }
  }
  return impulse;
}

class VishaAudioEngine {
  private ctx: AudioContext | null = null;
  private sourceMap = new WeakMap<HTMLMediaElement, MediaElementAudioSourceNode>();
  private inputNode: GainNode | null = null;
  private preampNode: GainNode | null = null;
  private eqFilters: BiquadFilterNode[] = [];
  private bassNode: BiquadFilterNode | null = null;
  private trebleNode: BiquadFilterNode | null = null;
  private hpSubFilter: BiquadFilterNode | null = null;
  private hpMidFilter: BiquadFilterNode | null = null;
  private hpHighFilter: BiquadFilterNode | null = null;
  private compressorNode: DynamicsCompressorNode | null = null;

  private dryGain: GainNode | null = null;
  private crossfeedGain: GainNode | null = null;
  private crossfeedSplitter: ChannelSplitterNode | null = null;
  private crossfeedMerger: ChannelMergerNode | null = null;
  private crossfeedDelayL: DelayNode | null = null;
  private crossfeedDelayR: DelayNode | null = null;
  private crossfeedFilterL: BiquadFilterNode | null = null;
  private crossfeedFilterR: BiquadFilterNode | null = null;
  private convolverNode: ConvolverNode | null = null;
  private wetGain: GainNode | null = null;
  private masterGain: GainNode | null = null;
  private analyser: AnalyserNode | null = null;

  private spatialBuffer: AudioBuffer | null = null;
  private concertBuffer: AudioBuffer | null = null;

  private isCrossfeedConnected = false;
  private isConvolverConnected = false;
  private isProcessingChainConnected = false;

  private lastEqSettings: EqualizerSettings | null = null;
  private lastHeadphoneMode: HeadphoneModeId = 'estandar';

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;

    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;

      // latencyHint: 'playback' asigna un búfer amplio en móvil para evitar micro-cortes
      const ctx = new AudioCtx({ latencyHint: 'playback' });
      this.ctx = ctx;

      this.inputNode = ctx.createGain();
      this.preampNode = ctx.createGain();

      this.eqFilters = EQ_FREQUENCIES.map((freq, idx) => {
        const filter = ctx.createBiquadFilter();
        filter.type =
          idx === 0 ? 'lowshelf' : idx === EQ_FREQUENCIES.length - 1 ? 'highshelf' : 'peaking';
        filter.frequency.value = freq;
        filter.Q.value = idx === 0 || idx === EQ_FREQUENCIES.length - 1 ? 0.707 : 1.4;
        filter.gain.value = 0;
        return filter;
      });

      this.bassNode = ctx.createBiquadFilter();
      this.bassNode.type = 'lowshelf';
      this.bassNode.frequency.value = 85;
      this.bassNode.gain.value = 0;

      this.trebleNode = ctx.createBiquadFilter();
      this.trebleNode.type = 'highshelf';
      this.trebleNode.frequency.value = 6500;
      this.trebleNode.gain.value = 0;

      this.hpSubFilter = ctx.createBiquadFilter();
      this.hpSubFilter.type = 'lowshelf';
      this.hpSubFilter.frequency.value = 60;
      this.hpSubFilter.gain.value = 0;

      this.hpMidFilter = ctx.createBiquadFilter();
      this.hpMidFilter.type = 'peaking';
      this.hpMidFilter.frequency.value = 260;
      this.hpMidFilter.Q.value = 1.1;
      this.hpMidFilter.gain.value = 0;

      this.hpHighFilter = ctx.createBiquadFilter();
      this.hpHighFilter.type = 'peaking';
      this.hpHighFilter.frequency.value = 3400;
      this.hpHighFilter.Q.value = 1.2;
      this.hpHighFilter.gain.value = 0;

      this.compressorNode = ctx.createDynamicsCompressor();
      this.compressorNode.threshold.value = -2;
      this.compressorNode.knee.value = 12;
      this.compressorNode.ratio.value = 1;
      this.compressorNode.attack.value = 0.005;
      this.compressorNode.release.value = 0.2;

      this.dryGain = ctx.createGain();
      this.dryGain.gain.value = 1;

      this.crossfeedSplitter = ctx.createChannelSplitter(2);
      this.crossfeedMerger = ctx.createChannelMerger(2);
      this.crossfeedDelayL = ctx.createDelay(0.05);
      this.crossfeedDelayR = ctx.createDelay(0.05);
      this.crossfeedDelayL.delayTime.value = 0.00032;
      this.crossfeedDelayR.delayTime.value = 0.00032;

      this.crossfeedFilterL = ctx.createBiquadFilter();
      this.crossfeedFilterL.type = 'lowpass';
      this.crossfeedFilterL.frequency.value = 1400;

      this.crossfeedFilterR = ctx.createBiquadFilter();
      this.crossfeedFilterR.type = 'lowpass';
      this.crossfeedFilterR.frequency.value = 1400;

      this.crossfeedGain = ctx.createGain();
      this.crossfeedGain.gain.value = 0;

      this.convolverNode = ctx.createConvolver();
      this.wetGain = ctx.createGain();
      this.wetGain.gain.value = 0;

      this.masterGain = ctx.createGain();
      this.masterGain.gain.value = 1;

      this.analyser = ctx.createAnalyser();
      this.analyser.fftSize = 128;
      this.analyser.smoothingTimeConstant = 0.85;

      // Cableado interno fijo de la cadena EQ (se conecta bajo demanda para ahorrar CPU)
      let cursor: AudioNode = this.preampNode;
      for (const band of this.eqFilters) {
        cursor.connect(band);
        cursor = band;
      }
      cursor.connect(this.bassNode);
      this.bassNode.connect(this.trebleNode);
      this.trebleNode.connect(this.hpSubFilter);
      this.hpSubFilter.connect(this.hpMidFilter);
      this.hpMidFilter.connect(this.hpHighFilter);
      this.hpHighFilter.connect(this.compressorNode);
      this.compressorNode.connect(this.dryGain);
      this.dryGain.connect(this.masterGain);

      // Cableado interno Crossfeed
      this.crossfeedSplitter.connect(this.crossfeedDelayL, 0);
      this.crossfeedDelayL.connect(this.crossfeedFilterL);
      this.crossfeedFilterL.connect(this.crossfeedMerger, 0, 1);

      this.crossfeedSplitter.connect(this.crossfeedDelayR, 1);
      this.crossfeedDelayR.connect(this.crossfeedFilterR);
      this.crossfeedFilterR.connect(this.crossfeedMerger, 0, 0);

      this.crossfeedMerger.connect(this.crossfeedGain);
      this.crossfeedGain.connect(this.masterGain);

      // Cableado interno Convolución
      this.convolverNode.connect(this.wetGain);
      this.wetGain.connect(this.masterGain);

      // Salida estándar limpia (100%) + Analizador
      this.masterGain.connect(this.analyser);
      this.analyser.connect(ctx.destination);

      this.rebuildRouting();

      if (this.lastEqSettings) {
        this.applyEqualizer(this.lastEqSettings);
      }
      this.applyHeadphoneMode(this.lastHeadphoneMode);
    }

    return this.ctx;
  }

  public needsDspProcessing(): boolean {
    if (this.lastHeadphoneMode !== 'estandar') return true;
    const eq = this.lastEqSettings;
    if (!eq || !eq.enabled) return false;
    if (eq.preampDb !== 0 || eq.bassBoostDb !== 0 || eq.trebleClarityDb !== 0 || eq.compressorEnabled) {
      return true;
    }
    return eq.bands.some((g) => g !== 0);
  }

  public hasConnectedElement(element: HTMLMediaElement | null): boolean {
    return Boolean(element && this.sourceMap.has(element));
  }

  private rebuildRouting(): void {
    if (!this.ctx || !this.inputNode || !this.preampNode || !this.masterGain || !this.compressorNode) {
      return;
    }

    const useDsp = this.needsDspProcessing();

    if (useDsp && !this.isProcessingChainConnected) {
      try {
        this.inputNode.disconnect();
      } catch {
        // Ignorar
      }
      this.inputNode.connect(this.preampNode);
      this.isProcessingChainConnected = true;
    } else if (!useDsp && this.isProcessingChainConnected) {
      try {
        this.inputNode.disconnect();
      } catch {
        // Ignorar
      }
      this.inputNode.connect(this.masterGain);
      this.isProcessingChainConnected = false;
    } else if (!useDsp && !this.isProcessingChainConnected) {
      try {
        this.inputNode.disconnect();
      } catch {
        // Ignorar
      }
      this.inputNode.connect(this.masterGain);
    }

    const needsCrossfeed =
      useDsp && (this.lastHeadphoneMode === 'estudio' || this.lastHeadphoneMode === 'espacial');
    if (needsCrossfeed && !this.isCrossfeedConnected && this.crossfeedSplitter) {
      this.compressorNode.connect(this.crossfeedSplitter);
      this.isCrossfeedConnected = true;
    } else if (!needsCrossfeed && this.isCrossfeedConnected && this.crossfeedSplitter) {
      try {
        this.compressorNode.disconnect(this.crossfeedSplitter);
      } catch {
        // Ignorar
      }
      this.isCrossfeedConnected = false;
    }

    const needsConvolver =
      useDsp && (this.lastHeadphoneMode === 'espacial' || this.lastHeadphoneMode === 'concierto');
    if (needsConvolver && !this.isConvolverConnected && this.convolverNode) {
      if (this.lastHeadphoneMode === 'espacial') {
        if (!this.spatialBuffer) {
          this.spatialBuffer = createImpulseResponse(this.ctx, 0.35, 3.8, 0.008);
        }
        this.convolverNode.buffer = this.spatialBuffer;
      } else {
        if (!this.concertBuffer) {
          this.concertBuffer = createImpulseResponse(this.ctx, 1.4, 2.7, 0.024);
        }
        this.convolverNode.buffer = this.concertBuffer;
      }
      this.compressorNode.connect(this.convolverNode);
      this.isConvolverConnected = true;
    } else if (!needsConvolver && this.isConvolverConnected && this.convolverNode) {
      try {
        this.compressorNode.disconnect(this.convolverNode);
      } catch {
        // Ignorar
      }
      this.isConvolverConnected = false;
    }
  }

  public connectMediaElement(element: HTMLMediaElement): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.inputNode) return;

    if (ctx.state !== 'running' && ctx.state !== 'closed') {
      void ctx.resume().catch(() => {});
    }

    if (!this.sourceMap.has(element)) {
      try {
        const source = ctx.createMediaElementSource(element);
        source.connect(this.inputNode);
        this.sourceMap.set(element, source);
      } catch {
        // Ignorar si ya fue conectado previamente
      }
    }
  }

  public resume(): void {
    if (this.ctx && this.ctx.state !== 'running' && this.ctx.state !== 'closed') {
      void this.ctx.resume().catch(() => {});
    }
  }

  public suspendIdle(): void {
    if (this.ctx && this.ctx.state === 'running') {
      void this.ctx.suspend().catch(() => {});
    }
  }

  private setParam(param: AudioParam, value: number, timeConstant: number): void {
    if (!this.ctx) return;
    if (this.ctx.state === 'running') {
      param.setTargetAtTime(value, this.ctx.currentTime, timeConstant);
    } else {
      param.value = value;
    }
  }

  public applyEqualizer(eq: EqualizerSettings): void {
    this.lastEqSettings = eq;
    const ctx = this.ctx;
    if (!ctx || !this.preampNode || !this.bassNode || !this.trebleNode) return;

    this.rebuildRouting();

    const preampLinear = eq.enabled ? Math.pow(10, eq.preampDb / 20) : 1;
    this.setParam(this.preampNode.gain, preampLinear, 0.02);

    this.eqFilters.forEach((filter, idx) => {
      const targetGain = eq.enabled ? eq.bands[idx] ?? 0 : 0;
      this.setParam(filter.gain, targetGain, 0.02);
    });

    this.setParam(this.bassNode.gain, eq.enabled ? eq.bassBoostDb : 0, 0.02);
    this.setParam(this.trebleNode.gain, eq.enabled ? eq.trebleClarityDb : 0, 0.02);

    this.syncCompressorAndHeadphone(eq, this.lastHeadphoneMode);
  }

  public applyHeadphoneMode(mode: HeadphoneModeId): void {
    this.lastHeadphoneMode = mode;
    const ctx = this.ctx;
    if (
      !ctx ||
      !this.dryGain ||
      !this.crossfeedGain ||
      !this.wetGain ||
      !this.hpSubFilter ||
      !this.hpMidFilter ||
      !this.hpHighFilter ||
      !this.masterGain
    ) {
      return;
    }

    this.rebuildRouting();

    let dry = 1;
    let crossfeed = 0;
    let wet = 0;
    let subGain = 0;
    let midGain = 0;
    let highGain = 0;
    let master = 1;

    switch (mode) {
      case 'estandar':
        break;
      case 'estudio':
        dry = 0.86;
        crossfeed = 0.28;
        master = 1;
        break;
      case 'espacial':
        dry = 0.88;
        crossfeed = 0.1;
        wet = 0.24;
        highGain = 1.2;
        break;
      case 'iem':
        subGain = 3.2;
        midGain = -2.2;
        highGain = 2.6;
        master = 0.96;
        break;
      case 'nocturno':
        subGain = -2.5;
        highGain = 1.5;
        master = 1.04;
        break;
      case 'concierto':
        dry = 0.82;
        wet = 0.34;
        subGain = 1.4;
        break;
    }

    this.setParam(this.dryGain.gain, dry, 0.03);
    this.setParam(this.crossfeedGain.gain, crossfeed, 0.03);
    this.setParam(this.wetGain.gain, wet, 0.03);
    this.setParam(this.hpSubFilter.gain, subGain, 0.03);
    this.setParam(this.hpMidFilter.gain, midGain, 0.03);
    this.setParam(this.hpHighFilter.gain, highGain, 0.03);
    this.setParam(this.masterGain.gain, master, 0.03);

    if (this.lastEqSettings) {
      this.syncCompressorAndHeadphone(this.lastEqSettings, mode);
    }
  }

  private syncCompressorAndHeadphone(eq: EqualizerSettings, mode: HeadphoneModeId): void {
    if (!this.ctx || !this.compressorNode) return;
    const isNight = mode === 'nocturno';

    if (isNight) {
      this.setParam(this.compressorNode.threshold, -24, 0.03);
      this.setParam(this.compressorNode.knee, 18, 0.03);
      this.setParam(this.compressorNode.ratio, 6, 0.03);
    } else if (eq.enabled && eq.compressorEnabled) {
      this.setParam(this.compressorNode.threshold, -16, 0.03);
      this.setParam(this.compressorNode.knee, 14, 0.03);
      this.setParam(this.compressorNode.ratio, 3.2, 0.03);
    } else {
      this.setParam(this.compressorNode.threshold, -1, 0.03);
      this.setParam(this.compressorNode.knee, 0, 0.03);
      this.setParam(this.compressorNode.ratio, 1, 0.03);
    }
  }

  public getFrequencyData(targetArray: Uint8Array<ArrayBuffer>): boolean {
    if (!this.analyser) return false;
    this.analyser.getByteFrequencyData(targetArray);
    return true;
  }

  public getBinCount(): number {
    return this.analyser ? this.analyser.frequencyBinCount : 64;
  }
}

export const audioEngine = new VishaAudioEngine();
