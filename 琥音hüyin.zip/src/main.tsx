import {Component, type ErrorInfo, type ReactNode} from 'react';
import {createRoot} from 'react-dom/client';
import {registerSW} from 'virtual:pwa-register';
import App from './App.tsx';
import './index.css';
import {isCapacitorNative} from './utils/nativeAndroidMedia';

if (isCapacitorNative()) {
  if ('serviceWorker' in navigator) {
    void navigator.serviceWorker.getRegistrations().then((regs) => {
      regs.forEach((r) => void r.unregister());
    });
  }
  if ('caches' in window) {
    void caches.keys().then((keys) => Promise.all(keys.map((k) => caches.delete(k))));
  }
} else {
  registerSW({immediate: true});
}

interface ErrorBoundaryState {
  hasError: boolean;
}

class AppErrorBoundary extends Component<{children: ReactNode}, ErrorBoundaryState> {
  state: ErrorBoundaryState = {hasError: false};

  static getDerivedStateFromError(): ErrorBoundaryState {
    return {hasError: true};
  }

  componentDidCatch(_error: Error, _info: ErrorInfo) {
    // Limpiar cachés viejas si hubo un fallo de carga de módulo
    if ('caches' in window) {
      void caches.keys().then((keys) => Promise.all(keys.map((k) => caches.delete(k))));
    }
  }

  render() {
    if (this.state.hasError) {
      return (
        <div
          style={{
            minHeight: '100vh',
            display: 'grid',
            placeItems: 'center',
            background: '#0b0d12',
            color: '#f3f4f6',
            fontFamily: 'system-ui, sans-serif',
            padding: '24px',
            textAlign: 'center',
          }}
        >
          <div style={{maxWidth: '360px'}}>
            <h1 style={{fontSize: '18px', fontWeight: 700, marginBottom: '8px'}}>琥音Hǔyīn</h1>
            <p style={{fontSize: '14px', color: '#9ca3af', marginBottom: '16px'}}>
              Ocurrió un problema al cargar la pantalla. Pulsa el botón para reiniciar la caché local.
            </p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              style={{
                background: '#f59e0b',
                color: '#0b0d12',
                border: 'none',
                borderRadius: '12px',
                padding: '10px 18px',
                fontSize: '14px',
                fontWeight: 600,
                cursor: 'pointer',
              }}
            >
              Recargar reproductor
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

const bootWindow = window as unknown as {
  __HUYIN_MOUNTED__?: boolean;
  __HUYIN_CLEAR_WATCHDOG__?: () => void;
};
bootWindow.__HUYIN_MOUNTED__ = true;
bootWindow.__HUYIN_CLEAR_WATCHDOG__?.();

createRoot(document.getElementById('root')!).render(
  <AppErrorBoundary>
    <App />
  </AppErrorBoundary>
);
