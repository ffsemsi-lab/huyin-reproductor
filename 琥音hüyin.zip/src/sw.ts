import { CacheableResponsePlugin } from 'workbox-cacheable-response';
import { ExpirationPlugin } from 'workbox-expiration';
import { cleanupOutdatedCaches, precacheAndRoute } from 'workbox-precaching';
import { registerRoute } from 'workbox-routing';
import { CacheFirst } from 'workbox-strategies';

interface SwExtendableEvent extends Event {
  waitUntil(promise: Promise<unknown>): void;
}

interface SwFetchEvent extends SwExtendableEvent {
  request: Request;
  respondWith(response: Response | Promise<Response>): void;
}

interface SwClients {
  claim(): Promise<void>;
}

interface SwGlobal {
  __WB_MANIFEST: Array<string | { url: string; revision: string | null }>;
  skipWaiting(): Promise<void>;
  clients: SwClients;
  location: Location;
  navigator: Navigator;
  addEventListener(type: 'install' | 'activate', listener: (e: SwExtendableEvent) => void): void;
  addEventListener(type: 'fetch', listener: (e: SwFetchEvent) => void): void;
}

const sw = self as unknown as SwGlobal;

const PAGE_CACHE = 'huyin-pages-v5';
const ASSET_CACHE = 'huyin-assets-v5';
const IMAGE_CACHE = 'huyin-images-v5';

function isLocalMediaOrCapacitorFile(url: URL, request: Request): boolean {
  if (url.pathname.startsWith('/_capacitor_file_') || url.pathname.startsWith('/_capacitor_content_')) {
    return true;
  }
  if (request.destination === 'audio' || request.destination === 'video') {
    return true;
  }
  return /\.(mp3|wav|flac|ogg|oga|opus|m4a|aac|wma|aiff|alac|weba|mp4|webm|mkv|mov|avi|m4v|ogv|3gp|ts|flv|wmv)$/i.test(
    url.pathname
  );
}

const STATIC_IMAGE_URLS = [
  '/huyin-icon.png',
  '/pwa-192x192.png',
  '/pwa-512x512.png',
  '/apple-touch-icon.png',
  '/src/assets/images/music_bg_studio_1795535300187.jpg',
  '/src/assets/images/music_bg_waves_1795535300544.jpg',
  '/src/assets/images/music_bg_vinyl_1795535301829.jpg',
];

cleanupOutdatedCaches();
precacheAndRoute((self as unknown as SwGlobal).__WB_MANIFEST || []);

sw.addEventListener('install', (event) => {
  void sw.skipWaiting();
  event.waitUntil(
    (async () => {
      try {
        const pageCache = await caches.open(PAGE_CACHE);
        const homeRes = await fetch('/');
        if (homeRes.ok && homeRes.status === 200) {
          await pageCache.put('/', homeRes);
        }
      } catch {
        // Ignorar si falla sin conexión
      }

      const imgCache = await caches.open(IMAGE_CACHE);
      await Promise.allSettled(
        STATIC_IMAGE_URLS.map(async (url) => {
          try {
            const res = await fetch(url);
            if (res.ok && res.status === 200) {
              await imgCache.put(url, res);
            }
          } catch {
            // Ignorar si falla sin conexión
          }
        })
      );
    })()
  );
});

sw.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      // Eliminar cachés antiguos v1/v2 para curar cualquier estado roto previo
      const keys = await caches.keys();
      await Promise.all(
        keys.map((key) => {
          if (
            key.startsWith('huyin-') &&
            key !== PAGE_CACHE &&
            key !== ASSET_CACHE &&
            key !== IMAGE_CACHE &&
            key !== 'huyin-fonts-v1'
          ) {
            return caches.delete(key);
          }
          return Promise.resolve(false);
        })
      );
      await sw.clients.claim();
    })()
  );
});

async function networkFirstWithTimeout(
  request: Request,
  cacheName: string,
  cacheKey: Request | string,
  timeoutMs: number
): Promise<Response | undefined> {
  const cache = await caches.open(cacheName);

  // Si ya sabemos que no hay conexión, devolver caché de inmediato
  if (typeof sw.navigator !== 'undefined' && sw.navigator.onLine === false) {
    const offlineHit = await cache.match(cacheKey);
    if (offlineHit) return offlineHit;
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const netRes = await fetch(request, { signal: controller.signal });
    clearTimeout(timer);
    if (netRes && netRes.ok && netRes.status === 200) {
      await cache.put(cacheKey, netRes.clone());
    }
    return netRes;
  } catch {
    clearTimeout(timer);
    return (await cache.match(cacheKey)) || (await caches.match(cacheKey));
  }
}

// 1. Navegación HTML: NetworkFirst para no servir HTML obsoleto online, con respaldo inmediato offline
registerRoute(
  ({ request }) => request.mode === 'navigate',
  async ({ request }) => {
    const res = await networkFirstWithTimeout(request, PAGE_CACHE, '/', 6000);
    if (res) return res;
    return new Response(
      '<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>琥音Hǔyīn</title><body style="background:#0b0d12;color:#f3f4f6;font-family:sans-serif;display:grid;place-items:center;min-height:100vh;margin:0;padding:24px;text-align:center"><p>Abre 琥音Hǔyīn una vez con internet para guardar la aplicación en este dispositivo.</p></body></html>',
      { headers: { 'Content-Type': 'text/html; charset=utf-8' } }
    );
  }
);

// 2. Imágenes estáticas e iconos: CacheFirst para carga instantánea sin internet
registerRoute(
  ({ url, request }) => {
    if (isLocalMediaOrCapacitorFile(url, request)) return false;
    return (
      url.origin === sw.location.origin &&
      (request.destination === 'image' || /\.(png|jpg|jpeg|webp|svg|ico)$/i.test(url.pathname))
    );
  },
  new CacheFirst({
    cacheName: IMAGE_CACHE,
    plugins: [
      new CacheableResponsePlugin({ statuses: [0, 200] }),
      new ExpirationPlugin({ maxEntries: 60, maxAgeSeconds: 60 * 60 * 24 * 90 }),
    ],
  })
);

// 3. Módulos JS/TS/CSS/Manifest del mismo origen: NetworkFirst (evita desajuste de hashes Vite en blanco) con respaldo offline
registerRoute(
  ({ url, request }) => {
    if (url.origin !== sw.location.origin) return false;
    if (request.mode === 'navigate') return false;
    if (isLocalMediaOrCapacitorFile(url, request)) return false;
    if (url.pathname.endsWith('sw.js') || url.pathname.includes('dev-sw.js')) return false;
    if (url.pathname.includes('vite-plugin-pwa')) return false;
    return true;
  },
  async ({ request }) => {
    const res = await networkFirstWithTimeout(request, ASSET_CACHE, request, 6000);
    if (res) return res;
    return Response.error();
  }
);

// 4. Fuentes de Google: CacheFirst
registerRoute(
  ({ url }) =>
    url.origin === 'https://fonts.googleapis.com' ||
    url.origin === 'https://fonts.gstatic.com',
  new CacheFirst({
    cacheName: 'huyin-fonts-v1',
    plugins: [
      new CacheableResponsePlugin({ statuses: [0, 200] }),
      new ExpirationPlugin({ maxEntries: 20, maxAgeSeconds: 60 * 60 * 24 * 365 }),
    ],
  })
);
