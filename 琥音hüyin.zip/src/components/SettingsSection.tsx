import {
  Check,
  FolderOpen,
  HardDrive,
  Headphones,
  Image as ImageIcon,
  Palette,
  RefreshCw,
  RotateCcw,
  ShieldCheck,
  SlidersHorizontal,
  Trash2,
} from 'lucide-react';
import { useMemo, useState } from 'react';
import {
  BUILT_IN_BACKDROPS,
  EQ_BAND_LABELS,
  EQ_PRESETS,
  HEADPHONE_MODES,
  PLAYER_THEMES,
} from '../constants/presets';
import type {
  AppSettings,
  BackdropId,
  EqualizerPresetId,
  HeadphoneModeId,
  ThemeId,
} from '../types/media';
import {
  formatBytes,
  type SavedDirectoryEntry,
  type StoragePermissionStatus,
} from '../utils/libraryDb';
import { audioEngine } from '../utils/audioEngine';
import { isCapacitorNative } from '../utils/nativeAndroidMedia';
import { InstallAppCard } from './InstallAppCard';

interface SettingsSectionProps {
  settings: AppSettings;
  musicCount: number;
  videoCount: number;
  totalBytes: number;
  internalBlobBytes: number;
  storageStatus: StoragePermissionStatus;
  savedFolders: SavedDirectoryEntry[];
  isScanningFolders: boolean;
  onRequestStoragePermission: () => void;
  onRescanFolders: () => void;
  onRemoveFolder: (id: string) => void;
  onUpdateSettings: (next: AppSettings) => void;
  onClearLibrary: () => void;
}

export function SettingsSection({
  settings,
  musicCount,
  videoCount,
  totalBytes,
  internalBlobBytes,
  storageStatus,
  savedFolders,
  isScanningFolders,
  onRequestStoragePermission,
  onRescanFolders,
  onRemoveFolder,
  onUpdateSettings,
  onClearLibrary,
}: SettingsSectionProps) {
  const [confirmClear, setConfirmClear] = useState(false);

  const eq = settings.equalizer;

  const handleSelectPreset = (presetId: EqualizerPresetId) => {
    audioEngine.resume();
    const found = EQ_PRESETS.find((p) => p.id === presetId);
    onUpdateSettings({
      ...settings,
      equalizer: {
        ...eq,
        enabled: true,
        presetId,
        bands: found ? [...found.bands] : [...eq.bands],
      },
    });
  };

  const handleBandChange = (index: number, value: number) => {
    audioEngine.resume();
    const nextBands = [...eq.bands];
    nextBands[index] = value;
    onUpdateSettings({
      ...settings,
      equalizer: {
        ...eq,
        enabled: true,
        presetId: 'personalizado',
        bands: nextBands,
      },
    });
  };

  const handleResetEq = () => {
    audioEngine.resume();
    onUpdateSettings({
      ...settings,
      equalizer: {
        enabled: true,
        presetId: 'plano',
        preampDb: 0,
        bands: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        bassBoostDb: 0,
        trebleClarityDb: 0,
        compressorEnabled: false,
      },
    });
  };

  const handleSelectHeadphone = (mode: HeadphoneModeId) => {
    audioEngine.resume();
    onUpdateSettings({ ...settings, headphoneMode: mode });
  };

  const handleSelectTheme = (theme: ThemeId) => {
    onUpdateSettings({ ...settings, theme });
  };

  const handleSelectBackdrop = (backdrop: BackdropId) => {
    onUpdateSettings({ ...settings, backdrop });
  };

  // Curva SVG suave que visualiza los 10 puntos del ecualizador
  const eqCurvePath = useMemo(() => {
    const width = 600;
    const height = 100;
    const paddingX = 24;
    const stepX = (width - paddingX * 2) / (eq.bands.length - 1);
    const points = eq.bands.map((db, idx) => {
      const x = paddingX + idx * stepX;
      const clamped = Math.max(-12, Math.min(12, eq.enabled ? db : 0));
      const y = height / 2 - (clamped / 12) * (height / 2 - 12);
      return { x, y };
    });

    if (points.length === 0) return '';
    let d = `M ${points[0].x} ${points[0].y}`;
    for (let i = 0; i < points.length - 1; i++) {
      const curr = points[i];
      const next = points[i + 1];
      const midX = (curr.x + next.x) / 2;
      d += ` C ${midX} ${curr.y}, ${midX} ${next.y}, ${next.x} ${next.y}`;
    }
    return d;
  }, [eq.bands, eq.enabled]);

  return (
    <section className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8 space-y-10">
      {/* Encabezado */}
      <div className="pb-6 border-b" style={{ borderColor: 'var(--border-subtle)' }}>
        <h1
          className="font-display text-2xl sm:text-3xl font-bold tracking-tight"
          style={{ color: 'var(--text-primary)' }}
        >
          Ajustes de audio y apariencia
        </h1>
        <p className="mt-1 text-sm" style={{ color: 'var(--text-secondary)' }}>
          Configura el ecualizador de 10 bandas, los modos profesionales de auriculares y el tema visual del reproductor.
        </p>
      </div>

      {/* 1. Ecualizador Avanzado */}
      <div
        className="rounded-2xl border p-5 sm:p-6"
        style={{
          backgroundColor: 'var(--bg-surface)',
          borderColor: 'var(--border-subtle)',
        }}
      >
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <div
              className="flex h-10 w-10 items-center justify-center rounded-xl"
              style={{ backgroundColor: 'var(--accent-soft)', color: 'var(--accent)' }}
            >
              <SlidersHorizontal className="h-5 w-5" aria-hidden="true" />
            </div>
            <div>
              <h2 className="font-display text-lg font-bold" style={{ color: 'var(--text-primary)' }}>
                Ecualizador avanzado de 10 bandas
              </h2>
              <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                Procesamiento en tiempo real para música y video
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => {
                audioEngine.resume();
                onUpdateSettings({
                  ...settings,
                  equalizer: { ...eq, enabled: !eq.enabled },
                });
              }}
              className="min-h-[40px] rounded-xl px-4 py-2 text-xs font-semibold transition-colors cursor-pointer"
              style={{
                backgroundColor: eq.enabled ? 'var(--accent)' : 'var(--bg-elevated)',
                color: eq.enabled ? 'var(--accent-contrast)' : 'var(--text-secondary)',
              }}
            >
              {eq.enabled ? 'Ecualizador activo' : 'Ecualizador apagado'}
            </button>

            <button
              type="button"
              onClick={handleResetEq}
              className="flex min-h-[40px] items-center gap-1.5 rounded-xl border px-3.5 py-2 text-xs font-medium cursor-pointer"
              style={{
                borderColor: 'var(--border-subtle)',
                color: 'var(--text-secondary)',
              }}
            >
              <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Restablecer</span>
            </button>
          </div>
        </div>

        {/* Selector de perfiles del ecualizador */}
        <div className="mt-5 flex flex-wrap gap-2">
          {EQ_PRESETS.map((preset) => {
            const active = eq.presetId === preset.id;
            return (
              <button
                key={preset.id}
                type="button"
                onClick={() => handleSelectPreset(preset.id)}
                className="min-h-[38px] rounded-xl border px-3.5 py-1.5 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap"
                style={{
                  borderColor: active ? 'var(--accent)' : 'var(--border-subtle)',
                  backgroundColor: active ? 'var(--accent-soft)' : 'var(--bg-elevated)',
                  color: active ? 'var(--accent)' : 'var(--text-primary)',
                }}
              >
                {preset.name}
              </button>
            );
          })}
        </div>

        {/* Curva de respuesta de frecuencia SVG */}
        <div
          className="mt-5 overflow-hidden rounded-xl border px-2 py-2"
          style={{
            backgroundColor: 'var(--bg-canvas)',
            borderColor: 'var(--border-subtle)',
          }}
        >
          <svg
            viewBox="0 0 600 100"
            className="h-24 w-full"
            preserveAspectRatio="none"
            aria-hidden="true"
          >
            <line
              x1="0"
              y1="50"
              x2="600"
              y2="50"
              stroke="currentColor"
              strokeOpacity="0.14"
              strokeDasharray="4 4"
            />
            <path
              d={eqCurvePath}
              fill="none"
              stroke="var(--accent)"
              strokeWidth="2.5"
              strokeLinecap="round"
            />
          </svg>
        </div>

        {/* Banco de 10 faders verticales */}
        <div className="mt-5 overflow-x-auto pb-2">
          <div className="grid min-w-[540px] grid-cols-10 gap-2">
            {EQ_BAND_LABELS.map((label, idx) => {
              const val = eq.bands[idx] ?? 0;
              return (
                <div key={label} className="flex flex-col items-center gap-2">
                  <span
                    className="font-mono-tabular text-[11px] font-medium"
                    style={{ color: val !== 0 && eq.enabled ? 'var(--accent)' : 'var(--text-secondary)' }}
                  >
                    {val > 0 ? `+${val}` : val} dB
                  </span>
                  <div className="flex h-36 items-center justify-center">
                    <input
                      type="range"
                      min={-12}
                      max={12}
                      step={1}
                      value={val}
                      onChange={(e) => handleBandChange(idx, Number(e.target.value))}
                      aria-label={`Banda ${label}`}
                      className="eq-slider h-32 w-6"
                    />
                  </div>
                  <span
                    className="font-mono-tabular text-[11px]"
                    style={{ color: 'var(--text-secondary)' }}
                  >
                    {label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Controles adicionales DSP: Preamplificador, Graves, Claridad, Compresor */}
        <div
          className="mt-6 grid grid-cols-1 gap-5 pt-5 border-t sm:grid-cols-2 lg:grid-cols-4"
          style={{ borderColor: 'var(--border-subtle)' }}
        >
          <div>
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="font-medium" style={{ color: 'var(--text-primary)' }}>
                Preamplificador
              </span>
              <span className="font-mono-tabular" style={{ color: 'var(--accent)' }}>
                {eq.preampDb > 0 ? `+${eq.preampDb}` : eq.preampDb} dB
              </span>
            </div>
            <input
              type="range"
              min={-6}
              max={6}
              step={0.5}
              value={eq.preampDb}
              onChange={(e) =>
                onUpdateSettings({
                  ...settings,
                  equalizer: { ...eq, preampDb: Number(e.target.value) },
                })
              }
              aria-label="Preamplificador"
              className="visha-range w-full"
            />
          </div>

          <div>
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="font-medium" style={{ color: 'var(--text-primary)' }}>
                Refuerzo de graves
              </span>
              <span className="font-mono-tabular" style={{ color: 'var(--accent)' }}>
                +{eq.bassBoostDb} dB
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={10}
              step={1}
              value={eq.bassBoostDb}
              onChange={(e) =>
                onUpdateSettings({
                  ...settings,
                  equalizer: { ...eq, bassBoostDb: Number(e.target.value) },
                })
              }
              aria-label="Refuerzo de graves"
              className="visha-range w-full"
            />
          </div>

          <div>
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="font-medium" style={{ color: 'var(--text-primary)' }}>
                Claridad de agudos
              </span>
              <span className="font-mono-tabular" style={{ color: 'var(--accent)' }}>
                +{eq.trebleClarityDb} dB
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={10}
              step={1}
              value={eq.trebleClarityDb}
              onChange={(e) =>
                onUpdateSettings({
                  ...settings,
                  equalizer: { ...eq, trebleClarityDb: Number(e.target.value) },
                })
              }
              aria-label="Claridad de agudos"
              className="visha-range w-full"
            />
          </div>

          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-xs font-medium" style={{ color: 'var(--text-primary)' }}>
                Normalizador dinámico
              </p>
              <p className="text-[11px]" style={{ color: 'var(--text-secondary)' }}>
                Equilibra picos de volumen
              </p>
            </div>
            <button
              type="button"
              onClick={() =>
                onUpdateSettings({
                  ...settings,
                  equalizer: { ...eq, compressorEnabled: !eq.compressorEnabled },
                })
              }
              className="min-h-[38px] rounded-xl px-3.5 py-1.5 text-xs font-semibold cursor-pointer"
              style={{
                backgroundColor: eq.compressorEnabled ? 'var(--accent)' : 'var(--bg-elevated)',
                color: eq.compressorEnabled ? 'var(--accent-contrast)' : 'var(--text-secondary)',
              }}
            >
              {eq.compressorEnabled ? 'Activo' : 'Apagado'}
            </button>
          </div>
        </div>
      </div>

      {/* 2. Modos profesionales para auriculares */}
      <div
        className="rounded-2xl border p-5 sm:p-6"
        style={{
          backgroundColor: 'var(--bg-surface)',
          borderColor: 'var(--border-subtle)',
        }}
      >
        <div className="flex items-center gap-3">
          <div
            className="flex h-10 w-10 items-center justify-center rounded-xl"
            style={{ backgroundColor: 'var(--accent-soft)', color: 'var(--accent)' }}
          >
            <Headphones className="h-5 w-5" aria-hidden="true" />
          </div>
          <div>
            <h2 className="font-display text-lg font-bold" style={{ color: 'var(--text-primary)' }}>
              Modos profesionales para auriculares
            </h2>
            <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
              Perfiles acústicos calibrados con procesamiento binaural y convolución local
            </p>
          </div>
        </div>

        <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {HEADPHONE_MODES.map((mode) => {
            const active = settings.headphoneMode === mode.id;
            return (
              <button
                key={mode.id}
                type="button"
                onClick={() => handleSelectHeadphone(mode.id)}
                className="flex flex-col items-start justify-between rounded-2xl border p-4 text-left transition-colors cursor-pointer"
                style={{
                  borderColor: active ? 'var(--accent)' : 'var(--border-subtle)',
                  backgroundColor: active ? 'var(--accent-soft)' : 'var(--bg-elevated)',
                }}
              >
                <div className="flex w-full items-start justify-between gap-2">
                  <div>
                    <h3
                      className="text-sm font-semibold"
                      style={{ color: active ? 'var(--accent)' : 'var(--text-primary)' }}
                    >
                      {mode.name}
                    </h3>
                    <p className="text-xs font-medium mt-0.5" style={{ color: 'var(--text-secondary)' }}>
                      {mode.subtitle}
                    </p>
                  </div>
                  {active && (
                    <span
                      className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full"
                      style={{ backgroundColor: 'var(--accent)', color: 'var(--accent-contrast)' }}
                    >
                      <Check className="h-3.5 w-3.5" aria-hidden="true" />
                    </span>
                  )}
                </div>
                <p
                  className="mt-2.5 text-xs leading-relaxed"
                  style={{ color: 'var(--text-secondary)' }}
                >
                  {mode.description}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. Personalización de temas y fondo musical incorporado */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Temas */}
        <div
          className="rounded-2xl border p-5 sm:p-6"
          style={{
            backgroundColor: 'var(--bg-surface)',
            borderColor: 'var(--border-subtle)',
          }}
        >
          <div className="flex items-center gap-3">
            <div
              className="flex h-10 w-10 items-center justify-center rounded-xl"
              style={{ backgroundColor: 'var(--accent-soft)', color: 'var(--accent)' }}
            >
              <Palette className="h-5 w-5" aria-hidden="true" />
            </div>
            <div>
              <h2 className="font-display text-lg font-bold" style={{ color: 'var(--text-primary)' }}>
                Temas del reproductor
              </h2>
              <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                Cambia la paleta de toda la interfaz al instante
              </p>
            </div>
          </div>

          <div className="mt-5 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
            {PLAYER_THEMES.map((theme) => {
              const active = settings.theme === theme.id;
              return (
                <button
                  key={theme.id}
                  type="button"
                  onClick={() => handleSelectTheme(theme.id)}
                  className="flex items-center justify-between gap-3 rounded-xl border p-3 text-left transition-colors cursor-pointer"
                  style={{
                    borderColor: active ? 'var(--accent)' : 'var(--border-subtle)',
                    backgroundColor: active ? 'var(--accent-soft)' : 'var(--bg-elevated)',
                  }}
                >
                  <div className="flex items-center gap-3">
                    <span
                      className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-black/15"
                      style={{ backgroundColor: theme.canvasPreview }}
                    >
                      <span
                        className="h-3.5 w-3.5 rounded-full"
                        style={{ backgroundColor: theme.accentPreview }}
                      />
                    </span>
                    <span
                      className="text-sm font-medium"
                      style={{ color: 'var(--text-primary)' }}
                    >
                      {theme.name}
                    </span>
                  </div>
                  {active && (
                    <Check className="h-4 w-4 shrink-0" style={{ color: 'var(--accent)' }} aria-hidden="true" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Fondo incorporado del reproductor de música */}
        <div
          className="rounded-2xl border p-5 sm:p-6"
          style={{
            backgroundColor: 'var(--bg-surface)',
            borderColor: 'var(--border-subtle)',
          }}
        >
          <div className="flex items-center gap-3">
            <div
              className="flex h-10 w-10 items-center justify-center rounded-xl"
              style={{ backgroundColor: 'var(--accent-soft)', color: 'var(--accent)' }}
            >
              <ImageIcon className="h-5 w-5" aria-hidden="true" />
            </div>
            <div>
              <h2 className="font-display text-lg font-bold" style={{ color: 'var(--text-primary)' }}>
                Fondo incorporado de música
              </h2>
              <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                Escenario visual al abrir una canción
              </p>
            </div>
          </div>

          <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-3">
            {BUILT_IN_BACKDROPS.map((bg) => {
              const active = settings.backdrop === bg.id;
              return (
                <button
                  key={bg.id}
                  type="button"
                  onClick={() => handleSelectBackdrop(bg.id)}
                  className="group overflow-hidden rounded-xl border text-left transition-colors cursor-pointer"
                  style={{
                    borderColor: active ? 'var(--accent)' : 'var(--border-subtle)',
                    backgroundColor: 'var(--bg-elevated)',
                  }}
                >
                  <div className="relative aspect-video w-full overflow-hidden bg-neutral-900">
                    <img
                      src={bg.imageUrl}
                      alt={bg.name}
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                    {active && (
                      <span
                        className="absolute right-2 top-2 flex h-6 w-6 items-center justify-center rounded-full shadow"
                        style={{ backgroundColor: 'var(--accent)', color: 'var(--accent-contrast)' }}
                      >
                        <Check className="h-3.5 w-3.5" aria-hidden="true" />
                      </span>
                    )}
                  </div>
                  <div className="p-2.5">
                    <p
                      className="truncate text-xs font-semibold"
                      style={{ color: active ? 'var(--accent)' : 'var(--text-primary)' }}
                    >
                      {bg.name}
                    </p>
                    <p className="truncate text-[11px]" style={{ color: 'var(--text-secondary)' }}>
                      {bg.description}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 4. Acceso directo en el menú, link directo e instalación PWA (solo en navegador) */}
      {!isCapacitorNative() && <InstallAppCard />}

      {/* 5. Permisos de almacenamiento local y carpetas */}
      <div
        className="rounded-2xl border p-5 sm:p-6 space-y-4"
        style={{
          backgroundColor: 'var(--bg-surface)',
          borderColor: 'var(--border-subtle)',
        }}
      >
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3">
            <div
              className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl"
              style={{ backgroundColor: 'var(--accent-soft)', color: 'var(--accent)' }}
            >
              <HardDrive className="h-5 w-5" aria-hidden="true" />
            </div>
            <div>
              <h2 className="font-display text-base font-bold" style={{ color: 'var(--text-primary)' }}>
                Permisos de almacenamiento local
              </h2>
              <p className="mt-0.5 text-xs flex flex-wrap items-center gap-2" style={{ color: 'var(--text-secondary)' }}>
                <span className="inline-flex items-center gap-1">
                  <ShieldCheck
                    className="h-3.5 w-3.5"
                    style={{ color: storageStatus.persisted ? '#22c55e' : 'var(--accent)' }}
                    aria-hidden="true"
                  />
                  {storageStatus.persisted
                    ? 'Almacenamiento protegido activo'
                    : 'Permiso persistente pendiente'}
                </span>
                {storageStatus.quotaBytes > 0 && (
                  <span>
                    · Espacio disponible en app: {formatBytes(storageStatus.quotaBytes)}
                  </span>
                )}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {savedFolders.length > 0 && (
              <button
                type="button"
                disabled={isScanningFolders}
                onClick={onRescanFolders}
                className="flex min-h-[40px] items-center gap-1.5 rounded-xl border px-3.5 py-2 text-xs font-semibold cursor-pointer disabled:opacity-60"
                style={{
                  borderColor: 'var(--border-subtle)',
                  backgroundColor: 'var(--bg-elevated)',
                  color: 'var(--text-primary)',
                }}
              >
                <RefreshCw
                  className={`h-3.5 w-3.5 ${isScanningFolders ? 'animate-spin' : ''}`}
                  aria-hidden="true"
                />
                <span>{isScanningFolders ? 'Escaneando...' : 'Re-escanear carpetas'}</span>
              </button>
            )}
            <button
              type="button"
              onClick={onRequestStoragePermission}
              className="flex min-h-[40px] items-center gap-1.5 rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer"
              style={{
                backgroundColor: 'var(--accent)',
                color: 'var(--accent-contrast)',
              }}
            >
              <FolderOpen className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Solicitar permiso y elegir archivos</span>
            </button>
          </div>
        </div>

        {savedFolders.length > 0 && (
          <div className="space-y-2 pt-2 border-t" style={{ borderColor: 'var(--border-subtle)' }}>
            <p className="text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>
              Carpetas autorizadas ({savedFolders.length})
            </p>
            <div className="flex flex-wrap gap-2">
              {savedFolders.map((folder) => (
                <div
                  key={folder.id}
                  className="flex items-center gap-2 rounded-xl border px-3 py-1.5 text-xs"
                  style={{
                    backgroundColor: 'var(--bg-elevated)',
                    borderColor: 'var(--border-subtle)',
                    color: 'var(--text-primary)',
                  }}
                >
                  <FolderOpen className="h-3.5 w-3.5" style={{ color: 'var(--accent)' }} aria-hidden="true" />
                  <span className="max-w-[180px] truncate font-medium">{folder.name}</span>
                  <button
                    type="button"
                    onClick={() => onRemoveFolder(folder.id)}
                    aria-label={`Quitar carpeta ${folder.name}`}
                    className="ml-1 rounded p-0.5 hover:bg-white/10 cursor-pointer"
                    style={{ color: 'var(--text-muted)' }}
                  >
                    <Trash2 className="h-3 w-3" aria-hidden="true" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* 6. Gestión de biblioteca local */}
      <div
        className="flex flex-col gap-4 rounded-2xl border p-5 sm:flex-row sm:items-center sm:justify-between sm:p-6"
        style={{
          backgroundColor: 'var(--bg-surface)',
          borderColor: 'var(--border-subtle)',
        }}
      >
        <div>
          <h2 className="font-display text-base font-bold" style={{ color: 'var(--text-primary)' }}>
            Biblioteca local sin conexión
          </h2>
          <p className="mt-1 text-xs" style={{ color: 'var(--text-secondary)' }}>
            {musicCount} canciones · {videoCount} videos · {formatBytes(totalBytes)} en biblioteca
            {internalBlobBytes > 0
              ? ` (${formatBytes(internalBlobBytes)} copiados dentro de la app)`
              : musicCount + videoCount > 0
                ? ' (0 B copiados dentro de la app · lectura directa)'
                : ''}
          </p>
        </div>

        {(musicCount > 0 || videoCount > 0) && (
          <div className="flex items-center gap-2">
            {!confirmClear ? (
              <button
                type="button"
                onClick={() => setConfirmClear(true)}
                className="flex min-h-[42px] items-center gap-2 rounded-xl border px-4 py-2 text-xs font-semibold cursor-pointer"
                style={{
                  borderColor: 'var(--border-subtle)',
                  color: 'var(--text-secondary)',
                }}
              >
                <Trash2 className="h-4 w-4" aria-hidden="true" />
                <span>Vaciar biblioteca</span>
              </button>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    onClearLibrary();
                    setConfirmClear(false);
                  }}
                  className="min-h-[40px] rounded-xl bg-red-600 px-4 py-2 text-xs font-semibold text-white cursor-pointer"
                >
                  Confirmar vaciado
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmClear(false)}
                  className="min-h-[40px] rounded-xl border px-3 py-2 text-xs font-medium cursor-pointer"
                  style={{
                    borderColor: 'var(--border-subtle)',
                    color: 'var(--text-primary)',
                  }}
                >
                  Cancelar
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
}
