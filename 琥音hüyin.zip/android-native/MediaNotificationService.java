package com.huyin.reproductor;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Icon;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.IBinder;

public class MediaNotificationService extends Service {
    public static final String CHANNEL_ID = "huyin_media_playback";
    public static final int NOTIFICATION_ID = 1001;

    public static final String ACTION_UPDATE = "com.huyin.reproductor.MEDIA_UPDATE";
    public static final String ACTION_PLAY_PAUSE = "com.huyin.reproductor.MEDIA_PLAY_PAUSE";
    public static final String ACTION_NEXT = "com.huyin.reproductor.MEDIA_NEXT";
    public static final String ACTION_PREV = "com.huyin.reproductor.MEDIA_PREV";
    public static final String ACTION_DISMISS = "com.huyin.reproductor.MEDIA_DISMISS";

    private MediaSession mediaSession;
    private Bitmap artworkBitmap;

    private String currentTitle = "琥音Hǔyīn";
    private String currentArtist = "Biblioteca local";
    private String currentAlbum = "琥音Hǔyīn";
    private boolean currentPlaying = false;
    private long currentDurationMs = 0L;
    private long currentPositionMs = 0L;
    private float currentSpeed = 1.0f;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannelIfNeeded();
        loadArtwork();

        mediaSession = new MediaSession(this, "HuyinMediaSession");
        mediaSession.setCallback(new MediaSession.Callback() {
            @Override
            public void onPlay() {
                LocalMediaPlugin.dispatchMediaAction("play", null);
            }

            @Override
            public void onPause() {
                LocalMediaPlugin.dispatchMediaAction("pause", null);
            }

            @Override
            public void onSkipToNext() {
                LocalMediaPlugin.dispatchMediaAction("next", null);
            }

            @Override
            public void onSkipToPrevious() {
                LocalMediaPlugin.dispatchMediaAction("prev", null);
            }

            @Override
            public void onSeekTo(long pos) {
                LocalMediaPlugin.dispatchMediaAction("seek", pos / 1000.0);
            }

            @Override
            public void onStop() {
                LocalMediaPlugin.dispatchMediaAction("pause", null);
            }
        });
        mediaSession.setActive(true);
    }

    private void createChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Reproducción de música",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Controles de música en barra de notificaciones y pantalla bloqueada");
            channel.setShowBadge(false);
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) {
                nm.createNotificationChannel(channel);
            }
        }
    }

    private void loadArtwork() {
        try {
            int iconRes = getApplicationInfo().icon;
            if (iconRes != 0) {
                artworkBitmap = BitmapFactory.decodeResource(getResources(), iconRes);
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;

        if (ACTION_DISMISS.equals(action)) {
            LocalMediaPlugin.dispatchMediaAction("pause", null);
            stopForegroundCompat(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        if (ACTION_PLAY_PAUSE.equals(action)) {
            boolean nextPlaying = !currentPlaying;
            currentPlaying = nextPlaying;
            LocalMediaPlugin.dispatchMediaAction(nextPlaying ? "play" : "pause", null);
            updateMediaSessionState();
            startForegroundCompat(buildNotification());
            return START_NOT_STICKY;
        }

        if (ACTION_NEXT.equals(action)) {
            LocalMediaPlugin.dispatchMediaAction("next", null);
            startForegroundCompat(buildNotification());
            return START_NOT_STICKY;
        }

        if (ACTION_PREV.equals(action)) {
            LocalMediaPlugin.dispatchMediaAction("prev", null);
            startForegroundCompat(buildNotification());
            return START_NOT_STICKY;
        }

        if (intent != null && ACTION_UPDATE.equals(action)) {
            String title = intent.getStringExtra("title");
            String artist = intent.getStringExtra("artist");
            String album = intent.getStringExtra("album");
            if (title != null && !title.trim().isEmpty()) {
                currentTitle = title;
            }
            if (artist != null && !artist.trim().isEmpty()) {
                currentArtist = artist;
            }
            if (album != null && !album.trim().isEmpty()) {
                currentAlbum = album;
            }
            currentPlaying = intent.getBooleanExtra("isPlaying", false);
            currentDurationMs = Math.max(0L, intent.getLongExtra("durationMs", 0L));
            currentPositionMs = Math.max(0L, intent.getLongExtra("positionMs", 0L));
            currentSpeed = Math.max(0.25f, intent.getFloatExtra("playbackRate", 1.0f));
        }

        updateMediaSessionState();
        startForegroundCompat(buildNotification());
        return START_NOT_STICKY;
    }

    private void updateMediaSessionState() {
        if (mediaSession == null) return;

        MediaMetadata.Builder meta = new MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, currentTitle)
            .putString(MediaMetadata.METADATA_KEY_ARTIST, currentArtist)
            .putString(MediaMetadata.METADATA_KEY_ALBUM, currentAlbum)
            .putLong(MediaMetadata.METADATA_KEY_DURATION, currentDurationMs);

        if (artworkBitmap != null) {
            meta.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, artworkBitmap);
        }
        mediaSession.setMetadata(meta.build());

        long actions = PlaybackState.ACTION_PLAY
            | PlaybackState.ACTION_PAUSE
            | PlaybackState.ACTION_PLAY_PAUSE
            | PlaybackState.ACTION_SKIP_TO_PREVIOUS
            | PlaybackState.ACTION_SKIP_TO_NEXT
            | PlaybackState.ACTION_SEEK_TO
            | PlaybackState.ACTION_STOP;

        int state = currentPlaying ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED;
        float speed = currentPlaying ? currentSpeed : 0.0f;
        PlaybackState playbackState = new PlaybackState.Builder()
            .setActions(actions)
            .setState(state, currentPositionMs, speed)
            .build();
        mediaSession.setPlaybackState(playbackState);
    }

    private PendingIntent servicePendingIntent(String action, int requestCode) {
        Intent i = new Intent(this, MediaNotificationService.class);
        i.setAction(action);
        return PendingIntent.getService(
            this,
            requestCode,
            i,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private Notification.Action buildAction(int iconRes, String label, String action, int requestCode) {
        PendingIntent pi = servicePendingIntent(action, requestCode);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return new Notification.Action.Builder(
                Icon.createWithResource(this, iconRes),
                label,
                pi
            ).build();
        }
        @SuppressWarnings("deprecation")
        Notification.Action legacyAction = new Notification.Action.Builder(iconRes, label, pi).build();
        return legacyAction;
    }

    private Notification buildNotification() {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification.Action prevAction = buildAction(
            android.R.drawable.ic_media_previous,
            "Anterior",
            ACTION_PREV,
            1
        );
        Notification.Action playPauseAction = buildAction(
            currentPlaying ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play,
            currentPlaying ? "Pausar" : "Reproducir",
            ACTION_PLAY_PAUSE,
            2
        );
        Notification.Action nextAction = buildAction(
            android.R.drawable.ic_media_next,
            "Siguiente",
            ACTION_NEXT,
            3
        );

        Notification.MediaStyle style = new Notification.MediaStyle()
            .setMediaSession(mediaSession.getSessionToken())
            .setShowActionsInCompactView(0, 1, 2);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? new Notification.Builder(this, CHANNEL_ID)
            : new Notification.Builder(this);

        int smallIcon = getApplicationInfo().icon != 0
            ? getApplicationInfo().icon
            : android.R.drawable.ic_media_play;

        builder.setSmallIcon(smallIcon)
            .setContentTitle(currentTitle)
            .setContentText(currentArtist)
            .setSubText(currentAlbum)
            .setContentIntent(contentIntent)
            .setDeleteIntent(servicePendingIntent(ACTION_DISMISS, 4))
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOnlyAlertOnce(true)
            .setOngoing(currentPlaying)
            .setStyle(style)
            .addAction(prevAction)
            .addAction(playPauseAction)
            .addAction(nextAction);

        if (artworkBitmap != null) {
            builder.setLargeIcon(artworkBitmap);
        }

        return builder.build();
    }

    private void startForegroundCompat(Notification notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            );
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void stopForegroundCompat(boolean removeNotification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(removeNotification ? STOP_FOREGROUND_REMOVE : STOP_FOREGROUND_DETACH);
        } else {
            @SuppressWarnings("deprecation")
            boolean ignored = removeNotification;
            stopForeground(ignored);
        }
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        stopForegroundCompat(true);
        stopSelf();
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        if (mediaSession != null) {
            mediaSession.setActive(false);
            mediaSession.release();
            mediaSession = null;
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
