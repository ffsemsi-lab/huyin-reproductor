import { Download, Upload, X } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AndroidFolderModal } from './components/AndroidFolderModal';
import { MiniPlayer } from './components/MiniPlayer';
import { MusicNowPlaying } from './components/MusicNowPlaying';
import { MusicSection } from './components/MusicSection';
import { SettingsSection } from './components/SettingsSection';
import { StoragePermissionModal } from './components/StoragePermissionModal';
import { TopBar } from './components/TopBar';
import { VideoPlayerModal } from './components/VideoPlayerModal';
import { VideoSection } from './components/VideoSection';
import { PLAYER_THEMES } from './constants/presets';
import { usePWAInstall } from './hooks/usePWAInstall';
import type { AppSettings, MediaItem, NavSection, RepeatMode } from './types/media';
import { audioEngine } from './utils/audioEngine';
import {
  checkStoragePermissionStatus,
  clearAllMediaLibrary,
  cleanFileTitle,
  deleteDirectoryHandle,
  deleteMediaItem,
  detectMediaKind,
  extractMediaMetadata,
  extractMediaMetadataFromUrl,
  generateOfflineDemoMedia,
  getMediaBlob,
  loadAllMediaItems,
  loadDirectoryHandles,
  loadSavedSettings,
  parseArtistAndTitle,
  requestPersistentStorage,
  saveDirectoryHandle,
  saveMediaItemsBatch,
  saveSettings,
  scanDirectoryHandle,
  updateMediaItemMetadata,
  verifyDirectoryPermission,
  type SavedDirectoryEntry,
  type StoragePermissionStatus,
} from './utils/libraryDb';
import {
  addNativeMediaControlListener,
  clearNativeMediaNotification,
  ensureNativeMediaPermissions,
  ensureNativeNotificationPermission,
  getNativeStreamUrl,
  isCapacitorNative,
  isNativeAndroidMediaAvailable,
  scanNativeDirectory,
  type NativeMediaFile,
  updateNativeMediaNotification,
} from './utils/nativeAndroidMedia';
import { readSubtitleFile } from './utils/subtitles';

function safeRevokeObjectUrl(url: string | null | undefined) {
  if (url && url.startsWith('blob:')) {
    URL.revokeObjectURL(url);
  }
}

async function resolveMediaPlayableUrl(item: MediaItem): Promise<string | null> {
  if (item.localPath) {
    return await getNativeStreamUrl(item.localPath);
  }
  const blob = await getMediaBlob(item.id);
  if (!blob) return null;
  return URL.createObjectURL(blob);
}

const SECTION_ORDER: Record<NavSection, number> = {
  musica: 0,
  video: 1,
  ajustes: 2,
};

const PLAYBACK_SESSION_KEY = 'huyin_playback_session_v1';
const STORAGE_PROMPT_SEEN_KEY = 'huyin_storage_prompt_v1';

interface SavedPlaybackSession {
  trackId: string | null;
  currentTime: number;
  wasPlaying: boolean;
  isNowPlayingOpen: boolean;
  activeSection: NavSection;
  playbackRate: number;
  repeatMode: RepeatMode;
}

function loadSavedPlaybackSession(): Partial<SavedPlaybackSession> {
  if (typeof window === 'undefined') return {};
  try {
    const raw = window.localStorage.getItem(PLAYBACK_SESSION_KEY);
    if (!raw) return {};
    return JSON.parse(raw) as Partial<SavedPlaybackSession>;
  } catch {
    return {};
  }
}

export default function App() {
  const initialSessionRef = useRef<Partial<SavedPlaybackSession> | null>(null);
  if (initialSessionRef.current === null) {
    initialSessionRef.current = loadSavedPlaybackSession();
  }
  const initialSession = initialSessionRef.current;

  const [activeSection, setActiveSection] = useState<NavSection>(
    initialSession.activeSection && initialSession.activeSection in SECTION_ORDER
      ? initialSession.activeSection
      : 'musica'
  );
  const [navDirection, setNavDirection] = useState<number>(1);
  const [mediaItems, setMediaItems] = useState<MediaItem[]>([]);
  const [isLoadingLibrary, setIsLoadingLibrary] = useState(true);
  const [settings, setSettings] = useState<AppSettings>(() => loadSavedSettings());
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [dismissedInstallBanner, setDismissedInstallBanner] = useState(false);

  // Estado del reproductor de música
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [audioElement, setAudioElement] = useState<HTMLAudioElement | null>(null);
  const setAudioNode = useCallback((node: HTMLAudioElement | null) => {
    audioRef.current = node;
    setAudioElement(node);
  }, []);
  const audioObjectUrlRef = useRef<string | null>(null);
  const preloadedNextRef = useRef<{ trackId: string; url: string } | null>(null);
  const preloadTokenRef = useRef(0);
  const audioLoadTokenRef = useRef(0);
  const isTransitioningAudioRef = useRef(false);
  const shouldBePlayingRef = useRef(false);
  const hasRestoredSessionRef = useRef(false);
  const lastSavedTickRef = useRef(0);
  const pendingRestoreRef = useRef<{
    trackId: string;
    currentTime: number;
    wasPlaying: boolean;
  } | null>(
    initialSession.trackId
      ? {
          trackId: initialSession.trackId,
          currentTime:
            typeof initialSession.currentTime === 'number' && initialSession.currentTime > 0
              ? initialSession.currentTime
              : 0,
          wasPlaying: Boolean(initialSession.wasPlaying),
        }
      : null
  );
  const [audioSlotKey, setAudioSlotKey] = useState(0);
  const pendingSlotTransferRef = useRef<{
    url: string;
    currentTime: number;
    playbackRate: number;
    shouldPlay: boolean;
  } | null>(null);
  const [currentTrackId, setCurrentTrackId] = useState<string | null>(
    initialSession.trackId || null
  );
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);
  const [isNowPlayingOpen, setIsNowPlayingOpen] = useState(
    Boolean(initialSession.trackId && initialSession.isNowPlayingOpen)
  );
  const [audioDuration, setAudioDuration] = useState(0);
  const [playbackRate, setPlaybackRate] = useState(
    typeof initialSession.playbackRate === 'number' && initialSession.playbackRate > 0
      ? initialSession.playbackRate
      : 1
  );
  const [repeatMode, setRepeatMode] = useState<RepeatMode>(
    initialSession.repeatMode === 'pista' ||
      initialSession.repeatMode === 'ninguno' ||
      initialSession.repeatMode === 'lista'
      ? initialSession.repeatMode
      : 'lista'
  );
  const [sleepTimerMinutes, setSleepTimerMinutes] = useState<number | null>(null);

  // Estado del reproductor de video
  const videoObjectUrlRef = useRef<string | null>(null);
  const videoLoadTokenRef = useRef(0);
  const [activeVideo, setActiveVideo] = useState<MediaItem | null>(null);
  const [activeVideoUrl, setActiveVideoUrl] = useState<string | null>(null);

  const revokePreloadedNext = useCallback(() => {
    preloadTokenRef.current++;
    if (preloadedNextRef.current) {
      safeRevokeObjectUrl(preloadedNextRef.current.url);
      preloadedNextRef.current = null;
    }
  }, []);

  // Limpieza automática de ObjectURLs y buffers de decodificación al detener
  const releaseAudioUrl = useCallback(() => {
    isTransitioningAudioRef.current = false;
    revokePreloadedNext();
    const el = audioRef.current;
    if (el) {
      el.pause();
      el.removeAttribute('src');
      el.load();
    }
    audioEngine.suspendIdle();
    if (audioObjectUrlRef.current) {
      safeRevokeObjectUrl(audioObjectUrlRef.current);
      audioObjectUrlRef.current = null;
    }
  }, [revokePreloadedNext]);

  const releaseVideoUrl = useCallback(() => {
    if (videoObjectUrlRef.current) {
      safeRevokeObjectUrl(videoObjectUrlRef.current);
      videoObjectUrlRef.current = null;
    }
  }, []);

  useEffect(() => {
    return () => {
      releaseAudioUrl();
      releaseVideoUrl();
    };
  }, [releaseAudioUrl, releaseVideoUrl]);

  // Carga de archivos / Drag & Drop / Permisos de almacenamiento
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const folderInputRef = useRef<HTMLInputElement | null>(null);
  const mediaItemsRef = useRef<MediaItem[]>([]);
  mediaItemsRef.current = mediaItems;
  const [isDraggingFiles, setIsDraggingFiles] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importProgress, setImportProgress] = useState<{ done: number; total: number } | null>(null);
  const [isGeneratingDemo, setIsGeneratingDemo] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [showStorageModal, setShowStorageModal] = useState(false);
  const [showAndroidFolderModal, setShowAndroidFolderModal] = useState(false);
  const [savedFolders, setSavedFolders] = useState<SavedDirectoryEntry[]>([]);
  const [isScanningFolders, setIsScanningFolders] = useState(false);
  const [storageStatus, setStorageStatus] = useState<StoragePermissionStatus>({
    supported: false,
    persisted: false,
    usageBytes: 0,
    quotaBytes: 0,
  });

  const supportsWebkitDir = useMemo(() => {
    if (typeof document === 'undefined') return false;
    const input = document.createElement('input');
    return 'webkitdirectory' in input;
  }, []);

  const supportsFolderPicker =
    isNativeAndroidMediaAvailable() ||
    (typeof window !== 'undefined' && 'showDirectoryPicker' in window) ||
    supportsWebkitDir;

  useEffect(() => {
    const el = folderInputRef.current;
    if (!el) return;
    el.setAttribute('webkitdirectory', '');
    el.setAttribute('directory', '');
  }, []);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
  }, []);

  useEffect(() => {
    if (!toastMessage) return;
    const t = window.setTimeout(() => setToastMessage(null), 3200);
    return () => window.clearTimeout(t);
  }, [toastMessage]);

  // Aplicar tema y modo oscuro al documento
  useEffect(() => {
    const themeInfo = PLAYER_THEMES.find((t) => t.id === settings.theme);
    const root = document.documentElement;
    if (settings.theme === 'obsidiana') {
      root.removeAttribute('data-theme');
    } else {
      root.setAttribute('data-theme', settings.theme);
    }
    if (themeInfo?.isDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    saveSettings(settings);
  }, [settings]);

  const useDspPipeline = useMemo(() => {
    if (settings.headphoneMode !== 'estandar') return true;
    const eq = settings.equalizer;
    if (!eq.enabled) return false;
    return (
      eq.preampDb !== 0 ||
      eq.bassBoostDb !== 0 ||
      eq.trebleClarityDb !== 0 ||
      eq.compressorEnabled ||
      eq.bands.some((g) => g !== 0)
    );
  }, [settings.headphoneMode, settings.equalizer]);

  const useDspPipelineRef = useRef(useDspPipeline);
  useDspPipelineRef.current = useDspPipeline;

  // Sincronizar motor de audio Web Audio API con ajustes y cambiar entre ruta hardware/DSP sin cortes
  useEffect(() => {
    audioEngine.applyEqualizer(settings.equalizer);
  }, [settings.equalizer]);

  useEffect(() => {
    audioEngine.applyHeadphoneMode(settings.headphoneMode);
  }, [settings.headphoneMode]);

  useEffect(() => {
    const el = audioRef.current;
    if (!el) return;

    if (useDspPipeline) {
      if (audioObjectUrlRef.current) {
        audioEngine.connectMediaElement(el);
        audioEngine.resume();
      }
      return;
    }

    // Si el usuario desactiva EQ/efectos, devolver el <audio> a ruta nativa de hardware (sin Web Audio)
    if (audioEngine.hasConnectedElement(el)) {
      if (audioObjectUrlRef.current && el.src) {
        isTransitioningAudioRef.current = true;
        const snapshotTime = Number.isFinite(el.currentTime) ? el.currentTime : 0;
        el.pause();
        pendingSlotTransferRef.current = {
          url: audioObjectUrlRef.current,
          currentTime: snapshotTime,
          playbackRate,
          shouldPlay: shouldBePlayingRef.current,
        };
      }
      setAudioSlotKey((k) => k + 1);
    }
  }, [useDspPipeline, playbackRate]);

  useEffect(() => {
    if (audioSlotKey === 0) return;
    const pending = pendingSlotTransferRef.current;
    pendingSlotTransferRef.current = null;
    const el = audioRef.current;
    if (!pending || !el) return;

    isTransitioningAudioRef.current = true;
    el.src = pending.url;
    el.playbackRate = pending.playbackRate;
    el.volume = 1;
    el.muted = false;

    const applySeek = () => {
      if (pending.currentTime > 0) {
        const maxT =
          Number.isFinite(el.duration) && el.duration > 0
            ? Math.max(0, el.duration - 0.25)
            : pending.currentTime;
        el.currentTime = Math.max(0, Math.min(pending.currentTime, maxT));
      }
    };

    if (el.readyState >= 1) {
      applySeek();
    } else {
      el.addEventListener('loadedmetadata', applySeek, { once: true });
    }

    if (pending.shouldPlay) {
      el.play()
        .then(() => {
          isTransitioningAudioRef.current = false;
          setIsMusicPlaying(true);
        })
        .catch(() => {
          isTransitioningAudioRef.current = false;
          setIsMusicPlaying(false);
        });
    } else {
      isTransitioningAudioRef.current = false;
    }
  }, [audioSlotKey]);

  // Guardar estado actual de reproducción para que nunca se pierda al salir/volver de la app
  const persistPlaybackSession = useCallback(
    (overridePlaying?: boolean) => {
      if (typeof window === 'undefined' || !hasRestoredSessionRef.current) return;
      try {
        const snapshot: SavedPlaybackSession = {
          trackId: currentTrackId,
          currentTime: audioRef.current?.currentTime || 0,
          wasPlaying:
            overridePlaying !== undefined ? overridePlaying : shouldBePlayingRef.current,
          isNowPlayingOpen,
          activeSection,
          playbackRate,
          repeatMode,
        };
        window.localStorage.setItem(PLAYBACK_SESSION_KEY, JSON.stringify(snapshot));
      } catch {
        // Ignorar errores de almacenamiento
      }
    },
    [
      currentTrackId,
      isNowPlayingOpen,
      activeSection,
      playbackRate,
      repeatMode,
    ]
  );

  const persistPlaybackSessionRef = useRef(persistPlaybackSession);
  persistPlaybackSessionRef.current = persistPlaybackSession;

  useEffect(() => {
    persistPlaybackSession();
  }, [persistPlaybackSession]);

  const refreshStorageState = useCallback(async () => {
    const [status, folders] = await Promise.all([
      checkStoragePermissionStatus(),
      loadDirectoryHandles(),
    ]);
    setStorageStatus(status);
    setSavedFolders(folders);
    return { status, folders };
  }, []);

  // Cargar biblioteca desde IndexedDB al iniciar, verificar permisos y restaurar sesión
  useEffect(() => {
    let mounted = true;
    Promise.all([
      loadAllMediaItems(),
      checkStoragePermissionStatus(),
      loadDirectoryHandles(),
    ]).then(async ([items, status, folders]) => {
      if (!mounted) return;
      setMediaItems(items);
      setStorageStatus(status);
      setSavedFolders(folders);
      setIsLoadingLibrary(false);

      // Pedir permiso de almacenamiento la primera vez si aún no hay archivos ni carpetas vinculadas
      try {
        const promptSeen = window.localStorage.getItem(STORAGE_PROMPT_SEEN_KEY);
        if (!promptSeen && items.length === 0 && folders.length === 0) {
          setShowStorageModal(true);
        }
      } catch {
        // Ignorar
      }

      const pending = pendingRestoreRef.current;
      pendingRestoreRef.current = null;
      if (!pending || !pending.trackId) {
        hasRestoredSessionRef.current = true;
        return;
      }

      const found = items.find((it) => it.kind === 'audio' && it.id === pending.trackId);
      if (!found) {
        setCurrentTrackId(null);
        setIsNowPlayingOpen(false);
        hasRestoredSessionRef.current = true;
        persistPlaybackSessionRef.current(false);
        return;
      }

      const url = await resolveMediaPlayableUrl(found);
      if (!mounted || !url) {
        hasRestoredSessionRef.current = true;
        return;
      }

      const prevUrl = audioObjectUrlRef.current;
      audioObjectUrlRef.current = url;
      setCurrentTrackId(found.id);
      setAudioDuration(found.duration || 0);

      const el = audioRef.current;
      if (el) {
        el.src = url;
        el.playbackRate = playbackRate;
        el.volume = 1;
        el.muted = false;

        const seekToSaved = () => {
          if (pending.currentTime > 0) {
            const maxT = Number.isFinite(el.duration) && el.duration > 0 ? el.duration - 0.5 : pending.currentTime;
            el.currentTime = Math.max(0, Math.min(pending.currentTime, maxT));
          }
        };

        if (el.readyState >= 1) {
          seekToSaved();
        } else {
          el.addEventListener('loadedmetadata', seekToSaved, { once: true });
        }

        if (useDspPipelineRef.current) {
          audioEngine.connectMediaElement(el);
        }

        if (pending.wasPlaying) {
          shouldBePlayingRef.current = true;
          if (audioEngine.hasConnectedElement(el)) {
            audioEngine.resume();
          }
          el.play()
            .then(() => setIsMusicPlaying(true))
            .catch(() => {
              // Si el navegador bloqueó el inicio automático tras recarga del sistema, reanudar al primer toque
              setIsMusicPlaying(false);
              showToast(`Listo para continuar: ${found.title}`);
              const resumeOnFirstTap = () => {
                window.removeEventListener('pointerdown', resumeOnFirstTap);
                window.removeEventListener('keydown', resumeOnFirstTap);
                if (!shouldBePlayingRef.current || !audioRef.current) return;
                if (audioEngine.hasConnectedElement(audioRef.current)) {
                  audioEngine.resume();
                }
                void audioRef.current.play().then(() => setIsMusicPlaying(true)).catch(() => {});
              };
              window.addEventListener('pointerdown', resumeOnFirstTap, { once: true });
              window.addEventListener('keydown', resumeOnFirstTap, { once: true });
            });
        }
      }

      if (prevUrl && prevUrl !== url) {
        safeRevokeObjectUrl(prevUrl);
      }
      hasRestoredSessionRef.current = true;
    });
    return () => {
      mounted = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Proteger y reanudar reproducción al salir de la app y volver a entrar (con debounce para evitar micro-cortes por notificaciones)
  useEffect(() => {
    let resumeTimer: number | null = null;

    const scheduleSafeResume = () => {
      if (resumeTimer !== null) {
        window.clearTimeout(resumeTimer);
      }
      resumeTimer = window.setTimeout(() => {
        resumeTimer = null;
        const el = audioRef.current;
        if (!el) return;
        if (audioEngine.hasConnectedElement(el)) {
          audioEngine.resume();
        }
        if (shouldBePlayingRef.current && el.src && el.paused && !el.ended) {
          void el.play().then(() => setIsMusicPlaying(true)).catch(() => {});
        }
      }, 180);
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        if (resumeTimer !== null) {
          window.clearTimeout(resumeTimer);
          resumeTimer = null;
        }
        if (!shouldBePlayingRef.current) {
          audioEngine.suspendIdle();
        }
        persistPlaybackSessionRef.current(shouldBePlayingRef.current);
        return;
      }
      scheduleSafeResume();
    };

    const handlePageHide = () => {
      if (resumeTimer !== null) {
        window.clearTimeout(resumeTimer);
        resumeTimer = null;
      }
      persistPlaybackSessionRef.current(shouldBePlayingRef.current);
    };

    const handlePageShow = () => {
      scheduleSafeResume();
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('pagehide', handlePageHide);
    window.addEventListener('pageshow', handlePageShow);

    return () => {
      if (resumeTimer !== null) {
        window.clearTimeout(resumeTimer);
      }
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('pagehide', handlePageHide);
      window.removeEventListener('pageshow', handlePageShow);
    };
  }, []);

  const tracks = useMemo(
    () => mediaItems.filter((item) => item.kind === 'audio'),
    [mediaItems]
  );

  const videos = useMemo(
    () => mediaItems.filter((item) => item.kind === 'video'),
    [mediaItems]
  );

  const totalBytes = useMemo(
    () => mediaItems.reduce((acc, item) => acc + (item.size || 0), 0),
    [mediaItems]
  );

  const internalBlobBytes = useMemo(
    () =>
      mediaItems.reduce(
        (acc, item) => (item.localPath ? acc : acc + (item.size || 0)),
        0
      ),
    [mediaItems]
  );

  const currentTrack = useMemo(
    () => tracks.find((t) => t.id === currentTrackId) || null,
    [tracks, currentTrackId]
  );

  // Cambio de sección con dirección de transición fluida
  const handleSelectSection = useCallback(
    (next: NavSection) => {
      if (next === activeSection) return;
      setNavDirection(SECTION_ORDER[next] >= SECTION_ORDER[activeSection] ? 1 : -1);
      setActiveSection(next);
    },
    [activeSection]
  );

  // Temporizador de apagado con liberación inmediata de memoria
  useEffect(() => {
    if (!sleepTimerMinutes) return;
    const ms = sleepTimerMinutes * 60 * 1000;
    const timer = window.setTimeout(() => {
      shouldBePlayingRef.current = false;
      releaseAudioUrl();
      setIsMusicPlaying(false);
      setSleepTimerMinutes(null);
      persistPlaybackSessionRef.current(false);
      showToast('Temporizador finalizado: reproducción detenida');
    }, ms);
    return () => window.clearTimeout(timer);
  }, [sleepTimerMinutes, releaseAudioUrl, showToast]);

  // Importación rápida y equilibrada de archivos locales (lotes paralelos controlados + escritura agrupada)
  const importFiles = useCallback(
    async (
      fileList: File[],
      presetSubtitles?: Map<string, { name: string; raw: string }>
    ) => {
      if (fileList.length === 0) return;
      setIsImporting(true);
      setImportProgress(null);

      try {
        const subtitleMap = presetSubtitles ?? new Map<string, { name: string; raw: string }>();
        const mediaFiles: File[] = [];

        for (const file of fileList) {
          const ext = file.name.split('.').pop()?.toLowerCase() || '';
          if (ext === 'srt' || ext === 'vtt' || ext === 'ass' || ext === 'ssa') {
            const raw = await readSubtitleFile(file);
            subtitleMap.set(cleanFileTitle(file.name).toLowerCase(), {
              name: file.name,
              raw,
            });
          } else if (detectMediaKind(file)) {
            mediaFiles.push(file);
          }
        }

        let addedAudio = 0;
        let addedVideo = 0;
        let skippedDuplicates = 0;
        const pendingFiles: Array<{ file: File; kind: 'audio' | 'video' }> = [];
        const existingSignatures = new Set(
          mediaItemsRef.current.map((it) => `${it.name}|${it.size}|${it.lastModified}`)
        );

        for (const file of mediaFiles) {
          const signature = `${file.name}|${file.size}|${file.lastModified}`;
          if (existingSignatures.has(signature)) {
            skippedDuplicates++;
            continue;
          }
          existingSignatures.add(signature);
          const kind = detectMediaKind(file);
          if (kind) {
            pendingFiles.push({ file, kind });
          }
        }

        if (pendingFiles.length > 0) {
          const total = pendingFiles.length;
          if (total > 1) {
            setImportProgress({ done: 0, total });
          }

          const hasVideos = pendingFiles.some((p) => p.kind === 'video');
          const concurrency = hasVideos ? 3 : 4;
          const batchBuffer: Array<{ item: MediaItem; blob: Blob }> = [];
          const baseTime = Date.now();
          let cursor = 0;
          let completed = 0;
          let flushChain: Promise<void> = Promise.resolve();

          const enqueueFlush = (force = false) => {
            if (!force && batchBuffer.length < 4) return;
            if (batchBuffer.length === 0) return;
            const toWrite = batchBuffer.splice(0, batchBuffer.length);
            flushChain = flushChain.then(async () => {
              await saveMediaItemsBatch(toWrite);
              const itemsToAdd = toWrite.map((e) => e.item);
              setMediaItems((prev) => [...itemsToAdd, ...prev]);
            });
          };

          const worker = async () => {
            while (cursor < total) {
              const idx = cursor++;
              const { file, kind } = pendingFiles[idx];
              const ext = (file.name.split('.').pop() || kind).toLowerCase();
              const meta = await extractMediaMetadata(file, kind);
              const parsed =
                kind === 'audio'
                  ? parseArtistAndTitle(file.name)
                  : { title: cleanFileTitle(file.name), artist: 'Video local' };

              const matchedSub =
                kind === 'video'
                  ? subtitleMap.get(cleanFileTitle(file.name).toLowerCase())
                  : undefined;

              const item: MediaItem = {
                id: `${baseTime + idx}-${Math.random().toString(36).slice(2, 9)}`,
                name: file.name,
                title: parsed.title,
                artist: parsed.artist,
                kind,
                format: ext,
                mimeType: file.type || `${kind}/${ext}`,
                size: file.size,
                duration: meta.duration,
                width: meta.width,
                height: meta.height,
                thumbnailUrl: meta.thumbnailUrl,
                addedAt: baseTime - idx,
                lastModified: file.lastModified,
                subtitleName: matchedSub?.name,
                subtitleRaw: matchedSub?.raw,
              };

              if (kind === 'audio') addedAudio++;
              else addedVideo++;

              completed++;
              if (total > 1) {
                setImportProgress({ done: completed, total });
              }

              batchBuffer.push({ item, blob: file });
              enqueueFlush(false);
            }
          };

          await Promise.all(
            Array.from({ length: Math.min(concurrency, total) }, () => worker())
          );
          enqueueFlush(true);
          try {
            await flushChain;
          } catch {
            showToast(
              isNativeAndroidMediaAvailable()
                ? 'Archivo demasiado grande para copiar: usa «Explorar carpetas» para leerlo directo sin copiar'
                : 'El almacenamiento del navegador está lleno para archivos tan grandes'
            );
            return;
          }
        }

        if (addedAudio + addedVideo > 0) {
          const parts: string[] = [];
          if (addedAudio > 0) parts.push(`${addedAudio} ${addedAudio === 1 ? 'canción' : 'canciones'}`);
          if (addedVideo > 0) parts.push(`${addedVideo} ${addedVideo === 1 ? 'video' : 'videos'}`);
          showToast(`Añadido a tu biblioteca: ${parts.join(' y ')}`);
        } else if (skippedDuplicates > 0) {
          showToast('Tu biblioteca ya está al día con estos archivos');
        } else if (subtitleMap.size > 0) {
          showToast('Para adjuntar subtítulos, ábrelos dentro del reproductor de video o junto al archivo de video');
        } else {
          showToast('No se detectaron archivos de audio o video compatibles');
        }

        void refreshStorageState();
      } finally {
        setImportProgress(null);
        setIsImporting(false);
      }
    },
    [showToast, refreshStorageState]
  );

  const markStoragePromptSeen = useCallback(() => {
    try {
      window.localStorage.setItem(STORAGE_PROMPT_SEEN_KEY, '1');
    } catch {
      // Ignorar
    }
  }, []);

  const importNativeMediaEntries = useCallback(
    async (entries: NativeMediaFile[], label: string, emptyMsg: string) => {
      markStoragePromptSeen();
      setShowAndroidFolderModal(false);
      setShowStorageModal(false);
      setIsImporting(true);
      setImportProgress(null);

      try {
        if (entries.length === 0) {
          showToast(emptyMsg);
          return;
        }

        const existingPaths = new Set(
          mediaItemsRef.current.map((it) => it.localPath).filter(Boolean)
        );
        const existingSignatures = new Set(
          mediaItemsRef.current.map((it) => `${it.name}|${it.size}|${it.lastModified}`)
        );

        const pending = entries.filter((f) => {
          if (existingPaths.has(f.path)) return false;
          const sig = `${f.name}|${f.size}|${f.lastModified}`;
          if (existingSignatures.has(sig)) return false;
          existingPaths.add(f.path);
          existingSignatures.add(sig);
          return true;
        });

        if (pending.length === 0) {
          showToast('Tu biblioteca ya está al día con estos archivos');
          return;
        }

        const total = pending.length;
        if (total > 1) {
          setImportProgress({ done: 0, total });
        }

        const hasVideos = pending.some((p) => p.kind === 'video');
        const concurrency = hasVideos ? 3 : 4;
        const batchBuffer: Array<{ item: MediaItem }> = [];
        const baseTime = Date.now();
        let cursor = 0;
        let completed = 0;
        let addedAudio = 0;
        let addedVideo = 0;
        let flushChain: Promise<void> = Promise.resolve();

        const enqueueFlush = (force = false) => {
          if (!force && batchBuffer.length < 6) return;
          if (batchBuffer.length === 0) return;
          const toWrite = batchBuffer.splice(0, batchBuffer.length);
          flushChain = flushChain.then(async () => {
            await saveMediaItemsBatch(toWrite);
            const itemsToAdd = toWrite.map((e) => e.item);
            setMediaItems((prev) => [...itemsToAdd, ...prev]);
          });
        };

        const worker = async () => {
          while (cursor < total) {
            const idx = cursor++;
            const f = pending[idx];
            const ext = (f.name.split('.').pop() || f.kind).toLowerCase();
            const isNativeOnlyVideo =
              f.kind === 'video' &&
              ['mkv', 'avi', 'wmv', 'flv', 'ts', 'm2ts', 'mts', 'mpg', 'mpeg'].includes(ext);
            const meta = isNativeOnlyVideo
              ? { duration: 0 }
              : await extractMediaMetadataFromUrl(await getNativeStreamUrl(f.path), f.kind, false);
            const parsed =
              f.kind === 'audio'
                ? parseArtistAndTitle(f.name)
                : { title: cleanFileTitle(f.name), artist: 'Video local' };

            const item: MediaItem = {
              id: `${baseTime + idx}-${Math.random().toString(36).slice(2, 9)}`,
              name: f.name,
              title: parsed.title,
              artist: parsed.artist,
              kind: f.kind,
              format: ext,
              mimeType: `${f.kind}/${ext}`,
              size: f.size,
              duration: meta.duration,
              width: meta.width,
              height: meta.height,
              thumbnailUrl: meta.thumbnailUrl,
              addedAt: baseTime - idx,
              lastModified: f.lastModified,
              localPath: f.path,
            };

            if (f.kind === 'audio') addedAudio++;
            else addedVideo++;

            completed++;
            if (total > 1) {
              setImportProgress({ done: completed, total });
            }

            batchBuffer.push({ item });
            enqueueFlush(false);
          }
        };

        await Promise.all(
          Array.from({ length: Math.min(concurrency, total) }, () => worker())
        );
        enqueueFlush(true);
        await flushChain;

        const parts: string[] = [];
        if (addedAudio > 0) parts.push(`${addedAudio} ${addedAudio === 1 ? 'canción' : 'canciones'}`);
        if (addedVideo > 0) parts.push(`${addedVideo} ${addedVideo === 1 ? 'video' : 'videos'}`);
        showToast(`${label}: ${parts.join(' y ')}`);
        void refreshStorageState();
      } catch {
        showToast('No se pudieron importar los archivos seleccionados');
      } finally {
        setImportProgress(null);
        setIsImporting(false);
      }
    },
    [markStoragePromptSeen, showToast, refreshStorageState]
  );

  const handleImportNativeFolder = useCallback(
    async (folderPath: string, folderName: string) => {
      const scanned = await scanNativeDirectory(folderPath, 600);
      await importNativeMediaEntries(
        scanned,
        `Carpeta «${folderName}» añadida`,
        `No se encontraron archivos de música o video en «${folderName}»`
      );
    },
    [importNativeMediaEntries]
  );

  const handleImportNativeFiles = useCallback(
    async (files: NativeMediaFile[], folderName: string) => {
      await importNativeMediaEntries(
        files,
        `Enlazado desde «${folderName}»`,
        'No seleccionaste archivos multimedia'
      );
    },
    [importNativeMediaEntries]
  );

  const handleOpenFolder = useCallback(async () => {
    if (isNativeAndroidMediaAvailable()) {
      const granted = await ensureNativeMediaPermissions();
      if (!granted) {
        showToast('Concede permiso a música y videos para explorar carpetas');
        return;
      }
      markStoragePromptSeen();
      setShowStorageModal(false);
      setShowAndroidFolderModal(true);
      return;
    }

    if (typeof window !== 'undefined' && 'showDirectoryPicker' in window) {
      try {
        void requestPersistentStorage().then(() => refreshStorageState());
        // @ts-expect-error showDirectoryPicker disponible en navegadores compatibles
        const dirHandle = await window.showDirectoryPicker({ mode: 'read' });
        await saveDirectoryHandle(dirHandle);
        markStoragePromptSeen();
        setShowStorageModal(false);
        const files = await scanDirectoryHandle(dirHandle);
        await importFiles(files);
        await refreshStorageState();
      } catch (err) {
        if ((err as Error)?.name !== 'AbortError') {
          showToast('No se pudo abrir la carpeta seleccionada');
        }
      }
      return;
    }

    if (supportsWebkitDir && folderInputRef.current) {
      markStoragePromptSeen();
      setShowStorageModal(false);
      folderInputRef.current.click();
      return;
    }

    markStoragePromptSeen();
    setShowStorageModal(false);
    fileInputRef.current?.click();
  }, [importFiles, showToast, markStoragePromptSeen, refreshStorageState, supportsWebkitDir]);

  const handleSmartAddFiles = useCallback(() => {
    if (isNativeAndroidMediaAvailable()) {
      void handleOpenFolder();
      return;
    }
    fileInputRef.current?.click();
  }, [handleOpenFolder]);

  const handleGrantAndSelectFiles = useCallback(() => {
    markStoragePromptSeen();
    setShowStorageModal(false);
    if (isNativeAndroidMediaAvailable()) {
      void handleOpenFolder();
      return;
    }
    // Abrir el selector del sistema de forma síncrona para conservar la activación táctil en móvil/iOS
    fileInputRef.current?.click();
    void requestPersistentStorage().then(() => refreshStorageState());
  }, [markStoragePromptSeen, refreshStorageState, handleOpenFolder]);

  const handleRequestStorageOnly = useCallback(async () => {
    markStoragePromptSeen();
    const res = await requestPersistentStorage();
    await refreshStorageState();
    setShowStorageModal(false);
    showToast(
      res.persisted
        ? 'Permiso de almacenamiento local activado'
        : 'Almacenamiento local listo para tus archivos'
    );
  }, [markStoragePromptSeen, refreshStorageState, showToast]);

  const handleRescanFolders = useCallback(async () => {
    if (savedFolders.length === 0) return;
    setIsScanningFolders(true);
    try {
      await requestPersistentStorage();
      const collected: File[] = [];
      for (const entry of savedFolders) {
        const granted = await verifyDirectoryPermission(entry.handle, true);
        if (granted) {
          const files = await scanDirectoryHandle(entry.handle);
          collected.push(...files);
        }
      }
      if (collected.length > 0) {
        await importFiles(collected);
      } else {
        showToast('No hay archivos nuevos en las carpetas autorizadas');
      }
      await refreshStorageState();
    } catch {
      showToast('No se pudo verificar el permiso de las carpetas');
    } finally {
      setIsScanningFolders(false);
    }
  }, [savedFolders, importFiles, refreshStorageState, showToast]);

  const handleRemoveFolder = useCallback(
    async (id: string) => {
      await deleteDirectoryHandle(id);
      await refreshStorageState();
      showToast('Carpeta desvinculada');
    },
    [refreshStorageState, showToast]
  );

  const handleGenerateDemo = useCallback(async () => {
    setIsGeneratingDemo(true);
    try {
      const samples = await generateOfflineDemoMedia();
      const subMap = new Map<string, { name: string; raw: string }>();
      const files: File[] = [];
      for (const s of samples) {
        files.push(s.file);
        if (s.subtitleName && s.subtitleRaw) {
          subMap.set(cleanFileTitle(s.file.name).toLowerCase(), {
            name: s.subtitleName,
            raw: s.subtitleRaw,
          });
        }
      }
      await importFiles(files, subMap);
    } finally {
      setIsGeneratingDemo(false);
    }
  }, [importFiles]);

  const resolveNextTrack = useCallback(
    (fromEnded: boolean): MediaItem | null => {
      if (tracks.length === 0) return null;

      if (fromEnded && repeatMode === 'pista') {
        return tracks.find((t) => t.id === currentTrackId) || null;
      }

      const idx = tracks.findIndex((t) => t.id === currentTrackId);
      if (fromEnded && repeatMode === 'ninguno') {
        if (idx !== -1 && idx < tracks.length - 1) {
          return tracks[idx + 1];
        }
        return null;
      }

      const nextIdx = idx === -1 ? 0 : (idx + 1) % tracks.length;
      return tracks[nextIdx] || null;
    },
    [tracks, repeatMode, currentTrackId]
  );

  // Reproducir pista de música con intercambio atómico y revocación inmediata del ObjectURL previo
  const playTrack = useCallback(
    async (track: MediaItem, openFullView = true) => {
      const loadToken = ++audioLoadTokenRef.current;

      let url: string | null = null;
      if (preloadedNextRef.current?.trackId === track.id) {
        url = preloadedNextRef.current.url;
        preloadedNextRef.current = null;
      } else {
        revokePreloadedNext();
        url = await resolveMediaPlayableUrl(track);
        if (loadToken !== audioLoadTokenRef.current) {
          safeRevokeObjectUrl(url);
          return;
        }
        if (!url) {
          showToast('No se encontró el archivo local en el almacenamiento');
          return;
        }
      }

      if (loadToken !== audioLoadTokenRef.current) {
        safeRevokeObjectUrl(url);
        return;
      }

      const prevUrl = audioObjectUrlRef.current;
      audioObjectUrlRef.current = url;
      shouldBePlayingRef.current = true;
      setCurrentTrackId(track.id);
      setAudioDuration(track.duration || 0);

      if (openFullView) {
        setIsNowPlayingOpen(true);
      }

      const el = audioRef.current;
      if (el) {
        if (!useDspPipeline && audioEngine.hasConnectedElement(el)) {
          // Cambiar a un nodo <audio> nativo limpio cuando el DSP está desactivado
          isTransitioningAudioRef.current = true;
          el.pause();
          pendingSlotTransferRef.current = {
            url,
            currentTime: 0,
            playbackRate,
            shouldPlay: true,
          };
          setAudioSlotKey((k) => k + 1);
        } else {
          isTransitioningAudioRef.current = true;
          el.src = url;
          el.playbackRate = playbackRate;
          el.volume = 1;
          el.muted = false;

          if (useDspPipeline) {
            audioEngine.connectMediaElement(el);
            audioEngine.resume();
          }

          const startPlayback = () => {
            el.play()
              .then(() => {
                if (audioLoadTokenRef.current !== loadToken) return;
                isTransitioningAudioRef.current = false;
                setIsMusicPlaying(true);
                persistPlaybackSessionRef.current(true);
              })
              .catch(() => {
                if (audioLoadTokenRef.current !== loadToken) return;
                isTransitioningAudioRef.current = false;
                const retryOnCanPlay = () => {
                  if (audioLoadTokenRef.current !== loadToken) return;
                  el.play()
                    .then(() => {
                      if (audioLoadTokenRef.current !== loadToken) return;
                      setIsMusicPlaying(true);
                      persistPlaybackSessionRef.current(true);
                    })
                    .catch(() => {
                      if (audioLoadTokenRef.current === loadToken) setIsMusicPlaying(false);
                    });
                };
                el.addEventListener('canplay', retryOnCanPlay, { once: true });
              });
          };

          startPlayback();
        }
      }

      // Destruir inmediatamente el ObjectURL de la canción anterior tras asignar la nueva
      if (prevUrl && prevUrl !== url) {
        safeRevokeObjectUrl(prevUrl);
      }
    },
    [playbackRate, useDspPipeline, revokePreloadedNext, showToast]
  );

  // Precargar únicamente el ObjectURL de la siguiente canción tras iniciar la actual para no competir con I/O
  useEffect(() => {
    if (!currentTrackId || !isMusicPlaying || tracks.length === 0) return;

    if (repeatMode === 'pista') {
      revokePreloadedNext();
      return;
    }

    const idx = tracks.findIndex((t) => t.id === currentTrackId);
    if (repeatMode === 'ninguno' && (idx === -1 || idx >= tracks.length - 1)) {
      revokePreloadedNext();
      return;
    }

    const nextIdx = idx === -1 ? 0 : (idx + 1) % tracks.length;
    const candidate = tracks[nextIdx];

    if (!candidate || candidate.id === currentTrackId) return;
    if (preloadedNextRef.current?.trackId === candidate.id) return;

    const token = ++preloadTokenRef.current;
    const candidateItem = candidate;

    const timer = window.setTimeout(() => {
      void resolveMediaPlayableUrl(candidateItem).then((url) => {
        if (!url || token !== preloadTokenRef.current) {
          safeRevokeObjectUrl(url);
          return;
        }
        if (preloadedNextRef.current) {
          safeRevokeObjectUrl(preloadedNextRef.current.url);
        }
        preloadedNextRef.current = {
          trackId: candidateItem.id,
          url,
        };
      });
    }, 650);

    return () => window.clearTimeout(timer);
  }, [currentTrackId, isMusicPlaying, repeatMode, tracks, revokePreloadedNext]);

  const toggleMusicPlay = useCallback(() => {
    const el = audioRef.current;
    if (!el || !currentTrackId) return;
    // Si la memoria fue liberada tras detenerse, recargar la pista desde almacenamiento local
    if (!audioObjectUrlRef.current && currentTrack) {
      void playTrack(currentTrack, false);
      return;
    }
    if (el.paused) {
      if (useDspPipelineRef.current) audioEngine.resume();
      shouldBePlayingRef.current = true;
      el.play()
        .then(() => {
          setIsMusicPlaying(true);
          persistPlaybackSessionRef.current(true);
        })
        .catch(() => {});
    } else {
      shouldBePlayingRef.current = false;
      el.pause();
      audioEngine.suspendIdle();
      setIsMusicPlaying(false);
      persistPlaybackSessionRef.current(false);
    }
  }, [currentTrackId, currentTrack, playTrack]);

  const handleNextTrack = useCallback(() => {
    const nextTrack = resolveNextTrack(false);
    if (!nextTrack) return;
    if (nextTrack.id === currentTrackId && audioRef.current) {
      shouldBePlayingRef.current = true;
      audioRef.current.currentTime = 0;
      audioEngine.resume();
      void audioRef.current.play().then(() => setIsMusicPlaying(true)).catch(() => {});
      return;
    }
    void playTrack(nextTrack, false);
  }, [resolveNextTrack, currentTrackId, playTrack]);

  const handlePrevTrack = useCallback(() => {
    if (tracks.length === 0) return;
    if (audioRef.current && audioRef.current.currentTime > 3) {
      audioRef.current.currentTime = 0;
      return;
    }
    const idx = tracks.findIndex((t) => t.id === currentTrackId);
    const prevIdx = idx <= 0 ? tracks.length - 1 : idx - 1;
    void playTrack(tracks[prevIdx], false);
  }, [tracks, currentTrackId, playTrack]);

  const handleMusicEnded = useCallback(() => {
    const el = audioRef.current;
    if (repeatMode === 'pista' && el) {
      shouldBePlayingRef.current = true;
      el.currentTime = 0;
      audioEngine.resume();
      void el.play().then(() => setIsMusicPlaying(true)).catch(() => {});
      return;
    }

    const nextTrack = resolveNextTrack(true);
    if (!nextTrack) {
      shouldBePlayingRef.current = false;
      setIsMusicPlaying(false);
      releaseAudioUrl();
      persistPlaybackSessionRef.current(false);
      return;
    }

    if (nextTrack.id === currentTrackId && el) {
      shouldBePlayingRef.current = true;
      el.currentTime = 0;
      audioEngine.resume();
      void el.play().then(() => setIsMusicPlaying(true)).catch(() => {});
      return;
    }

    void playTrack(nextTrack, false);
  }, [repeatMode, resolveNextTrack, currentTrackId, playTrack, releaseAudioUrl]);

  // Refs siempre frescos para callbacks nativos (<audio>, MediaSession y notificación Android)
  const handleMusicEndedRef = useRef(handleMusicEnded);
  handleMusicEndedRef.current = handleMusicEnded;
  const handleNextTrackRef = useRef(handleNextTrack);
  handleNextTrackRef.current = handleNextTrack;
  const handlePrevTrackRef = useRef(handlePrevTrack);
  handlePrevTrackRef.current = handlePrevTrack;
  const playTrackRef = useRef(playTrack);
  playTrackRef.current = playTrack;
  const currentTrackRef = useRef(currentTrack);
  currentTrackRef.current = currentTrack;
  const isMusicPlayingRef = useRef(isMusicPlaying);
  isMusicPlayingRef.current = isMusicPlaying;
  const audioDurationRef = useRef(audioDuration);
  audioDurationRef.current = audioDuration;
  const playbackRateRef = useRef(playbackRate);
  playbackRateRef.current = playbackRate;
  const notifPermRequestedRef = useRef(false);
  const hasStartedMediaNotifRef = useRef(false);

  const activeSectionRef = useRef(activeSection);
  activeSectionRef.current = activeSection;
  const showAndroidFolderModalRef = useRef(showAndroidFolderModal);
  showAndroidFolderModalRef.current = showAndroidFolderModal;
  const showStorageModalRef = useRef(showStorageModal);
  showStorageModalRef.current = showStorageModal;
  const activeVideoRef = useRef(activeVideo);
  activeVideoRef.current = activeVideo;
  const handleSelectSectionRef = useRef(handleSelectSection);
  handleSelectSectionRef.current = handleSelectSection;

  // Manejo del botón Atrás del sistema (Android APK y PWA) sin cancelar la música
  useEffect(() => {
    const handleBackAction = (): 'handled' | 'background' | 'exit' => {
      if (showAndroidFolderModalRef.current) {
        setShowAndroidFolderModal(false);
        return 'handled';
      }
      if (showStorageModalRef.current) {
        setShowStorageModal(false);
        return 'handled';
      }

      const ev = new CustomEvent('huyin-back-press', { cancelable: true });
      window.dispatchEvent(ev);
      if (ev.defaultPrevented) {
        return 'handled';
      }

      if (activeSectionRef.current !== 'musica') {
        handleSelectSectionRef.current('musica');
        return 'handled';
      }

      if (
        shouldBePlayingRef.current ||
        isMusicPlayingRef.current ||
        Boolean(activeVideoRef.current)
      ) {
        return 'background';
      }

      return 'exit';
    };

    const win = window as unknown as {
      __huyinHandleBackPress?: () => 'handled' | 'background' | 'exit';
    };
    win.__huyinHandleBackPress = handleBackAction;

    // Respaldo para navegador / acceso directo PWA (fuera de APK nativo)
    const onPopState = () => {
      if (isCapacitorNative()) return;
      const result = handleBackAction();
      if (result === 'handled' || result === 'background') {
        try {
          window.history.pushState({ huyinBackGuard: true }, '');
        } catch {
          // Ignorar
        }
      }
    };

    if (!isCapacitorNative()) {
      try {
        if (!window.history.state?.huyinBackGuard) {
          window.history.pushState({ huyinBackGuard: true }, '');
        }
      } catch {
        // Ignorar
      }
      window.addEventListener('popstate', onPopState);
    }

    return () => {
      delete win.__huyinHandleBackPress;
      window.removeEventListener('popstate', onPopState);
    };
  }, []);

  // Escuchar botones de la notificación / pantalla de bloqueo en Android APK
  useEffect(() => {
    if (!isNativeAndroidMediaAvailable()) return;
    return addNativeMediaControlListener(({ action, positionSec }) => {
      const el = audioRef.current;
      const track = currentTrackRef.current;

      if (action === 'next') {
        handleNextTrackRef.current();
        return;
      }
      if (action === 'prev') {
        handlePrevTrackRef.current();
        return;
      }
      if (action === 'pause') {
        shouldBePlayingRef.current = false;
        if (el) el.pause();
        audioEngine.suspendIdle();
        setIsMusicPlaying(false);
        persistPlaybackSessionRef.current(false);
        return;
      }
      if (action === 'play') {
        if (!track) return;
        shouldBePlayingRef.current = true;
        audioEngine.resume();
        if (!audioObjectUrlRef.current || !el) {
          void playTrackRef.current(track, false);
        } else {
          void el
            .play()
            .then(() => {
              setIsMusicPlaying(true);
              persistPlaybackSessionRef.current(true);
            })
            .catch(() => {});
        }
        return;
      }
      if (action === 'seek' && typeof positionSec === 'number' && el) {
        el.currentTime = positionSec;
        persistPlaybackSessionRef.current();
        if (track) {
          void updateNativeMediaNotification({
            title: track.title,
            artist: track.artist || '琥音Hǔyīn',
            album: 'Biblioteca local · 琥音Hǔyīn',
            isPlaying: isMusicPlayingRef.current,
            durationSec: audioDurationRef.current || track.duration || 0,
            positionSec,
            playbackRate: playbackRateRef.current,
          });
        }
      }
    });
  }, []);

  // Sincronizar notificación multimedia y pantalla de bloqueo en Android APK
  useEffect(() => {
    if (!isNativeAndroidMediaAvailable()) return;

    if (!currentTrack || activeVideo) {
      hasStartedMediaNotifRef.current = false;
      void clearNativeMediaNotification();
      return;
    }

    if (isMusicPlaying) {
      hasStartedMediaNotifRef.current = true;
    } else if (!hasStartedMediaNotifRef.current) {
      return;
    }

    const payload = {
      title: currentTrack.title,
      artist: currentTrack.artist || '琥音Hǔyīn',
      album: 'Biblioteca local · 琥音Hǔyīn',
      isPlaying: isMusicPlaying,
      durationSec: audioDuration || currentTrack.duration || 0,
      positionSec: audioRef.current?.currentTime || 0,
      playbackRate,
    };

    if (isMusicPlaying && !notifPermRequestedRef.current) {
      notifPermRequestedRef.current = true;
      void ensureNativeNotificationPermission().then(() => {
        void updateNativeMediaNotification(payload);
      });
    } else {
      void updateNativeMediaNotification(payload);
    }
  }, [currentTrack, isMusicPlaying, audioDuration, playbackRate, activeVideo]);

  // Integración MediaSession para pantalla bloqueada y continuidad en segundo plano (Android/iOS)
  useEffect(() => {
    if (typeof navigator === 'undefined' || !('mediaSession' in navigator)) return;
    const ms = navigator.mediaSession;

    if (!currentTrack) {
      ms.metadata = null;
      ms.playbackState = 'none';
      return;
    }

    try {
      ms.metadata = new MediaMetadata({
        title: currentTrack.title,
        artist: currentTrack.artist || '琥音Hǔyīn',
        album: 'Biblioteca local · 琥音Hǔyīn',
        artwork: [
          { src: '/pwa-192x192.png', sizes: '192x192', type: 'image/png' },
          { src: '/pwa-512x512.png', sizes: '512x512', type: 'image/png' },
        ],
      });
    } catch {
      // Ignorar si MediaMetadata no está soportado
    }

    ms.playbackState = isMusicPlaying ? 'playing' : 'paused';

    const safeSetHandler = (
      action: MediaSessionAction,
      handler: MediaSessionActionHandler | null
    ) => {
      try {
        ms.setActionHandler(action, handler);
      } catch {
        // Acción no soportada por el navegador
      }
    };

    safeSetHandler('play', () => {
      const el = audioRef.current;
      if (!el) return;
      shouldBePlayingRef.current = true;
      audioEngine.resume();
      if (!audioObjectUrlRef.current && currentTrack) {
        void playTrack(currentTrack, false);
      } else {
        void el.play().then(() => {
          setIsMusicPlaying(true);
          persistPlaybackSessionRef.current(true);
        }).catch(() => {});
      }
    });
    safeSetHandler('pause', () => {
      const el = audioRef.current;
      if (!el) return;
      shouldBePlayingRef.current = false;
      el.pause();
      setIsMusicPlaying(false);
      persistPlaybackSessionRef.current(false);
    });
    safeSetHandler('previoustrack', () => handlePrevTrackRef.current());
    safeSetHandler('nexttrack', () => handleNextTrackRef.current());
    safeSetHandler('seekto', (details) => {
      if (audioRef.current && typeof details.seekTime === 'number') {
        audioRef.current.currentTime = details.seekTime;
        persistPlaybackSessionRef.current();
      }
    });
  }, [currentTrack, isMusicPlaying, playTrack]);

  // Abrir video de inmediato con carga ágil y limpieza automática de URLs previas
  const openVideo = useCallback(
    async (video: MediaItem) => {
      const loadToken = ++videoLoadTokenRef.current;

      // Liberar inmediatamente la reproducción musical y cualquier URL de video previo
      shouldBePlayingRef.current = false;
      audioLoadTokenRef.current++;
      releaseAudioUrl();
      setIsMusicPlaying(false);
      persistPlaybackSessionRef.current(false);
      releaseVideoUrl();

      setActiveVideo(video);
      setActiveVideoUrl(null);

      const url = await resolveMediaPlayableUrl(video);
      if (loadToken !== videoLoadTokenRef.current) {
        safeRevokeObjectUrl(url);
        return;
      }
      if (!url) {
        setActiveVideo(null);
        showToast('No se pudo cargar el archivo de video local');
        return;
      }
      videoObjectUrlRef.current = url;
      setActiveVideoUrl(url);
    },
    [releaseAudioUrl, releaseVideoUrl, showToast]
  );

  const closeVideo = useCallback(() => {
    videoLoadTokenRef.current++;
    releaseVideoUrl();
    setActiveVideo(null);
    setActiveVideoUrl(null);
  }, [releaseVideoUrl]);

  const handleAttachSubtitles = useCallback(
    async (videoId: string, subtitleName: string, subtitleRaw: string) => {
      const target = mediaItems.find((item) => item.id === videoId);
      if (!target) return;
      const updated: MediaItem = { ...target, subtitleName, subtitleRaw };
      await updateMediaItemMetadata(updated);
      setMediaItems((prev) => prev.map((it) => (it.id === videoId ? updated : it)));
      setActiveVideo((prev) => (prev && prev.id === videoId ? updated : prev));
      showToast(`Subtítulos cargados: ${subtitleName}`);
    },
    [mediaItems, showToast]
  );

  const handleDeleteItem = useCallback(
    async (id: string) => {
      await deleteMediaItem(id);
      setMediaItems((prev) => prev.filter((it) => it.id !== id));
      if (currentTrackId === id) {
        shouldBePlayingRef.current = false;
        releaseAudioUrl();
        setCurrentTrackId(null);
        setIsMusicPlaying(false);
        setIsNowPlayingOpen(false);
        persistPlaybackSessionRef.current(false);
      }
      if (activeVideo?.id === id) {
        closeVideo();
      }
    },
    [currentTrackId, activeVideo, releaseAudioUrl, closeVideo]
  );

  const handleClearLibrary = useCallback(async () => {
    await clearAllMediaLibrary();
    setMediaItems([]);
    shouldBePlayingRef.current = false;
    releaseAudioUrl();
    closeVideo();
    setCurrentTrackId(null);
    setIsMusicPlaying(false);
    setIsNowPlayingOpen(false);
    persistPlaybackSessionRef.current(false);
    showToast('Biblioteca local vaciada');
  }, [releaseAudioUrl, closeVideo, showToast]);

  return (
    <div
      onDragOver={(e) => {
        e.preventDefault();
        setIsDraggingFiles(true);
      }}
      onDragLeave={(e) => {
        if (e.currentTarget === e.target) setIsDraggingFiles(false);
      }}
      onDrop={(e) => {
        e.preventDefault();
        setIsDraggingFiles(false);
        const files = Array.from(e.dataTransfer.files);
        void importFiles(files);
      }}
      className="min-h-screen flex flex-col pb-[calc(7rem+env(safe-area-inset-bottom))] md:pb-20 transition-colors duration-200"
      style={{ backgroundColor: 'var(--bg-canvas)', color: 'var(--text-primary)' }}
    >
      {/* Elemento de audio global (ruta hardware nativa por defecto; DSP bajo demanda) */}
      <audio
        key={audioSlotKey}
        ref={setAudioNode}
        preload="auto"
        onLoadedMetadata={(e) => setAudioDuration(e.currentTarget.duration || 0)}
        onTimeUpdate={() => {
          if (document.visibilityState !== 'visible') return;
          const now = Date.now();
          if (now - lastSavedTickRef.current >= 6000) {
            lastSavedTickRef.current = now;
            persistPlaybackSessionRef.current();
          }
        }}
        onPlay={() => {
          isTransitioningAudioRef.current = false;
          setIsMusicPlaying(true);
        }}
        onPause={(e) => {
          if (!isTransitioningAudioRef.current && !e.currentTarget.ended) {
            setIsMusicPlaying(false);
            persistPlaybackSessionRef.current();
          }
        }}
        onEnded={() => handleMusicEndedRef.current()}
        onError={() => {
          isTransitioningAudioRef.current = false;
          if (audioObjectUrlRef.current) {
            showToast('No se pudo reproducir este archivo de audio');
          }
        }}
        className="hidden"
      />

      {/* Input oculto de selección múltiple */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept={
          isCapacitorNative()
            ? '*/*'
            : 'audio/*,video/*,.mkv,.flac,.aac,.opus,.ogg,.m4a,.m4v,.avi,.mov,.srt,.vtt,.ass,.ssa'
        }
        onChange={(e) => {
          const files = Array.from(e.target.files || []);
          void importFiles(files);
          e.target.value = '';
        }}
        className="hidden"
      />

      {/* Input oculto de carpeta completa (respaldo webkitdirectory en navegadores) */}
      <input
        ref={folderInputRef}
        type="file"
        multiple
        onChange={(e) => {
          const files = Array.from(e.target.files || []);
          void importFiles(files);
          e.target.value = '';
        }}
        className="hidden"
      />

      <TopBar
        activeSection={activeSection}
        onSelectSection={handleSelectSection}
        onAddFiles={handleSmartAddFiles}
        musicCount={tracks.length}
        videoCount={videos.length}
      />

      {/* Aviso discreto de instalación directa en tu menú (solo cuando está disponible) */}
      {isInstallable && !isInstalled && !dismissedInstallBanner && (
        <div
          className="border-b px-4 py-2 text-xs"
          style={{
            backgroundColor: 'var(--bg-surface)',
            borderColor: 'var(--border-subtle)',
          }}
        >
          <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 sm:px-2 lg:px-4">
            <div className="flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
              <Download className="h-3.5 w-3.5" style={{ color: 'var(--accent)' }} aria-hidden="true" />
              <span>Añade 琥音Hǔyīn a tu menú de aplicaciones para abrirla directo sin navegador.</span>
            </div>

            <div className="flex items-center gap-2 ml-auto">
              <button
                type="button"
                onClick={() => void install()}
                className="min-h-[34px] rounded-lg px-3 py-1 text-xs font-semibold cursor-pointer"
                style={{
                  backgroundColor: 'var(--accent)',
                  color: 'var(--accent-contrast)',
                }}
              >
                Instalar en mi menú
              </button>
              <button
                type="button"
                onClick={() => setDismissedInstallBanner(true)}
                aria-label="Ocultar aviso de instalación"
                className="flex h-8 w-8 items-center justify-center rounded-lg cursor-pointer"
                style={{ color: 'var(--text-secondary)' }}
              >
                <X className="h-3.5 w-3.5" aria-hidden="true" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Contenido principal con transición fluida entre Música, Video y Ajustes */}
      <main className="flex-1 overflow-x-hidden">
        {isLoadingLibrary ? (
          <div className="mx-auto max-w-7xl px-6 py-16 text-center text-sm" style={{ color: 'var(--text-secondary)' }}>
            Cargando tu biblioteca local...
          </div>
        ) : (
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={activeSection}
              initial={{ opacity: 0, x: navDirection * 24 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: navDirection * -24 }}
              transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            >
              {activeSection === 'musica' && (
                <MusicSection
                  tracks={tracks}
                  currentTrackId={currentTrackId}
                  isPlaying={isMusicPlaying}
                  onSelectTrack={(track) => void playTrack(track, true)}
                  onTogglePlay={toggleMusicPlay}
                  onDeleteTrack={(id) => void handleDeleteItem(id)}
                  onAddFiles={handleSmartAddFiles}
                  onOpenFolder={() => void handleOpenFolder()}
                  onGenerateDemo={() => void handleGenerateDemo()}
                  isGeneratingDemo={isGeneratingDemo}
                  supportsFolderPicker={supportsFolderPicker}
                />
              )}

              {activeSection === 'video' && (
                <VideoSection
                  videos={videos}
                  onSelectVideo={(video) => void openVideo(video)}
                  onDeleteVideo={(id) => void handleDeleteItem(id)}
                  onAddFiles={handleSmartAddFiles}
                  onOpenFolder={() => void handleOpenFolder()}
                  onGenerateDemo={() => void handleGenerateDemo()}
                  isGeneratingDemo={isGeneratingDemo}
                  supportsFolderPicker={supportsFolderPicker}
                />
              )}

              {activeSection === 'ajustes' && (
                <SettingsSection
                  settings={settings}
                  musicCount={tracks.length}
                  videoCount={videos.length}
                  totalBytes={totalBytes}
                  internalBlobBytes={internalBlobBytes}
                  storageStatus={storageStatus}
                  savedFolders={savedFolders}
                  isScanningFolders={isScanningFolders}
                  onRequestStoragePermission={() => setShowStorageModal(true)}
                  onRescanFolders={() => void handleRescanFolders()}
                  onRemoveFolder={(id) => void handleRemoveFolder(id)}
                  onUpdateSettings={setSettings}
                  onClearLibrary={() => void handleClearLibrary()}
                />
              )}
            </motion.div>
          </AnimatePresence>
        )}
      </main>

      {/* Minirreproductor cuando hay música activa y la vista expandida está cerrada */}
      <AnimatePresence>
        {currentTrack && !isNowPlayingOpen && !activeVideo && (
          <MiniPlayer
            track={currentTrack}
            audioEl={audioElement}
            isPlaying={isMusicPlaying}
            duration={audioDuration}
            onExpand={() => setIsNowPlayingOpen(true)}
            onTogglePlay={toggleMusicPlay}
            onPrev={handlePrevTrack}
            onNext={handleNextTrack}
          />
        )}
      </AnimatePresence>

      {/* Vista expandida animada de música con fondo incorporado */}
      <AnimatePresence>
        {currentTrack && isNowPlayingOpen && (
          <MusicNowPlaying
            track={currentTrack}
            audioEl={audioElement}
            isPlaying={isMusicPlaying}
            duration={audioDuration}
            playbackRate={playbackRate}
            repeatMode={repeatMode}
            sleepTimerMinutes={sleepTimerMinutes}
            backdropId={settings.backdrop}
            headphoneMode={settings.headphoneMode}
            batterySaverEnabled={settings.batterySaverEnabled}
            onClose={() => setIsNowPlayingOpen(false)}
            onTogglePlay={toggleMusicPlay}
            onPrev={handlePrevTrack}
            onNext={handleNextTrack}
            onSeek={(t) => {
              if (audioRef.current) audioRef.current.currentTime = t;
              if (isNativeAndroidMediaAvailable() && currentTrack) {
                void updateNativeMediaNotification({
                  title: currentTrack.title,
                  artist: currentTrack.artist || '琥音Hǔyīn',
                  album: 'Biblioteca local · 琥音Hǔyīn',
                  isPlaying: isMusicPlaying,
                  durationSec: audioDuration || currentTrack.duration || 0,
                  positionSec: t,
                  playbackRate,
                });
              }
            }}
            onCycleSpeed={() => {
              const speeds = [0.75, 1, 1.25, 1.5, 2];
              const next = speeds[(speeds.indexOf(playbackRate) + 1) % speeds.length];
              setPlaybackRate(next);
              if (audioRef.current) audioRef.current.playbackRate = next;
            }}
            onToggleRepeatList={() => {
              const next: RepeatMode = repeatMode === 'lista' ? 'ninguno' : 'lista';
              setRepeatMode(next);
              showToast(
                next === 'lista'
                  ? 'Repetir toda la música en bucle'
                  : 'Reproducción hasta el final de la lista'
              );
            }}
            onToggleRepeatOne={() => {
              const next: RepeatMode = repeatMode === 'pista' ? 'lista' : 'pista';
              setRepeatMode(next);
              showToast(
                next === 'pista'
                  ? 'Repetir esta canción en modo circular'
                  : 'Repetir toda la lista'
              );
            }}
            onSelectSleepTimer={setSleepTimerMinutes}
            onSelectHeadphoneMode={(mode) =>
              setSettings((prev) => ({ ...prev, headphoneMode: mode }))
            }
            onOpenEqualizer={() => {
              setIsNowPlayingOpen(false);
              handleSelectSection('ajustes');
            }}
          />
        )}
      </AnimatePresence>

      {/* Reproductor de video dedicado con subtítulos */}
      <AnimatePresence>
        {activeVideo && (
          <VideoPlayerModal
            video={activeVideo}
            videoUrl={activeVideoUrl}
            subtitleStyle={settings.subtitleStyle}
            batterySaverEnabled={settings.batterySaverEnabled}
            onUpdateSubtitleStyle={(style) =>
              setSettings((prev) => ({ ...prev, subtitleStyle: style }))
            }
            onAttachSubtitles={(id, name, raw) => void handleAttachSubtitles(id, name, raw)}
            onOpenAudioSettings={() => handleSelectSection('ajustes')}
            onClose={closeVideo}
          />
        )}
      </AnimatePresence>

      {/* Zona de arrastre visual */}
      <AnimatePresence>
        {isDraggingFiles && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-6"
          >
            <div
              className="flex max-w-md flex-col items-center rounded-3xl border-2 border-dashed p-10 text-center"
              style={{
                borderColor: 'var(--accent)',
                backgroundColor: 'var(--bg-surface)',
              }}
            >
              <Upload className="h-10 w-10 mb-3" style={{ color: 'var(--accent)' }} aria-hidden="true" />
              <p className="font-display text-lg font-bold" style={{ color: 'var(--text-primary)' }}>
                Suelta tus archivos aquí
              </p>
              <p className="mt-1 text-sm" style={{ color: 'var(--text-secondary)' }}>
                Música, videos y subtítulos (.srt, .vtt, .ass) se añadirán a tu biblioteca local.
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Modal de permiso de almacenamiento local */}
      <StoragePermissionModal
        isOpen={showStorageModal}
        supportsFolderPicker={supportsFolderPicker}
        isPersisted={storageStatus.persisted}
        onGrantAndOpenFolder={() => void handleOpenFolder()}
        onGrantAndSelectFiles={() => void handleGrantAndSelectFiles()}
        onRequestStorageOnly={() => void handleRequestStorageOnly()}
        onDismiss={() => {
          markStoragePromptSeen();
          setShowStorageModal(false);
        }}
      />

      {/* Explorador nativo de carpetas y archivos sin copiar en Android APK */}
      <AndroidFolderModal
        isOpen={showAndroidFolderModal}
        onClose={() => setShowAndroidFolderModal(false)}
        onSelectFolder={(folderPath, folderName) =>
          void handleImportNativeFolder(folderPath, folderName)
        }
        onSelectFiles={(files, folderName) =>
          void handleImportNativeFiles(files, folderName)
        }
        onFallbackFilePicker={() => {
          setShowAndroidFolderModal(false);
          fileInputRef.current?.click();
        }}
      />

      {/* Notificación breve de estado de importación */}
      <AnimatePresence>
        {(toastMessage || isImporting) && (
          <motion.div
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            className="fixed right-4 z-50 rounded-xl border px-4 py-2.5 text-xs font-medium shadow-xl backdrop-blur-md"
            style={{
              top: 'calc(4rem + env(safe-area-inset-top))',
              backgroundColor: 'var(--bg-elevated)',
              borderColor: 'var(--border-subtle)',
              color: 'var(--text-primary)',
            }}
          >
            {isImporting
              ? importProgress
                ? `Cargando archivos (${importProgress.done}/${importProgress.total})...`
                : 'Cargando archivos locales...'
              : toastMessage}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
