from pathlib import Path
import shutil

manifest_path = Path("android/app/src/main/AndroidManifest.xml")
manifest = manifest_path.read_text(encoding="utf-8")

perms = [
    '    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />',
    '    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />',
    '    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />',
]
missing = [p for p in perms if p.split('"')[1] not in manifest]
if missing:
    manifest = manifest.replace("<application", "\n".join(missing) + "\n\n    <application", 1)

if 'android:requestLegacyExternalStorage="true"' not in manifest:
    manifest = manifest.replace("<application", '<application android:requestLegacyExternalStorage="true"', 1)

if 'android:hardwareAccelerated="true"' not in manifest:
    manifest = manifest.replace("<application", '<application android:hardwareAccelerated="true"', 1)

native_activity_xml = (
    '        <activity\n'
    '            android:name="com.huyin.reproductor.NativeVideoActivity"\n'
    '            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|smallestScreenSize|screenLayout"\n'
    '            android:exported="false"\n'
    '            android:hardwareAccelerated="true"\n'
    '            android:theme="@style/AppTheme.NoActionBar" />\n'
)
if "com.huyin.reproductor.NativeVideoActivity" not in manifest:
    manifest = manifest.replace("</application>", native_activity_xml + "    </application>", 1)

manifest_path.write_text(manifest, encoding="utf-8")

java_dir = Path("android/app/src/main/java/com/huyin/reproductor")
java_dir.mkdir(parents=True, exist_ok=True)
shutil.copy2("android-native/LocalMediaPlugin.java", java_dir / "LocalMediaPlugin.java")
shutil.copy2("android-native/MainActivity.java", java_dir / "MainActivity.java")
shutil.copy2("android-native/NativeVideoActivity.java", java_dir / "NativeVideoActivity.java")

icon_src = Path("public/pwa-512x512.png")
if icon_src.exists():
    anydpi = Path("android/app/src/main/res/mipmap-anydpi-v26")
    if anydpi.exists():
        shutil.rmtree(anydpi)
    for density in ("mipmap-mdpi", "mipmap-hdpi", "mipmap-xhdpi", "mipmap-xxhdpi", "mipmap-xxxhdpi"):
        target_dir = Path("android/app/src/main/res") / density
        if target_dir.exists():
            shutil.copy2(icon_src, target_dir / "ic_launcher.png")
            shutil.copy2(icon_src, target_dir / "ic_launcher_round.png")

print("Android native setup completed.")
