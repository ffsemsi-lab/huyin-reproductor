import { FolderOpen, HardDrive, Music, ShieldCheck, X } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';

interface StoragePermissionModalProps {
  isOpen: boolean;
  supportsFolderPicker: boolean;
  isPersisted: boolean;
  onGrantAndOpenFolder: () => void;
  onGrantAndSelectFiles: () => void;
  onRequestStorageOnly: () => void;
  onDismiss: () => void;
}

export function StoragePermissionModal({
  isOpen,
  supportsFolderPicker,
  isPersisted,
  onGrantAndOpenFolder,
  onGrantAndSelectFiles,
  onRequestStorageOnly,
  onDismiss,
}: StoragePermissionModalProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-label="Permiso de almacenamiento local"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 12 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="w-full max-w-md rounded-2xl border p-6 shadow-2xl"
            style={{
              backgroundColor: 'var(--bg-surface)',
              borderColor: 'var(--border-subtle)',
              color: 'var(--text-primary)',
            }}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl"
                  style={{ backgroundColor: 'var(--accent-soft)', color: 'var(--accent)' }}
                >
                  <HardDrive className="h-5 w-5" aria-hidden="true" />
                </div>
                <div>
                  <h2 className="font-display text-lg font-bold leading-tight">
                    Permiso de almacenamiento
                  </h2>
                  <p className="mt-0.5 text-xs" style={{ color: 'var(--text-secondary)' }}>
                    Acceso local para música y videos
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={onDismiss}
                aria-label="Cerrar aviso de permiso"
                className="flex h-9 w-9 items-center justify-center rounded-xl hover:bg-white/10 cursor-pointer"
                style={{ color: 'var(--text-secondary)' }}
              >
                <X className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>

            <p className="mt-4 text-sm leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
              Para leer cualquier canción o video de tu dispositivo sin conexión y proteger tu biblioteca contra borrados automáticos, concede acceso a tu almacenamiento local.
            </p>

            <div
              className="mt-4 flex items-center gap-2.5 rounded-xl border px-3.5 py-2.5 text-xs"
              style={{
                backgroundColor: 'var(--bg-elevated)',
                borderColor: 'var(--border-subtle)',
                color: 'var(--text-primary)',
              }}
            >
              <ShieldCheck
                className="h-4 w-4 shrink-0"
                style={{ color: isPersisted ? '#22c55e' : 'var(--accent)' }}
                aria-hidden="true"
              />
              <span>
                {isPersisted
                  ? 'Almacenamiento persistente activo en este dispositivo.'
                  : '100% privado y local: ningún archivo sale de tu dispositivo.'}
              </span>
            </div>

            <div className="mt-5 flex flex-col gap-2.5">
              {supportsFolderPicker ? (
                <>
                  <button
                    type="button"
                    onClick={onGrantAndOpenFolder}
                    className="flex min-h-[46px] w-full items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition-transform active:scale-[0.98] cursor-pointer"
                    style={{
                      backgroundColor: 'var(--accent)',
                      color: 'var(--accent-contrast)',
                    }}
                  >
                    <FolderOpen className="h-4 w-4" aria-hidden="true" />
                    <span>Permitir acceso a carpeta completa</span>
                  </button>

                  <button
                    type="button"
                    onClick={onGrantAndSelectFiles}
                    className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl border px-4 py-2 text-xs font-semibold cursor-pointer"
                    style={{
                      backgroundColor: 'var(--bg-elevated)',
                      borderColor: 'var(--border-subtle)',
                      color: 'var(--text-primary)',
                    }}
                  >
                    <Music className="h-4 w-4" style={{ color: 'var(--accent)' }} aria-hidden="true" />
                    <span>Permitir y seleccionar archivos de música/video</span>
                  </button>
                </>
              ) : (
                <button
                  type="button"
                  onClick={onGrantAndSelectFiles}
                  className="flex min-h-[46px] w-full items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition-transform active:scale-[0.98] cursor-pointer"
                  style={{
                    backgroundColor: 'var(--accent)',
                    color: 'var(--accent-contrast)',
                  }}
                >
                  <FolderOpen className="h-4 w-4" aria-hidden="true" />
                  <span>Conceder permiso y elegir archivos</span>
                </button>
              )}

              <div className="mt-1 flex items-center justify-between gap-2">
                {!isPersisted && (
                  <button
                    type="button"
                    onClick={onRequestStorageOnly}
                    className="min-h-[38px] rounded-xl px-3 py-1.5 text-xs font-medium hover:underline cursor-pointer"
                    style={{ color: 'var(--accent)' }}
                  >
                    Solo activar protección local
                  </button>
                )}
                <button
                  type="button"
                  onClick={onDismiss}
                  className="ml-auto min-h-[38px] rounded-xl px-4 py-1.5 text-xs font-medium cursor-pointer"
                  style={{ color: 'var(--text-secondary)' }}
                >
                  Ahora no
                </button>
              </div>
            </div>

            <p className="mt-3 text-[11px] leading-relaxed" style={{ color: 'var(--text-muted)' }}>
              En teléfonos Android/iOS, el navegador abrirá el selector del sistema para que elijas cualquier carpeta, música o video de tu memoria interna o tarjeta SD.
            </p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
