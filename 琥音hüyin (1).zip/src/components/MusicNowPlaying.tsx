import {
  ChevronDown,
  Clock,
  Disc3,
  Headphones,
  Pause,
  Play,
  Repeat,
  Repeat1,
  Shuffle,
  SkipBack,
  SkipForward,
  SlidersHorizontal,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useEffect, useRef, useState } from 'react';
import { BUILT_IN_BACKDROPS, HEADPHONE_MODES } from '../constants/presets';
import type { BackdropId, HeadphoneModeId, MediaItem, RepeatMode } from '../types/media';
import { audioEngine } from '../utils/audioEngine';
import { formatDuration } from '../utils/libraryDb';

interface MusicNowPlayingProps {
  track: MediaItem;
  audioEl: HTMLAudioElement | null;
  isPlaying: boolean;
  duration: number;
  playbackRate: number;
  shuffle: boolean;
  repeatMode: RepeatMode;
  sleepTimerMinutes: number | null;
  backdropId: BackdropId;
  headphoneMode: HeadphoneModeId;
  onClose: () => void;
  onTogglePlay: () => void;
  onPrev: () => void;
  onNext: () => void;
  onSeek: (time: number) => void;
  onCycleSpeed: () => void;
  onToggleShuffle: () => void;
  onCycleRepeat: () => void;
  onSelectSleepTimer: (mins: number | null) => void;
  onSelectHeadphoneMode: (mode: HeadphoneModeId) => void;
  onOpenEqualizer: () => void;
}

export function MusicNowPlaying({
  track,
  audioEl,
  isPlaying,
  duration,
  playbackRate,
  shuffle,
  repeatMode,
  sleepTimerMinutes,
  backdropId,
  headphoneMode,
  onClose,
  onTogglePlay,
  onPrev,
  onNext,
  onSeek,
  onCycleSpeed,
  onToggleShuffle,
  onCycleRepeat,
  onSelectSleepTimer,
  onSelectHeadphoneMode,
  onOpenEqualizer,
}: MusicNowPlayingProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [currentTime, setCurrentTime] = useState(() => audioEl?.currentTime || 0);
  const [showTimerMenu, setShowTimerMenu] = useState(false);
  const [showHpMenu, setShowHpMenu] = useState(false);
  const [bgFailed, setBgFailed] = useState(false);

  const backdrop =
    BUILT_IN_BACKDROPS.find((b) => b.id === backdropId) || BUILT_IN_BACKDROPS[0];

  const activeHpMode =
    HEADPHONE_MODES.find((m) => m.id === headphoneMode) || HEADPHONE_MODES[0];

  useEffect(() => {
    setBgFailed(false);
  }, [backdrop.imageUrl]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (showHpMenu || showTimerMenu) {
          setShowHpMenu(false);
          setShowTimerMenu(false);
        } else {
          onClose();
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose, showHpMenu, showTimerMenu]);

  // Escucha local del progreso para no re-renderizar toda la app en cada tick
  useEffect(() => {
    if (!audioEl) return;
    setCurrentTime(audioEl.currentTime || 0);
    const onTimeUpdate = () => setCurrentTime(audioEl.currentTime || 0);
    audioEl.addEventListener('timeupdate', onTimeUpdate);
    return () => audioEl.removeEventListener('timeupdate', onTimeUpdate);
  }, [audioEl, track.id]);

  // Visualizador optimizado (~24 fps): se pausa automáticamente en segundo plano para cero consumo
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const binCount = audioEngine.getBinCount();
    const data = new Uint8Array(new ArrayBuffer(binCount));
    let rafId = 0;
    let lastDraw = -100;
    let stopped = false;

    const drawFrame = (now: number) => {
      if (stopped || document.visibilityState === 'hidden') return;

      if (now - lastDraw >= 42) {
        lastDraw = now;
        const width = canvas.width;
        const height = canvas.height;
        ctx.clearRect(0, 0, width, height);

        const isDspLinked = audioEngine.hasConnectedElement(audioEl);
        const hasLiveData = isDspLinked && audioEngine.getFrequencyData(data);
        const bars = 36;
        const barWidth = Math.max(3, Math.floor((width - (bars - 1) * 4) / bars));
        const totalWidth = bars * barWidth + (bars - 1) * 4;
        const startX = (width - totalWidth) / 2;
        const phase = now * 0.004;

        for (let i = 0; i < bars; i++) {
          let rawVal = 0.08;
          if (isPlaying) {
            if (hasLiveData) {
              const sampleIdx = Math.min(binCount - 1, Math.floor((i / bars) * (binCount * 0.78)));
              rawVal = Math.max(0.08, data[sampleIdx] / 255);
            } else {
              // Onda orgánica ligera en modo nativo directo sin carga al hilo de audio
              const waveA = Math.sin(phase + i * 0.36);
              const waveB = Math.cos(phase * 1.45 - i * 0.22);
              const centerBias = 1 - Math.abs(i - bars / 2) / (bars * 0.72);
              rawVal = Math.max(0.1, Math.min(0.92, (0.42 + waveA * 0.24 + waveB * 0.18) * centerBias));
            }
          }

          const barHeight = Math.max(4, rawVal * (height - 8));
          const x = startX + i * (barWidth + 4);
          const y = height - barHeight;

          ctx.fillStyle = isPlaying
            ? `rgba(245, 158, 11, ${0.38 + rawVal * 0.58})`
            : 'rgba(255, 255, 255, 0.18)';
          ctx.beginPath();
          ctx.roundRect(x, y, barWidth, barHeight, 3);
          ctx.fill();
        }
      }

      if (isPlaying) {
        rafId = requestAnimationFrame(drawFrame);
      }
    };

    const handleVisibility = () => {
      if (document.visibilityState === 'visible' && isPlaying && !stopped) {
        rafId = requestAnimationFrame(drawFrame);
      } else {
        cancelAnimationFrame(rafId);
      }
    };

    document.addEventListener('visibilitychange', handleVisibility);
    rafId = requestAnimationFrame(drawFrame);

    return () => {
      stopped = true;
      document.removeEventListener('visibilitychange', handleVisibility);
      cancelAnimationFrame(rafId);
    };
  }, [isPlaying, audioEl]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 28 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 28 }}
      transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
      onClick={() => {
        if (showHpMenu) setShowHpMenu(false);
        if (showTimerMenu) setShowTimerMenu(false);
      }}
      className="fixed inset-0 z-50 flex flex-col overflow-y-auto bg-neutral-950 text-white"
      role="dialog"
      aria-modal="true"
      aria-label={`Reproduciendo ${track.title}`}
    >
      {/* Fondo incorporado estático ligero (sin repintado continuo en móvil) */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        {!bgFailed ? (
          <motion.img
            key={backdrop.imageUrl}
            src={backdrop.imageUrl}
            alt={backdrop.name}
            referrerPolicy="no-referrer"
            onError={() => setBgFailed(true)}
            initial={{ opacity: 0, scale: 1.04 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="h-full w-full bg-gradient-to-br from-neutral-900 via-stone-950 to-black" />
        )}
        <div className="absolute inset-0 bg-gradient-to-b from-black/75 via-black/55 to-black/92" />
      </div>

      {/* Cabecera superior */}
      <div className="relative z-10 mx-auto flex w-full max-w-5xl items-center justify-between px-4 sm:px-6 pt-4 pb-2">
        <button
          type="button"
          onClick={onClose}
          className="flex min-h-[44px] min-w-[44px] items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-white/85 hover:bg-white/10 transition-colors cursor-pointer"
          aria-label="Minimizar reproductor"
        >
          <ChevronDown className="h-5 w-5" aria-hidden="true" />
          <span className="hidden sm:inline">Volver a biblioteca</span>
        </button>

        <div className="text-center">
          <p className="text-xs font-medium text-white/65">Reproduciendo ahora</p>
          <p className="text-xs text-amber-300/90 mt-0.5">{backdrop.name}</p>
        </div>

        <button
          type="button"
          onClick={onOpenEqualizer}
          className="flex min-h-[44px] items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-medium text-white/90 bg-white/10 hover:bg-white/15 transition-colors cursor-pointer whitespace-nowrap"
        >
          <SlidersHorizontal className="h-4 w-4 text-amber-400" aria-hidden="true" />
          <span>Ecualizador</span>
        </button>
      </div>

      {/* Contenido central */}
      <div className="relative z-10 mx-auto flex w-full max-w-4xl flex-1 flex-col items-center justify-center px-5 pt-2 pb-8">
        {/* Disco giratorio */}
        <motion.div
          initial={{ scale: 0.92, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className="relative flex items-center justify-center"
        >
          <div
            className={`relative flex h-44 w-44 sm:h-60 sm:w-60 items-center justify-center rounded-full border border-white/15 bg-gradient-to-br from-neutral-800/90 via-neutral-900/95 to-black shadow-2xl ${
              isPlaying ? 'animate-vinyl' : 'animate-vinyl-paused'
            }`}
          >
            <div className="absolute inset-4 rounded-full border border-white/10" />
            <div className="absolute inset-8 rounded-full border border-white/10" />
            <div className="absolute inset-12 rounded-full border border-white/5" />
            <div className="flex h-16 w-16 sm:h-20 sm:w-20 items-center justify-center rounded-full bg-amber-500/20 border border-amber-400/40">
              <Disc3 className="h-8 w-8 sm:h-9 sm:w-9 text-amber-400" aria-hidden="true" />
            </div>
          </div>
        </motion.div>

        {/* Visualizador de espectro */}
        <canvas
          ref={canvasRef}
          width={380}
          height={48}
          className="mt-5 h-11 w-full max-w-md opacity-90"
          aria-hidden="true"
        />

        {/* Título y metadatos */}
        <div className="mt-3 w-full max-w-xl text-center">
          <h2 className="font-display truncate text-xl sm:text-3xl font-bold tracking-tight text-white">
            {track.title}
          </h2>
          <p className="mt-1 text-xs sm:text-base text-white/75">
            {track.artist}
            <span className="mx-2 text-white/40" aria-hidden="true">·</span>
            <span className="uppercase">{track.format}</span>
            <span className="mx-2 text-white/40" aria-hidden="true">·</span>
            <span>{activeHpMode.name}</span>
          </p>
        </div>

        {/* Barra de progreso */}
        <div className="mt-5 w-full max-w-xl">
          <input
            type="range"
            min={0}
            max={Math.max(1, duration || track.duration || 1)}
            step={0.2}
            value={Math.min(currentTime, Math.max(1, duration || track.duration || 1))}
            onChange={(e) => {
              const val = Number(e.target.value);
              setCurrentTime(val);
              onSeek(val);
            }}
            aria-label="Progreso de la canción"
            className="visha-range w-full"
          />
          <div className="font-mono-tabular mt-1.5 flex items-center justify-between text-xs text-white/70">
            <span>{formatDuration(currentTime)}</span>
            <span>{formatDuration(duration || track.duration)}</span>
          </div>
        </div>

        {/* Controles principales */}
        <div className="mt-4 flex items-center justify-center gap-4 sm:gap-7">
          <button
            type="button"
            onClick={onToggleShuffle}
            aria-label={shuffle ? 'Desactivar aleatorio' : 'Activar aleatorio'}
            className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl transition-colors cursor-pointer"
            style={{ color: shuffle ? '#f59e0b' : 'rgba(255,255,255,0.65)' }}
          >
            <Shuffle className="h-5 w-5" aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={onPrev}
            aria-label="Canción anterior"
            className="flex min-h-[48px] min-w-[48px] items-center justify-center rounded-full text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <SkipBack className="h-6 w-6" aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={onTogglePlay}
            aria-label={isPlaying ? 'Pausar' : 'Reproducir'}
            className="flex h-15 w-15 sm:h-16 sm:w-16 items-center justify-center rounded-full bg-amber-500 text-neutral-950 shadow-lg shadow-amber-500/25 transition-transform hover:scale-105 active:scale-95 cursor-pointer"
          >
            {isPlaying ? (
              <Pause className="h-7 w-7 fill-current" aria-hidden="true" />
            ) : (
              <Play className="h-7 w-7 fill-current ml-0.5" aria-hidden="true" />
            )}
          </button>

          <button
            type="button"
            onClick={onNext}
            aria-label="Siguiente canción"
            className="flex min-h-[48px] min-w-[48px] items-center justify-center rounded-full text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <SkipForward className="h-6 w-6" aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={onCycleRepeat}
            aria-label={
              repeatMode === 'pista'
                ? 'Repetir esta canción'
                : repeatMode === 'lista'
                  ? 'Repetir toda la lista'
                  : 'Reproducir hasta el final'
            }
            title={
              repeatMode === 'pista'
                ? 'Repetir esta canción'
                : repeatMode === 'lista'
                  ? 'Repetir lista'
                  : 'Sin repetición'
            }
            className="flex min-h-[44px] min-w-[44px] flex-col items-center justify-center rounded-xl px-1.5 transition-colors cursor-pointer"
            style={{ color: repeatMode !== 'ninguno' ? '#f59e0b' : 'rgba(255,255,255,0.65)' }}
          >
            {repeatMode === 'pista' ? (
              <Repeat1 className="h-5 w-5" aria-hidden="true" />
            ) : (
              <Repeat className="h-5 w-5" aria-hidden="true" />
            )}
            <span className="mt-0.5 text-[10px] leading-none font-medium">
              {repeatMode === 'pista'
                ? '1 pista'
                : repeatMode === 'lista'
                  ? 'Lista'
                  : 'Normal'}
            </span>
          </button>
        </div>

        {/* Barra de herramientas inferior (sin volumen en pantalla: control por botones + / - del móvil) */}
        <div
          onClick={(e) => e.stopPropagation()}
          className="mt-5 flex w-full max-w-xl items-center justify-around gap-2 rounded-2xl border border-white/10 bg-black/55 px-4 py-2"
        >
          <button
            type="button"
            onClick={onCycleSpeed}
            className="font-mono-tabular min-h-[40px] rounded-xl px-3 py-1.5 text-xs font-medium text-white/85 hover:bg-white/10 transition-colors cursor-pointer"
            title="Velocidad de reproducción"
          >
            {playbackRate.toFixed(2).replace(/\.00$/, '')}x
          </button>

          <div className="relative">
            <button
              type="button"
              onClick={() => {
                setShowHpMenu((v) => !v);
                setShowTimerMenu(false);
              }}
              className="flex min-h-[40px] items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-medium text-white/85 hover:bg-white/10 transition-colors cursor-pointer whitespace-nowrap"
            >
              <Headphones className="h-4 w-4 text-amber-400" aria-hidden="true" />
              <span>Auriculares</span>
            </button>

            {showHpMenu && (
              <div className="absolute left-1/2 -translate-x-1/2 bottom-12 z-20 w-64 rounded-2xl border border-white/15 bg-neutral-900 p-2 shadow-2xl">
                <p className="px-3 py-1.5 text-xs font-semibold text-white/60">
                  Modo profesional de auriculares
                </p>
                {HEADPHONE_MODES.map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => {
                      onSelectHeadphoneMode(m.id);
                      setShowHpMenu(false);
                    }}
                    className="flex w-full flex-col items-start rounded-xl px-3 py-2 text-left transition-colors hover:bg-white/10 cursor-pointer"
                    style={{
                      backgroundColor:
                        headphoneMode === m.id ? 'rgba(245, 158, 11, 0.16)' : undefined,
                    }}
                  >
                    <span className="text-xs font-semibold text-white">{m.name}</span>
                    <span className="text-[11px] text-white/60">{m.subtitle}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="relative">
            <button
              type="button"
              onClick={() => {
                setShowTimerMenu((v) => !v);
                setShowHpMenu(false);
              }}
              className="flex min-h-[40px] items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-medium transition-colors hover:bg-white/10 cursor-pointer whitespace-nowrap"
              style={{ color: sleepTimerMinutes ? '#f59e0b' : 'rgba(255,255,255,0.85)' }}
              title="Temporizador de apagado"
            >
              <Clock className="h-4 w-4" aria-hidden="true" />
              <span>{sleepTimerMinutes ? `${sleepTimerMinutes} min` : 'Temporizador'}</span>
            </button>

            {showTimerMenu && (
              <div className="absolute right-0 bottom-12 z-20 w-44 rounded-2xl border border-white/15 bg-neutral-900 p-2 shadow-2xl">
                <p className="px-3 py-1 text-xs font-semibold text-white/60">
                  Detener reproducción
                </p>
                {[null, 15, 30, 45, 60].map((mins) => (
                  <button
                    key={String(mins)}
                    type="button"
                    onClick={() => {
                      onSelectSleepTimer(mins);
                      setShowTimerMenu(false);
                    }}
                    className="flex w-full items-center justify-between rounded-xl px-3 py-2 text-xs text-white hover:bg-white/10 cursor-pointer"
                  >
                    <span>{mins === null ? 'Desactivado' : `En ${mins} minutos`}</span>
                    {sleepTimerMinutes === mins && (
                      <span className="text-amber-400 font-bold">✓</span>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
