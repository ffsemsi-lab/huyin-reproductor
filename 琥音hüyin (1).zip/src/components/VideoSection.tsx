import {
  ArrowUpDown,
  Captions,
  Film,
  FolderOpen,
  Play,
  Plus,
  Search,
  Sparkles,
  Trash2,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useMemo, useState } from 'react';
import type { MediaItem } from '../types/media';
import { formatBytes, formatDuration, formatResolutionLabel } from '../utils/libraryDb';

interface VideoSectionProps {
  videos: MediaItem[];
  onSelectVideo: (video: MediaItem) => void;
  onDeleteVideo: (id: string) => void;
  onAddFiles: () => void;
  onOpenFolder: () => void;
  onGenerateDemo: () => void;
  isGeneratingDemo: boolean;
  supportsFolderPicker: boolean;
}

type SortKey = 'recientes' | 'titulo' | 'duracion';

export function VideoSection({
  videos,
  onSelectVideo,
  onDeleteVideo,
  onAddFiles,
  onOpenFolder,
  onGenerateDemo,
  isGeneratingDemo,
  supportsFolderPicker,
}: VideoSectionProps) {
  const [query, setQuery] = useState('');
  const [sortBy, setSortBy] = useState<SortKey>('recientes');

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const base = q
      ? videos.filter(
          (v) =>
            v.title.toLowerCase().includes(q) ||
            v.format.toLowerCase().includes(q)
        )
      : [...videos];

    if (sortBy === 'titulo') {
      base.sort((a, b) => a.title.localeCompare(b.title, 'es'));
    } else if (sortBy === 'duracion') {
      base.sort((a, b) => b.duration - a.duration);
    } else {
      base.sort((a, b) => b.addedAt - a.addedAt);
    }
    return base;
  }, [videos, query, sortBy]);

  return (
    <section className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
      {/* Encabezado */}
      <div
        className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between pb-6 border-b"
        style={{ borderColor: 'var(--border-subtle)' }}
      >
        <div>
          <h1
            className="font-display text-2xl sm:text-3xl font-bold tracking-tight"
            style={{ color: 'var(--text-primary)' }}
          >
            Mis videos
          </h1>
          <p className="mt-1 text-sm" style={{ color: 'var(--text-secondary)' }}>
            {videos.length === 0
              ? 'Reproducción fluida sin conexión · MP4, WebM, MKV, MOV, M4V, OGV · Subtítulos .SRT / .VTT / .ASS'
              : `${videos.length} ${videos.length === 1 ? 'video local' : 'videos locales'} disponibles sin conexión`}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {supportsFolderPicker && (
            <button
              type="button"
              onClick={onOpenFolder}
              className="flex min-h-[42px] items-center gap-2 rounded-xl border px-4 py-2 text-sm font-medium transition-colors cursor-pointer whitespace-nowrap"
              style={{
                borderColor: 'var(--border-subtle)',
                backgroundColor: 'var(--bg-surface)',
                color: 'var(--text-primary)',
              }}
            >
              <FolderOpen className="h-4 w-4" style={{ color: 'var(--accent)' }} aria-hidden="true" />
              <span>Abrir carpeta</span>
            </button>
          )}
          <button
            type="button"
            onClick={onAddFiles}
            className="flex min-h-[42px] items-center gap-2 rounded-xl border px-4 py-2 text-sm font-medium transition-colors cursor-pointer whitespace-nowrap"
            style={{
              borderColor: 'var(--border-subtle)',
              backgroundColor: 'var(--bg-surface)',
              color: 'var(--text-primary)',
            }}
          >
            <Plus className="h-4 w-4" style={{ color: 'var(--accent)' }} aria-hidden="true" />
            <span>Añadir videos</span>
          </button>
        </div>
      </div>

      {/* Estado vacío */}
      {videos.length === 0 ? (
        <div
          className="mt-8 rounded-2xl border p-8 sm:p-12 text-center"
          style={{
            backgroundColor: 'var(--bg-surface)',
            borderColor: 'var(--border-subtle)',
          }}
        >
          <div
            className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl"
            style={{ backgroundColor: 'var(--accent-soft)' }}
          >
            <Film className="h-8 w-8" style={{ color: 'var(--accent)' }} aria-hidden="true" />
          </div>
          <h2
            className="font-display mt-5 text-xl font-semibold"
            style={{ color: 'var(--text-primary)' }}
          >
            Tu videoteca local está vacía
          </h2>
          <p
            className="mx-auto mt-2 max-w-md text-sm leading-relaxed"
            style={{ color: 'var(--text-secondary)' }}
          >
            Carga películas, series o grabaciones desde tu equipo. Podrás añadir subtítulos personalizados (.srt, .vtt, .ass), cambiar la velocidad y usar el ecualizador sin anuncios.
          </p>

          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={onAddFiles}
              className="flex min-h-[44px] items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-semibold cursor-pointer transition-transform active:scale-[0.98]"
              style={{ backgroundColor: 'var(--accent)', color: 'var(--accent-contrast)' }}
            >
              <Plus className="h-4 w-4" aria-hidden="true" />
              <span>Seleccionar videos</span>
            </button>

            {supportsFolderPicker && (
              <button
                type="button"
                onClick={onOpenFolder}
                className="flex min-h-[44px] items-center gap-2 rounded-xl border px-5 py-2.5 text-sm font-medium cursor-pointer"
                style={{
                  borderColor: 'var(--border-subtle)',
                  backgroundColor: 'var(--bg-elevated)',
                  color: 'var(--text-primary)',
                }}
              >
                <FolderOpen className="h-4 w-4" aria-hidden="true" />
                <span>Escanear carpeta</span>
              </button>
            )}
          </div>

          <div className="mt-6 pt-5 border-t" style={{ borderColor: 'var(--border-subtle)' }}>
            <button
              type="button"
              onClick={onGenerateDemo}
              disabled={isGeneratingDemo}
              className="inline-flex min-h-[40px] items-center gap-2 text-xs font-medium transition-opacity hover:opacity-80 cursor-pointer disabled:opacity-50"
              style={{ color: 'var(--text-secondary)' }}
            >
              <Sparkles className="h-3.5 w-3.5" style={{ color: 'var(--accent)' }} aria-hidden="true" />
              <span>
                {isGeneratingDemo
                  ? 'Creando video y pista de prueba...'
                  : '¿Quieres probar los subtítulos personalizados? Generar muestra local'}
              </span>
            </button>
          </div>
        </div>
      ) : (
        <>
          {/* Búsqueda y orden */}
          <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="relative flex-1 max-w-md">
              <Search
                className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2"
                style={{ color: 'var(--text-secondary)' }}
                aria-hidden="true"
              />
              <input
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Buscar video o formato..."
                aria-label="Buscar en mis videos"
                className="w-full min-h-[42px] rounded-xl border pl-10 pr-4 text-sm outline-none transition-colors"
                style={{
                  backgroundColor: 'var(--bg-surface)',
                  borderColor: 'var(--border-subtle)',
                  color: 'var(--text-primary)',
                }}
              />
            </div>

            <div className="flex items-center gap-2">
              <ArrowUpDown className="h-4 w-4 shrink-0" style={{ color: 'var(--text-secondary)' }} aria-hidden="true" />
              <div
                className="flex items-center gap-1 rounded-xl p-1 border"
                style={{
                  backgroundColor: 'var(--bg-surface)',
                  borderColor: 'var(--border-subtle)',
                }}
              >
                {(['recientes', 'titulo', 'duracion'] as SortKey[]).map((key) => {
                  const labels: Record<SortKey, string> = {
                    recientes: 'Recientes',
                    titulo: 'Nombre',
                    duracion: 'Duración',
                  };
                  const active = sortBy === key;
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => setSortBy(key)}
                      className="min-h-[34px] rounded-lg px-3 py-1 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap"
                      style={{
                        backgroundColor: active ? 'var(--bg-elevated)' : 'transparent',
                        color: active ? 'var(--text-primary)' : 'var(--text-secondary)',
                      }}
                    >
                      {labels[key]}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Cuadrícula de videos */}
          {filtered.length === 0 ? (
            <p className="mt-10 text-center text-sm" style={{ color: 'var(--text-secondary)' }}>
              No se encontraron videos con «{query}».
            </p>
          ) : (
            <div className="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {filtered.map((video, idx) => (
                <motion.article
                  key={video.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.18, delay: Math.min(idx * 0.03, 0.22) }}
                  className="group overflow-hidden rounded-2xl border transition-colors"
                  style={{
                    backgroundColor: 'var(--bg-surface)',
                    borderColor: 'var(--border-subtle)',
                  }}
                >
                  <button
                    type="button"
                    onClick={() => onSelectVideo(video)}
                    className="relative block aspect-video w-full overflow-hidden bg-black/50 text-left cursor-pointer"
                    aria-label={`Reproducir ${video.title}`}
                  >
                    {video.thumbnailUrl ? (
                      <img
                        src={video.thumbnailUrl}
                        alt={video.title}
                        referrerPolicy="no-referrer"
                        className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                      />
                    ) : (
                      <div className="flex h-full w-full flex-col items-center justify-center gap-2 bg-gradient-to-br from-neutral-800 to-neutral-950 text-white/60">
                        <Film className="h-9 w-9" aria-hidden="true" />
                      </div>
                    )}

                    {/* Scrim inferior y duración */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent opacity-85" />

                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <span
                        className="flex h-12 w-12 items-center justify-center rounded-full shadow-lg"
                        style={{ backgroundColor: 'var(--accent)', color: 'var(--accent-contrast)' }}
                      >
                        <Play className="h-5 w-5 fill-current ml-0.5" aria-hidden="true" />
                      </span>
                    </div>

                    <div className="font-mono-tabular absolute bottom-2.5 right-2.5 rounded-md bg-black/75 px-2 py-0.5 text-xs font-medium text-white backdrop-blur-sm">
                      {formatDuration(video.duration)}
                    </div>
                  </button>

                  <div className="flex items-start justify-between gap-2 p-4">
                    <button
                      type="button"
                      onClick={() => onSelectVideo(video)}
                      className="min-w-0 flex-1 text-left cursor-pointer"
                    >
                      <h3
                        className="truncate text-base font-semibold"
                        style={{ color: 'var(--text-primary)' }}
                      >
                        {video.title}
                      </h3>
                      <div
                        className="mt-1 flex flex-wrap items-center gap-1.5 text-xs"
                        style={{ color: 'var(--text-secondary)' }}
                      >
                        <span className="uppercase">{video.format}</span>
                        {formatResolutionLabel(video.width, video.height) ? (
                          <>
                            <span aria-hidden="true">·</span>
                            <span>{formatResolutionLabel(video.width, video.height)}</span>
                          </>
                        ) : null}
                        <span aria-hidden="true">·</span>
                        <span>{formatBytes(video.size)}</span>
                        {video.subtitleRaw && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span
                              className="inline-flex items-center gap-1 font-medium"
                              style={{ color: 'var(--accent)' }}
                            >
                              <Captions className="h-3.5 w-3.5" aria-hidden="true" />
                              <span>Subtítulos</span>
                            </span>
                          </>
                        )}
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => onDeleteVideo(video.id)}
                      aria-label={`Eliminar ${video.title}`}
                      title="Quitar de la biblioteca"
                      className="flex min-h-[40px] min-w-[40px] shrink-0 items-center justify-center rounded-xl opacity-70 hover:opacity-100 transition-opacity cursor-pointer"
                      style={{ color: 'var(--text-secondary)' }}
                    >
                      <Trash2 className="h-4 w-4" aria-hidden="true" />
                    </button>
                  </div>
                </motion.article>
              ))}
            </div>
          )}
        </>
      )}
    </section>
  );
}
