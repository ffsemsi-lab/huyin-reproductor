import { Check, Copy, Download, ExternalLink, Smartphone, X } from 'lucide-react';
import { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export function InstallAppCard() {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [copied, setCopied] = useState(false);
  const [showGuideModal, setShowGuideModal] = useState(false);

  const directUrl =
    typeof window !== 'undefined' ? window.location.origin : '';

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(directUrl);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2400);
    } catch {
      // Ignorar si el portapapeles está bloqueado
    }
  };

  const handleInstallClick = async () => {
    if (isInstallable) {
      await install();
      return;
    }
    setShowGuideModal(true);
  };

  return (
    <div
      className="rounded-2xl border p-5 sm:p-6"
      style={{
        backgroundColor: 'var(--bg-surface)',
        borderColor: 'var(--border-subtle)',
      }}
    >
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="flex items-start gap-3">
          <div
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl"
            style={{ backgroundColor: 'var(--accent-soft)', color: 'var(--accent)' }}
          >
            <Smartphone className="h-5 w-5" aria-hidden="true" />
          </div>
          <div>
            <h2 className="font-display text-lg font-bold" style={{ color: 'var(--text-primary)' }}>
              Acceso directo en tu menú e instalación
            </h2>
            <p className="mt-0.5 text-xs leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
              Instala 琥音Hǔyīn directamente en el menú de aplicaciones de tu teléfono o escritorio como app independiente (PWA) sin anuncios y disponible sin internet.
            </p>
          </div>
        </div>

        {!isInstalled ? (
          <button
            type="button"
            onClick={() => void handleInstallClick()}
            className="flex min-h-[44px] shrink-0 items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-xs font-semibold transition-transform active:scale-[0.98] cursor-pointer whitespace-nowrap"
            style={{
              backgroundColor: 'var(--accent)',
              color: 'var(--accent-contrast)',
            }}
          >
            <Download className="h-4 w-4" aria-hidden="true" />
            <span>
              {isInstallable
                ? 'Instalar en tu menú'
                : isIOS
                  ? 'Instalar en iPhone / iPad'
                  : 'Añadir a tu menú'}
            </span>
          </button>
        ) : (
          <span
            className="flex min-h-[40px] shrink-0 items-center gap-1.5 text-xs font-semibold whitespace-nowrap"
            style={{ color: 'var(--accent)' }}
          >
            <Check className="h-4 w-4" aria-hidden="true" />
            <span>Instalada en este dispositivo</span>
          </span>
        )}
      </div>

      {/* Enlace directo */}
      <div
        className="mt-5 flex flex-col gap-3 rounded-xl border p-3.5 sm:flex-row sm:items-center sm:justify-between"
        style={{
          backgroundColor: 'var(--bg-elevated)',
          borderColor: 'var(--border-subtle)',
        }}
      >
        <div className="min-w-0 flex-1">
          <p className="text-[11px] font-medium" style={{ color: 'var(--text-secondary)' }}>
            Link directo del reproductor
          </p>
          <p
            className="font-mono-tabular mt-0.5 truncate text-xs font-medium"
            style={{ color: 'var(--text-primary)' }}
          >
            {directUrl}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => void handleCopyLink()}
            className="flex min-h-[40px] items-center gap-1.5 rounded-xl border px-3.5 py-2 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap"
            style={{
              borderColor: 'var(--border-subtle)',
              backgroundColor: 'var(--bg-surface)',
              color: 'var(--text-primary)',
            }}
          >
            {copied ? (
              <>
                <Check className="h-3.5 w-3.5" style={{ color: 'var(--accent)' }} aria-hidden="true" />
                <span>Link copiado</span>
              </>
            ) : (
              <>
                <Copy className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Copiar link</span>
              </>
            )}
          </button>

          <a
            href={directUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex min-h-[40px] items-center gap-1.5 rounded-xl border px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap"
            style={{
              borderColor: 'var(--border-subtle)',
              backgroundColor: 'var(--bg-surface)',
              color: 'var(--text-primary)',
            }}
          >
            <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Abrir directo</span>
          </a>
        </div>
      </div>

      {/* Nota honesta sobre APK */}
      <p className="mt-3 text-xs leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
        Nota sobre Android APK: desde el navegador no se compila un archivo .apk nativo firmado, pero al abrir el link directo en Chrome de Android y pulsar «Instalar aplicación», 琥音Hǔyīn se añade a tu menú de apps con icono propio y funcionamiento sin conexión. Si necesitas un paquete .apk tradicional, puedes empaquetar este mismo link con PWABuilder o Bubblewrap (TWA).
      </p>

      {/* Modal con pasos guiados si el navegador requiere instalación manual o es iOS */}
      {showGuideModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-label="Cómo añadir 琥音Hǔyīn a tu menú"
        >
          <div
            className="w-full max-w-md rounded-2xl border p-6 shadow-2xl"
            style={{
              backgroundColor: 'var(--bg-surface)',
              borderColor: 'var(--border-subtle)',
              color: 'var(--text-primary)',
            }}
          >
            <div className="flex items-center justify-between pb-3 border-b" style={{ borderColor: 'var(--border-subtle)' }}>
              <h3 className="font-display text-base font-bold">
                {isIOS ? 'Instalar en iPhone / iPad' : 'Añadir a tu menú de aplicaciones'}
              </h3>
              <button
                type="button"
                onClick={() => setShowGuideModal(false)}
                aria-label="Cerrar guía"
                className="flex h-9 w-9 items-center justify-center rounded-lg hover:bg-white/10 cursor-pointer"
              >
                <X className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>

            {isIOS ? (
              <ol className="mt-4 space-y-2.5 text-sm leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                <li>1. Abre el link directo en Safari (fuera de vistas previas).</li>
                <li>2. Toca el botón <strong style={{ color: 'var(--text-primary)' }}>Compartir</strong> en la barra inferior.</li>
                <li>3. Elige <strong style={{ color: 'var(--text-primary)' }}>Añadir a pantalla de inicio</strong> y confirma.</li>
              </ol>
            ) : (
              <ol className="mt-4 space-y-2.5 text-sm leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                <li>1. Si estás dentro de una vista previa, toca <strong style={{ color: 'var(--text-primary)' }}>Abrir directo</strong> para abrir el reproductor en una pestaña propia.</li>
                <li>2. En Chrome o Edge móvil, abre el menú <strong style={{ color: 'var(--text-primary)' }}>⋮</strong> y selecciona <strong style={{ color: 'var(--text-primary)' }}>Instalar aplicación</strong> o <strong style={{ color: 'var(--text-primary)' }}>Añadir a pantalla de inicio</strong>.</li>
                <li>3. El icono de 琥音Hǔyīn aparecerá en tu menú de apps y funcionará sin conexión.</li>
              </ol>
            )}

            <div className="mt-5 flex justify-end gap-2">
              <a
                href={directUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex min-h-[40px] items-center gap-1.5 rounded-xl px-4 py-2 text-xs font-semibold"
                style={{
                  backgroundColor: 'var(--accent)',
                  color: 'var(--accent-contrast)',
                }}
              >
                <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Abrir link directo</span>
              </a>
              <button
                type="button"
                onClick={() => setShowGuideModal(false)}
                className="min-h-[40px] rounded-xl border px-4 py-2 text-xs font-medium cursor-pointer"
                style={{ borderColor: 'var(--border-subtle)' }}
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
