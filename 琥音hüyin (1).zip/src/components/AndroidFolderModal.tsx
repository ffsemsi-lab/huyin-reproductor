import { ArrowUp, Check, Folder, FolderOpen, Loader2, Music, X } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useCallback, useEffect, useState } from 'react';
import {
  listNativeDirectory,
  type NativeDirListing,
} from '../utils/nativeAndroidMedia';

interface AndroidFolderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectFolder: (folderPath: string, folderName: string) => void;
  onFallbackFilePicker: () => void;
}

export function AndroidFolderModal({
  isOpen,
  onClose,
  onSelectFolder,
  onFallbackFilePicker,
}: AndroidFolderModalProps) {
  const [listing, setListing] = useState<NativeDirListing | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const loadPath = useCallback(async (targetPath?: string) => {
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const res = await listNativeDirectory(targetPath);
      setListing(res);
    } catch {
      setErrorMsg('No se pudo leer esta carpeta del dispositivo.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    if (isOpen) {
      void loadPath();
    }
  }, [isOpen, loadPath]);

  const currentName = listing
    ? listing.currentPath === listing.rootPath
      ? 'Almacenamiento interno'
      : listing.currentPath.split('/').filter(Boolean).pop() || 'Carpeta'
    : 'Almacenamiento interno';

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-label="Seleccionar carpeta del dispositivo"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 12 }}
            transition={{ duration: 0.18 }}
            className="flex max-h-[84vh] w-full max-w-lg flex-col overflow-hidden rounded-2xl border shadow-2xl"
            style={{
              backgroundColor: 'var(--bg-surface)',
              borderColor: 'var(--border-subtle)',
              color: 'var(--text-primary)',
            }}
          >
            {/* Cabecera */}
            <div
              className="flex items-center justify-between gap-3 border-b px-5 py-4"
              style={{ borderColor: 'var(--border-subtle)' }}
            >
              <div className="flex min-w-0 items-center gap-3">
                <div
                  className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl"
                  style={{ backgroundColor: 'var(--accent-soft)', color: 'var(--accent)' }}
                >
                  <FolderOpen className="h-5 w-5" aria-hidden="true" />
                </div>
                <div className="min-w-0">
                  <h2 className="font-display truncate text-base font-bold">
                    Elegir carpeta de música o video
                  </h2>
                  <p className="truncate text-xs" style={{ color: 'var(--text-secondary)' }}>
                    {currentName}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={onClose}
                aria-label="Cerrar selector de carpetas"
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl hover:bg-white/10 cursor-pointer"
                style={{ color: 'var(--text-secondary)' }}
              >
                <X className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>

            {/* Accesos rápidos */}
            {listing && listing.shortcuts.length > 0 && (
              <div
                className="flex flex-wrap gap-1.5 border-b px-4 py-2.5"
                style={{
                  borderColor: 'var(--border-subtle)',
                  backgroundColor: 'var(--bg-elevated)',
                }}
              >
                {listing.shortcuts.map((sc) => {
                  const active = listing.currentPath === sc.path;
                  return (
                    <button
                      key={sc.path}
                      type="button"
                      onClick={() => void loadPath(sc.path)}
                      className="min-h-[32px] rounded-lg border px-2.5 py-1 text-xs font-medium cursor-pointer"
                      style={{
                        borderColor: active ? 'var(--accent)' : 'var(--border-subtle)',
                        backgroundColor: active ? 'var(--accent-soft)' : 'var(--bg-surface)',
                        color: active ? 'var(--accent)' : 'var(--text-primary)',
                      }}
                    >
                      {sc.name}
                    </button>
                  );
                })}
              </div>
            )}

            {/* Navegación y lista de subcarpetas */}
            <div className="flex-1 overflow-y-auto p-3 space-y-1.5">
              {listing?.parentPath && (
                <button
                  type="button"
                  onClick={() => void loadPath(listing.parentPath || undefined)}
                  className="flex w-full min-h-[44px] items-center gap-3 rounded-xl border px-3.5 py-2.5 text-left text-xs font-semibold cursor-pointer"
                  style={{
                    borderColor: 'var(--border-subtle)',
                    backgroundColor: 'var(--bg-elevated)',
                    color: 'var(--text-primary)',
                  }}
                >
                  <ArrowUp className="h-4 w-4" style={{ color: 'var(--accent)' }} aria-hidden="true" />
                  <span>Subir una carpeta</span>
                </button>
              )}

              {isLoading ? (
                <div className="flex items-center justify-center gap-2 py-10 text-xs" style={{ color: 'var(--text-secondary)' }}>
                  <Loader2 className="h-5 w-5 animate-spin" style={{ color: 'var(--accent)' }} aria-hidden="true" />
                  <span>Leyendo carpetas...</span>
                </div>
              ) : errorMsg ? (
                <div className="py-8 text-center text-xs" style={{ color: 'var(--text-secondary)' }}>
                  <p>{errorMsg}</p>
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onFallbackFilePicker();
                    }}
                    className="mt-3 rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer"
                    style={{ backgroundColor: 'var(--accent)', color: 'var(--accent-contrast)' }}
                  >
                    Usar selector de archivos del sistema
                  </button>
                </div>
              ) : listing && listing.directories.length === 0 ? (
                <div className="py-8 text-center text-xs" style={{ color: 'var(--text-secondary)' }}>
                  <p>No hay más subcarpetas aquí.</p>
                  <p className="mt-1">
                    {listing.mediaCountHere > 0
                      ? `Hay ${listing.mediaCountHere} archivos multimedia listos en esta carpeta.`
                      : 'Puedes importar esta carpeta o volver atrás.'}
                  </p>
                </div>
              ) : (
                listing?.directories.map((dir) => (
                  <button
                    key={dir.path}
                    type="button"
                    onClick={() => void loadPath(dir.path)}
                    className="flex w-full min-h-[46px] items-center justify-between gap-3 rounded-xl border px-3.5 py-2.5 text-left transition-colors cursor-pointer"
                    style={{
                      borderColor: 'var(--border-subtle)',
                      backgroundColor: 'var(--bg-elevated)',
                    }}
                  >
                    <div className="flex min-w-0 items-center gap-3">
                      <Folder className="h-4 w-4 shrink-0" style={{ color: 'var(--accent)' }} aria-hidden="true" />
                      <span className="truncate text-sm font-medium" style={{ color: 'var(--text-primary)' }}>
                        {dir.name}
                      </span>
                    </div>
                    {dir.mediaCount > 0 && (
                      <span className="font-mono-tabular shrink-0 text-[11px]" style={{ color: 'var(--text-secondary)' }}>
                        {dir.mediaCount}
                      </span>
                    )}
                  </button>
                ))
              )}
            </div>

            {/* Pie con botón principal */}
            <div
              className="flex flex-col gap-2 border-t p-4 sm:flex-row sm:items-center sm:justify-between"
              style={{
                borderColor: 'var(--border-subtle)',
                backgroundColor: 'var(--bg-surface)',
              }}
            >
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onFallbackFilePicker();
                }}
                className="flex min-h-[42px] items-center justify-center gap-2 rounded-xl border px-3.5 py-2 text-xs font-medium cursor-pointer"
                style={{
                  borderColor: 'var(--border-subtle)',
                  color: 'var(--text-secondary)',
                }}
              >
                <Music className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Elegir archivos sueltos</span>
              </button>

              {listing && (
                <button
                  type="button"
                  onClick={() => {
                    onSelectFolder(listing.currentPath, currentName);
                    onClose();
                  }}
                  className="flex min-h-[44px] items-center justify-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer"
                  style={{
                    backgroundColor: 'var(--accent)',
                    color: 'var(--accent-contrast)',
                  }}
                >
                  <Check className="h-4 w-4" aria-hidden="true" />
                  <span>
                    Importar «{currentName}»
                    {listing.mediaCountHere > 0 ? ` (${listing.mediaCountHere})` : ''}
                  </span>
                </button>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
