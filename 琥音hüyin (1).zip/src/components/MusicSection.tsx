import {
  ArrowUpDown,
  Disc3,
  FolderOpen,
  Music,
  Pause,
  Play,
  Plus,
  Search,
  Sparkles,
  Trash2,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useMemo, useState } from 'react';
import type { MediaItem } from '../types/media';
import { formatBytes, formatDuration } from '../utils/libraryDb';

interface MusicSectionProps {
  tracks: MediaItem[];
  currentTrackId: string | null;
  isPlaying: boolean;
  onSelectTrack: (track: MediaItem) => void;
  onTogglePlay: () => void;
  onDeleteTrack: (id: string) => void;
  onAddFiles: () => void;
  onOpenFolder: () => void;
  onGenerateDemo: () => void;
  isGeneratingDemo: boolean;
  supportsFolderPicker: boolean;
}

type SortKey = 'recientes' | 'titulo' | 'duracion';

export function MusicSection({
  tracks,
  currentTrackId,
  isPlaying,
  onSelectTrack,
  onTogglePlay,
  onDeleteTrack,
  onAddFiles,
  onOpenFolder,
  onGenerateDemo,
  isGeneratingDemo,
  supportsFolderPicker,
}: MusicSectionProps) {
  const [query, setQuery] = useState('');
  const [sortBy, setSortBy] = useState<SortKey>('recientes');

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const base = q
      ? tracks.filter(
          (t) =>
            t.title.toLowerCase().includes(q) ||
            t.artist.toLowerCase().includes(q) ||
            t.format.toLowerCase().includes(q)
        )
      : [...tracks];

    if (sortBy === 'titulo') {
      base.sort((a, b) => a.title.localeCompare(b.title, 'es'));
    } else if (sortBy === 'duracion') {
      base.sort((a, b) => b.duration - a.duration);
    } else {
      base.sort((a, b) => b.addedAt - a.addedAt);
    }
    return base;
  }, [tracks, query, sortBy]);

  const totalDuration = useMemo(
    () => tracks.reduce((acc, t) => acc + (t.duration || 0), 0),
    [tracks]
  );

  return (
    <section className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
      {/* Encabezado de sección */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between pb-6 border-b" style={{ borderColor: 'var(--border-subtle)' }}>
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight" style={{ color: 'var(--text-primary)' }}>
            Mi música
          </h1>
          <p className="mt-1 text-sm" style={{ color: 'var(--text-secondary)' }}>
            {tracks.length === 0
              ? 'Biblioteca local sin conexión · MP3, FLAC, WAV, AAC, OGG, OPUS, M4A'
              : `${tracks.length} ${tracks.length === 1 ? 'pista' : 'pistas'} · ${formatDuration(totalDuration)} de audio local`}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {supportsFolderPicker && (
            <button
              type="button"
              onClick={onOpenFolder}
              className="flex min-h-[42px] items-center gap-2 rounded-xl border px-4 py-2 text-sm font-medium transition-colors cursor-pointer whitespace-nowrap"
              style={{
                borderColor: 'var(--border-subtle)',
                backgroundColor: 'var(--bg-surface)',
                color: 'var(--text-primary)',
              }}
            >
              <FolderOpen className="h-4 w-4" style={{ color: 'var(--accent)' }} aria-hidden="true" />
              <span>Abrir carpeta</span>
            </button>
          )}
          <button
            type="button"
            onClick={onAddFiles}
            className="flex min-h-[42px] items-center gap-2 rounded-xl border px-4 py-2 text-sm font-medium transition-colors cursor-pointer whitespace-nowrap"
            style={{
              borderColor: 'var(--border-subtle)',
              backgroundColor: 'var(--bg-surface)',
              color: 'var(--text-primary)',
            }}
          >
            <Plus className="h-4 w-4" style={{ color: 'var(--accent)' }} aria-hidden="true" />
            <span>Añadir música</span>
          </button>
        </div>
      </div>

      {/* Estado vacío */}
      {tracks.length === 0 ? (
        <div
          className="mt-8 rounded-2xl border p-8 sm:p-12 text-center"
          style={{
            backgroundColor: 'var(--bg-surface)',
            borderColor: 'var(--border-subtle)',
          }}
        >
          <div
            className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl"
            style={{ backgroundColor: 'var(--accent-soft)' }}
          >
            <Music className="h-8 w-8" style={{ color: 'var(--accent)' }} aria-hidden="true" />
          </div>
          <h2 className="font-display mt-5 text-xl font-semibold" style={{ color: 'var(--text-primary)' }}>
            Tu biblioteca musical está lista
          </h2>
          <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
            Lee directamente tus canciones locales sin subir nada a la nube, sin anuncios y sin internet. Arrastra archivos aquí o selecciona tu música.
          </p>

          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={onAddFiles}
              className="flex min-h-[44px] items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-semibold cursor-pointer transition-transform active:scale-[0.98]"
              style={{ backgroundColor: 'var(--accent)', color: 'var(--accent-contrast)' }}
            >
              <Plus className="h-4 w-4" aria-hidden="true" />
              <span>Seleccionar canciones</span>
            </button>

            {supportsFolderPicker && (
              <button
                type="button"
                onClick={onOpenFolder}
                className="flex min-h-[44px] items-center gap-2 rounded-xl border px-5 py-2.5 text-sm font-medium cursor-pointer"
                style={{
                  borderColor: 'var(--border-subtle)',
                  backgroundColor: 'var(--bg-elevated)',
                  color: 'var(--text-primary)',
                }}
              >
                <FolderOpen className="h-4 w-4" aria-hidden="true" />
                <span>Escanear carpeta</span>
              </button>
            )}
          </div>

          <div className="mt-6 pt-5 border-t" style={{ borderColor: 'var(--border-subtle)' }}>
            <button
              type="button"
              onClick={onGenerateDemo}
              disabled={isGeneratingDemo}
              className="inline-flex min-h-[40px] items-center gap-2 text-xs font-medium transition-opacity hover:opacity-80 cursor-pointer disabled:opacity-50"
              style={{ color: 'var(--text-secondary)' }}
            >
              <Sparkles className="h-3.5 w-3.5" style={{ color: 'var(--accent)' }} aria-hidden="true" />
              <span>
                {isGeneratingDemo
                  ? 'Creando pista y video de prueba...'
                  : '¿Quieres probar el ecualizador ahora? Generar muestra local'}
              </span>
            </button>
          </div>
        </div>
      ) : (
        <>
          {/* Barra de búsqueda y orden */}
          <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="relative flex-1 max-w-md">
              <Search
                className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2"
                style={{ color: 'var(--text-secondary)' }}
                aria-hidden="true"
              />
              <input
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Buscar canción, artista o formato..."
                aria-label="Buscar en mi música"
                className="w-full min-h-[42px] rounded-xl border pl-10 pr-4 text-sm outline-none transition-colors"
                style={{
                  backgroundColor: 'var(--bg-surface)',
                  borderColor: 'var(--border-subtle)',
                  color: 'var(--text-primary)',
                }}
              />
            </div>

            <div className="flex items-center gap-2">
              <ArrowUpDown className="h-4 w-4 shrink-0" style={{ color: 'var(--text-secondary)' }} aria-hidden="true" />
              <div
                className="flex items-center gap-1 rounded-xl p-1 border"
                style={{
                  backgroundColor: 'var(--bg-surface)',
                  borderColor: 'var(--border-subtle)',
                }}
              >
                {(['recientes', 'titulo', 'duracion'] as SortKey[]).map((key) => {
                  const labels: Record<SortKey, string> = {
                    recientes: 'Recientes',
                    titulo: 'Nombre',
                    duracion: 'Duración',
                  };
                  const active = sortBy === key;
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => setSortBy(key)}
                      className="min-h-[34px] rounded-lg px-3 py-1 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap"
                      style={{
                        backgroundColor: active ? 'var(--bg-elevated)' : 'transparent',
                        color: active ? 'var(--text-primary)' : 'var(--text-secondary)',
                      }}
                    >
                      {labels[key]}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Lista de pistas */}
          {filtered.length === 0 ? (
            <p className="mt-10 text-center text-sm" style={{ color: 'var(--text-secondary)' }}>
              No se encontraron canciones con «{query}».
            </p>
          ) : (
            <div
              className="mt-4 overflow-hidden rounded-2xl border [&>*+*]:border-t"
              style={{
                backgroundColor: 'var(--bg-surface)',
                borderColor: 'var(--border-subtle)',
              }}
            >
              {filtered.map((track, idx) => {
                const isCurrent = track.id === currentTrackId;
                return (
                  <motion.div
                    key={track.id}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.16, delay: Math.min(idx * 0.02, 0.2) }}
                    className="group flex items-center justify-between gap-3 px-4 py-3 transition-colors"
                    style={{
                      backgroundColor: isCurrent ? 'var(--accent-soft)' : 'transparent',
                      borderColor: 'var(--border-subtle)',
                    }}
                  >
                    <button
                      type="button"
                      onClick={() => {
                        if (isCurrent) {
                          onTogglePlay();
                        } else {
                          onSelectTrack(track);
                        }
                      }}
                      className="flex min-w-0 flex-1 items-center gap-3.5 text-left cursor-pointer"
                    >
                      <div
                        className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl transition-transform group-hover:scale-105"
                        style={{
                          backgroundColor: isCurrent ? 'var(--accent)' : 'var(--bg-elevated)',
                          color: isCurrent ? 'var(--accent-contrast)' : 'var(--text-secondary)',
                        }}
                      >
                        {isCurrent && isPlaying ? (
                          <Pause className="h-5 w-5" aria-hidden="true" />
                        ) : isCurrent ? (
                          <Play className="h-5 w-5 ml-0.5" aria-hidden="true" />
                        ) : (
                          <Disc3 className="h-5 w-5" aria-hidden="true" />
                        )}
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span
                            className="truncate text-sm sm:text-base font-semibold"
                            style={{
                              color: isCurrent ? 'var(--accent)' : 'var(--text-primary)',
                            }}
                          >
                            {track.title}
                          </span>
                        </div>
                        <div
                          className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs truncate"
                          style={{ color: 'var(--text-secondary)' }}
                        >
                          <span className="truncate">{track.artist}</span>
                          <span aria-hidden="true">·</span>
                          <span className="uppercase">{track.format}</span>
                          <span aria-hidden="true">·</span>
                          <span>{formatBytes(track.size)}</span>
                        </div>
                      </div>
                    </button>

                    <div className="flex items-center gap-2 shrink-0">
                      <span
                        className="font-mono-tabular text-xs sm:text-sm"
                        style={{ color: 'var(--text-secondary)' }}
                      >
                        {formatDuration(track.duration)}
                      </span>
                      <button
                        type="button"
                        onClick={() => onDeleteTrack(track.id)}
                        aria-label={`Eliminar ${track.title}`}
                        title="Quitar de la biblioteca"
                        className="flex min-h-[40px] min-w-[40px] items-center justify-center rounded-lg opacity-70 hover:opacity-100 transition-opacity cursor-pointer"
                        style={{ color: 'var(--text-secondary)' }}
                      >
                        <Trash2 className="h-4 w-4" aria-hidden="true" />
                      </button>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </>
      )}
    </section>
  );
}
