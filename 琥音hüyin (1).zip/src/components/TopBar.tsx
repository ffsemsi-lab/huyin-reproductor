import { FolderPlus, Music, SlidersHorizontal, Video } from 'lucide-react';
import { motion } from 'motion/react';
import type { NavSection } from '../types/media';

interface TopBarProps {
  activeSection: NavSection;
  onSelectSection: (section: NavSection) => void;
  onAddFiles: () => void;
  musicCount: number;
  videoCount: number;
}

export function TopBar({
  activeSection,
  onSelectSection,
  onAddFiles,
  musicCount,
  videoCount,
}: TopBarProps) {
  const navItems: Array<{ id: NavSection; label: string; count?: number }> = [
    { id: 'musica', label: 'Música', count: musicCount },
    { id: 'video', label: 'Video', count: videoCount },
    { id: 'ajustes', label: 'Ajustes' },
  ];

  return (
    <>
      {/* Barra superior (Escritorio y móvil compacto) */}
      <header
        className="sticky top-0 z-30 border-b backdrop-blur-md"
        style={{
          backgroundColor: 'color-mix(in srgb, var(--bg-canvas) 86%, transparent)',
          borderColor: 'var(--border-subtle)',
          paddingTop: 'env(safe-area-inset-top)',
        }}
      >
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between gap-8 px-4 sm:px-6 lg:px-8">
          {/* Zona 1: Marca (icono recortado + nombre 琥音Hǔyīn) */}
          <button
            type="button"
            onClick={() => onSelectSection('musica')}
            className="font-display flex items-center gap-2.5 text-lg font-bold tracking-tight whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 cursor-pointer"
            style={{ color: 'var(--text-primary)', outlineColor: 'var(--accent)' }}
          >
            <img
              src="/huyin-icon.png"
              alt="琥音Hǔyīn"
              referrerPolicy="no-referrer"
              className="h-8 w-8 rounded-lg object-cover shrink-0 border border-white/10"
            />
            <span>琥音Hǔyīn</span>
          </button>

          {/* Zona 2: Navegación principal (Escritorio) */}
          <nav
            aria-label="Secciones principales"
            className="hidden md:flex items-center gap-8"
          >
            {navItems.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onSelectSection(item.id)}
                  className="relative flex items-center gap-2 py-4 text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  style={{
                    color: isActive ? 'var(--text-primary)' : 'var(--text-secondary)',
                  }}
                >
                  <span>{item.label}</span>
                  {typeof item.count === 'number' && item.count > 0 && (
                    <span
                      className="font-mono-tabular text-xs opacity-70"
                      style={{ color: isActive ? 'var(--accent)' : 'var(--text-secondary)' }}
                    >
                      {item.count}
                    </span>
                  )}
                  {isActive && (
                    <motion.span
                      layoutId="desktop-nav-underline"
                      transition={{ type: 'spring', stiffness: 420, damping: 34 }}
                      className="absolute inset-x-0 bottom-0 h-0.5 rounded-full"
                      style={{ backgroundColor: 'var(--accent)' }}
                    />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zona 3: Acción primaria única */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={onAddFiles}
              className="flex min-h-[40px] items-center gap-2 rounded-xl px-4 py-2 text-xs sm:text-sm font-semibold transition-transform active:scale-[0.97] whitespace-nowrap shrink-0 cursor-pointer"
              style={{
                backgroundColor: 'var(--accent)',
                color: 'var(--accent-contrast)',
              }}
            >
              <FolderPlus className="h-4 w-4" aria-hidden="true" />
              <span>Añadir archivos</span>
            </button>
          </div>
        </div>
      </header>

      {/* Barra inferior fija en móvil (respetando límite <= 15% altura móvil) */}
      <nav
        aria-label="Navegación inferior"
        className="fixed bottom-0 left-0 right-0 z-40 grid grid-cols-3 border-t backdrop-blur-md md:hidden"
        style={{
          backgroundColor: 'color-mix(in srgb, var(--bg-surface) 92%, transparent)',
          borderColor: 'var(--border-subtle)',
          minHeight: '60px',
          height: 'calc(60px + env(safe-area-inset-bottom))',
          paddingBottom: 'env(safe-area-inset-bottom)',
        }}
      >
        <button
          type="button"
          onClick={() => onSelectSection('musica')}
          className="relative flex min-h-[44px] flex-col items-center justify-center gap-0.5 text-[11px] font-medium transition-colors"
          style={{
            color: activeSection === 'musica' ? 'var(--accent)' : 'var(--text-secondary)',
          }}
        >
          <Music className="h-5 w-5" aria-hidden="true" />
          <span className="whitespace-nowrap">Música</span>
        </button>

        <button
          type="button"
          onClick={() => onSelectSection('video')}
          className="relative flex min-h-[44px] flex-col items-center justify-center gap-0.5 text-[11px] font-medium transition-colors"
          style={{
            color: activeSection === 'video' ? 'var(--accent)' : 'var(--text-secondary)',
          }}
        >
          <Video className="h-5 w-5" aria-hidden="true" />
          <span className="whitespace-nowrap">Video</span>
        </button>

        <button
          type="button"
          onClick={() => onSelectSection('ajustes')}
          className="relative flex min-h-[44px] flex-col items-center justify-center gap-0.5 text-[11px] font-medium transition-colors"
          style={{
            color: activeSection === 'ajustes' ? 'var(--accent)' : 'var(--text-secondary)',
          }}
        >
          <SlidersHorizontal className="h-5 w-5" aria-hidden="true" />
          <span className="whitespace-nowrap">Ajustes</span>
        </button>
      </nav>
    </>
  );
}
