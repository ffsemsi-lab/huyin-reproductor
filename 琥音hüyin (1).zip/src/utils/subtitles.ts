import type { SubtitleCue } from '../types/media';

function parseTimestamp(raw: string): number {
  const cleaned = raw.trim().replace(',', '.');
  const parts = cleaned.split(':');
  if (parts.length === 3) {
    const hours = Number(parts[0]) || 0;
    const minutes = Number(parts[1]) || 0;
    const seconds = Number(parts[2]) || 0;
    return hours * 3600 + minutes * 60 + seconds;
  }
  if (parts.length === 2) {
    const minutes = Number(parts[0]) || 0;
    const seconds = Number(parts[1]) || 0;
    return minutes * 60 + seconds;
  }
  return 0;
}

function cleanSubtitleText(raw: string): string {
  return raw
    .replace(/\{\\[^}]+\}/g, '') // Etiquetas ASS/SSA {\an8} etc.
    .replace(/<[^>]+>/g, '') // Etiquetas HTML <i>, <b>, <font>
    .replace(/\\N/g, '\n')
    .replace(/\\n/g, '\n')
    .trim();
}

export function parseSubtitleContent(content: string): SubtitleCue[] {
  const normalized = content.replace(/\r\n/g, '\n').replace(/\r/g, '\n').trim();
  if (!normalized) return [];

  // Detección de formato ASS / SSA
  if (normalized.includes('[Events]') && normalized.includes('Dialogue:')) {
    const lines = normalized.split('\n');
    const cues: SubtitleCue[] = [];
    let idCounter = 1;
    let formatFields: string[] = [];

    for (const line of lines) {
      const trimmed = line.trim();
      if (trimmed.startsWith('Format:')) {
        formatFields = trimmed
          .slice(7)
          .split(',')
          .map((f) => f.trim().toLowerCase());
      } else if (trimmed.startsWith('Dialogue:')) {
        const payload = trimmed.slice(9).trim();
        const maxCols = formatFields.length > 0 ? formatFields.length : 10;
        const parts: string[] = [];
        let remaining = payload;
        for (let i = 0; i < maxCols - 1; i++) {
          const commaIdx = remaining.indexOf(',');
          if (commaIdx === -1) break;
          parts.push(remaining.slice(0, commaIdx).trim());
          remaining = remaining.slice(commaIdx + 1);
        }
        parts.push(remaining.trim());

        const startIdx = formatFields.indexOf('start') !== -1 ? formatFields.indexOf('start') : 1;
        const endIdx = formatFields.indexOf('end') !== -1 ? formatFields.indexOf('end') : 2;
        const textIdx = formatFields.indexOf('text') !== -1 ? formatFields.indexOf('text') : parts.length - 1;

        const start = parseTimestamp(parts[startIdx] || '0');
        const end = parseTimestamp(parts[endIdx] || '0');
        const text = cleanSubtitleText(parts[textIdx] || '');

        if (text && end > start) {
          cues.push({ id: idCounter++, start, end, text });
        }
      }
    }
    return cues.sort((a, b) => a.start - b.start);
  }

  // Formato SRT o WebVTT
  const blocks = normalized
    .replace(/^WEBVTT[^\n]*\n+/i, '')
    .split(/\n{2,}/);

  const cues: SubtitleCue[] = [];
  let idCounter = 1;

  for (const block of blocks) {
    const lines = block
      .split('\n')
      .map((l) => l.trim())
      .filter(Boolean);

    if (lines.length === 0) continue;
    if (lines[0].startsWith('NOTE') || lines[0].startsWith('STYLE')) continue;

    const timeLineIdx = lines.findIndex((l) => l.includes('-->'));
    if (timeLineIdx === -1) continue;

    const timeLine = lines[timeLineIdx];
    const [startRaw, endRawWithMeta] = timeLine.split('-->');
    if (!startRaw || !endRawWithMeta) continue;

    const endRaw = endRawWithMeta.trim().split(/\s+/)[0];
    const start = parseTimestamp(startRaw);
    const end = parseTimestamp(endRaw);
    const text = cleanSubtitleText(lines.slice(timeLineIdx + 1).join('\n'));

    if (text && end > start) {
      cues.push({ id: idCounter++, start, end, text });
    }
  }

  return cues.sort((a, b) => a.start - b.start);
}

export function getActiveSubtitles(
  cues: SubtitleCue[],
  currentTimeSec: number,
  syncOffsetSec: number
): SubtitleCue[] {
  if (!cues.length) return [];
  const adjustedTime = currentTimeSec - syncOffsetSec;
  return cues.filter((cue) => adjustedTime >= cue.start && adjustedTime <= cue.end);
}

export async function readSubtitleFile(file: File): Promise<string> {
  const buffer = await file.arrayBuffer();
  try {
    const utf8 = new TextDecoder('utf-8', { fatal: true }).decode(buffer);
    return utf8;
  } catch {
    return new TextDecoder('iso-8859-1').decode(buffer);
  }
}
