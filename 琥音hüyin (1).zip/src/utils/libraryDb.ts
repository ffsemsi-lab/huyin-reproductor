import type { AppSettings, MediaItem, MediaKind } from '../types/media';
import { DEFAULT_APP_SETTINGS } from '../constants/presets';

const DB_NAME = 'visha_libre_db';
const DB_VERSION = 2;
const STORE_ITEMS = 'media_items';
const STORE_BLOBS = 'media_blobs';
const STORE_DIR_HANDLES = 'dir_handles';
const SETTINGS_KEY = 'visha_libre_settings_v1';

export interface SavedDirectoryEntry {
  id: string;
  name: string;
  addedAt: number;
  handle: FileSystemDirectoryHandle;
}

export interface StoragePermissionStatus {
  supported: boolean;
  persisted: boolean;
  usageBytes: number;
  quotaBytes: number;
}

const AUDIO_EXTS = new Set([
  'mp3', 'wav', 'flac', 'ogg', 'oga', 'opus', 'm4a', 'aac', 'wma', 'aiff', 'alac', 'weba',
]);
const VIDEO_EXTS = new Set([
  'mp4', 'webm', 'mkv', 'mov', 'avi', 'm4v', 'ogv', '3gp', 'ts', 'flv', 'wmv',
]);

export function detectMediaKind(file: File): MediaKind | null {
  const ext = file.name.split('.').pop()?.toLowerCase() || '';
  if (file.type.startsWith('audio/') || AUDIO_EXTS.has(ext)) return 'audio';
  if (file.type.startsWith('video/') || VIDEO_EXTS.has(ext)) return 'video';
  return null;
}

export function cleanFileTitle(filename: string): string {
  return filename.replace(/\.[^/.]+$/, '').replace(/[_]+/g, ' ').trim() || filename;
}

export function parseArtistAndTitle(filename: string): { title: string; artist: string } {
  const base = cleanFileTitle(filename);
  const dashSplit = base.split(/\s+-\s+/);
  if (dashSplit.length >= 2) {
    return {
      artist: dashSplit[0].trim(),
      title: dashSplit.slice(1).join(' - ').trim(),
    };
  }
  return { title: base, artist: 'Archivo local' };
}

export function formatDuration(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds <= 0) return '00:00';
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  if (hrs > 0) {
    return `${hrs}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export function formatBytes(bytes: number): string {
  if (!bytes) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  let idx = 0;
  let val = bytes;
  while (val >= 1024 && idx < units.length - 1) {
    val /= 1024;
    idx++;
  }
  return `${val.toFixed(idx === 0 ? 0 : 1)} ${units[idx]}`;
}

export function formatResolutionLabel(width?: number, height?: number): string | null {
  if (!height && !width) return null;
  const maxDim = Math.max(width || 0, height || 0);
  const h = height || 0;
  if (maxDim >= 3800 || h >= 2160) return '4K';
  if (maxDim >= 2500 || h >= 1440) return '2K';
  if (maxDim >= 1900 || h >= 1080) return '1080p';
  if (maxDim >= 1260 || h >= 720) return '720p';
  return h > 0 ? `${h}p` : null;
}

let dbPromise: Promise<IDBDatabase> | null = null;

function openDatabase(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_ITEMS)) {
        db.createObjectStore(STORE_ITEMS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_BLOBS)) {
        db.createObjectStore(STORE_BLOBS);
      }
      if (!db.objectStoreNames.contains(STORE_DIR_HANDLES)) {
        db.createObjectStore(STORE_DIR_HANDLES, { keyPath: 'id' });
      }
    };
    req.onsuccess = () => {
      const db = req.result;
      db.onclose = () => {
        dbPromise = null;
      };
      db.onversionchange = () => {
        db.close();
        dbPromise = null;
      };
      resolve(db);
    };
    req.onerror = () => {
      dbPromise = null;
      reject(req.error);
    };
  });
  return dbPromise;
}

export async function loadAllMediaItems(): Promise<MediaItem[]> {
  try {
    const db = await openDatabase();
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_ITEMS, 'readonly');
      const store = tx.objectStore(STORE_ITEMS);
      const req = store.getAll();
      req.onsuccess = () => {
        const list = (req.result as MediaItem[]) || [];
        resolve(list.sort((a, b) => b.addedAt - a.addedAt));
      };
      req.onerror = () => reject(req.error);
    });
  } catch {
    return [];
  }
}

export async function saveMediaItemWithBlob(item: MediaItem, blob: Blob): Promise<void> {
  const db = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction([STORE_ITEMS, STORE_BLOBS], 'readwrite');
    tx.objectStore(STORE_ITEMS).put(item);
    tx.objectStore(STORE_BLOBS).put(blob, item.id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function saveMediaItemsBatch(
  entries: Array<{ item: MediaItem; blob?: Blob }>
): Promise<void> {
  if (entries.length === 0) return;
  const db = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction([STORE_ITEMS, STORE_BLOBS], 'readwrite');
    const itemsStore = tx.objectStore(STORE_ITEMS);
    const blobsStore = tx.objectStore(STORE_BLOBS);
    for (const { item, blob } of entries) {
      itemsStore.put(item);
      if (blob) {
        blobsStore.put(blob, item.id);
      }
    }
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function updateMediaItemMetadata(item: MediaItem): Promise<void> {
  const db = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_ITEMS, 'readwrite');
    tx.objectStore(STORE_ITEMS).put(item);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function getMediaBlob(id: string): Promise<Blob | null> {
  try {
    const db = await openDatabase();
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_BLOBS, 'readonly');
      const req = tx.objectStore(STORE_BLOBS).get(id);
      req.onsuccess = () => resolve((req.result as Blob) || null);
      req.onerror = () => reject(req.error);
    });
  } catch {
    return null;
  }
}

export async function deleteMediaItem(id: string): Promise<void> {
  const db = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction([STORE_ITEMS, STORE_BLOBS], 'readwrite');
    tx.objectStore(STORE_ITEMS).delete(id);
    tx.objectStore(STORE_BLOBS).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function clearAllMediaLibrary(): Promise<void> {
  const db = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction([STORE_ITEMS, STORE_BLOBS], 'readwrite');
    tx.objectStore(STORE_ITEMS).clear();
    tx.objectStore(STORE_BLOBS).clear();
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function extractMediaMetadataFromUrl(
  mediaUrl: string,
  kind: MediaKind,
  revokeOnCleanup = false
): Promise<{
  duration: number;
  width?: number;
  height?: number;
  thumbnailUrl?: string;
}> {
  if (kind === 'audio') {
    return await new Promise((resolve) => {
      const audio = document.createElement('audio');
      audio.preload = 'metadata';
      let settled = false;
      const cleanup = () => {
        audio.onloadedmetadata = null;
        audio.onerror = null;
        audio.removeAttribute('src');
        audio.load();
        if (revokeOnCleanup) URL.revokeObjectURL(mediaUrl);
      };
      const finish = (duration: number) => {
        if (settled) return;
        settled = true;
        window.clearTimeout(timer);
        cleanup();
        resolve({ duration });
      };
      const timer = window.setTimeout(() => finish(0), 1400);

      audio.onloadedmetadata = () => {
        finish(Number.isFinite(audio.duration) ? audio.duration : 0);
      };
      audio.onerror = () => finish(0);
      audio.src = mediaUrl;
    });
  }

  // Video: leer duración, resolución y capturar miniatura ligera con límite de tiempo ágil
  return await new Promise((resolve) => {
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.muted = true;
    video.playsInline = true;
    let settled = false;
    let seekTimer: number | null = null;

    const cleanup = () => {
      video.onloadedmetadata = null;
      video.onseeked = null;
      video.onerror = null;
      if (seekTimer !== null) window.clearTimeout(seekTimer);
      video.removeAttribute('src');
      video.load();
      if (revokeOnCleanup) URL.revokeObjectURL(mediaUrl);
    };

    const finish = (result: {
      duration: number;
      width?: number;
      height?: number;
      thumbnailUrl?: string;
    }) => {
      if (settled) return;
      settled = true;
      window.clearTimeout(timer);
      cleanup();
      resolve(result);
    };

    const timer = window.setTimeout(() => {
      const duration = Number.isFinite(video.duration) ? video.duration : 0;
      const width = video.videoWidth || undefined;
      const height = video.videoHeight || undefined;
      finish({ duration, width, height });
    }, 2200);

    video.onloadedmetadata = () => {
      const duration = Number.isFinite(video.duration) ? video.duration : 0;
      const width = video.videoWidth || undefined;
      const height = video.videoHeight || undefined;

      if (duration > 0.4 && width && height) {
        seekTimer = window.setTimeout(() => {
          finish({ duration, width, height });
        }, 900);
        video.currentTime = Math.min(1.2, duration * 0.1);
      } else {
        finish({ duration, width, height });
      }
    };

    video.onseeked = () => {
      let thumbnailUrl: string | undefined;
      try {
        const canvas = document.createElement('canvas');
        const targetW = 240;
        const ratio = video.videoHeight / Math.max(1, video.videoWidth);
        canvas.width = targetW;
        canvas.height = Math.max(100, Math.round(targetW * ratio));
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          thumbnailUrl = canvas.toDataURL('image/jpeg', 0.62);
        }
      } catch {
        thumbnailUrl = undefined;
      }
      const duration = Number.isFinite(video.duration) ? video.duration : 0;
      const width = video.videoWidth || undefined;
      const height = video.videoHeight || undefined;
      finish({ duration, width, height, thumbnailUrl });
    };

    video.onerror = () => finish({ duration: 0 });
    video.src = mediaUrl;
  });
}

export async function extractMediaMetadata(
  file: File,
  kind: MediaKind
): Promise<{
  duration: number;
  width?: number;
  height?: number;
  thumbnailUrl?: string;
}> {
  const tempUrl = URL.createObjectURL(file);
  return extractMediaMetadataFromUrl(tempUrl, kind, true);
}

export function loadSavedSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_APP_SETTINGS;
    const parsed = JSON.parse(raw) as Partial<AppSettings>;
    return {
      ...DEFAULT_APP_SETTINGS,
      ...parsed,
      equalizer: {
        ...DEFAULT_APP_SETTINGS.equalizer,
        ...(parsed.equalizer || {}),
      },
      subtitleStyle: {
        ...DEFAULT_APP_SETTINGS.subtitleStyle,
        ...(parsed.subtitleStyle || {}),
      },
    };
  } catch {
    return DEFAULT_APP_SETTINGS;
  }
}

export function saveSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    // Ignorar error de cuota
  }
}

const SUBTITLE_EXTS = new Set(['srt', 'vtt', 'ass', 'ssa']);

// Recorre recursivamente una carpeta usando File System Access API
export async function scanDirectoryHandle(
  dirHandle: FileSystemDirectoryHandle,
  maxFiles = 500
): Promise<File[]> {
  const files: File[] = [];

  async function walk(handle: FileSystemDirectoryHandle) {
    if (files.length >= maxFiles) return;
    for await (const entry of handle.values()) {
      if (files.length >= maxFiles) break;
      if (entry.kind === 'file') {
        const file = await entry.getFile();
        const ext = file.name.split('.').pop()?.toLowerCase() || '';
        if (detectMediaKind(file) || SUBTITLE_EXTS.has(ext)) {
          files.push(file);
        }
      } else if (entry.kind === 'directory') {
        await walk(entry);
      }
    }
  }

  await walk(dirHandle);
  return files;
}

export async function checkStoragePermissionStatus(): Promise<StoragePermissionStatus> {
  if (typeof navigator === 'undefined' || !navigator.storage) {
    return { supported: false, persisted: false, usageBytes: 0, quotaBytes: 0 };
  }
  let persisted = false;
  let usageBytes = 0;
  let quotaBytes = 0;
  try {
    if (typeof navigator.storage.persisted === 'function') {
      persisted = await navigator.storage.persisted();
    }
    if (typeof navigator.storage.estimate === 'function') {
      const est = await navigator.storage.estimate();
      usageBytes = est.usage || 0;
      quotaBytes = est.quota || 0;
    }
  } catch {
    // Ignorar si el navegador restringe la API de almacenamiento
  }
  return {
    supported: typeof navigator.storage.persist === 'function',
    persisted,
    usageBytes,
    quotaBytes,
  };
}

export async function requestPersistentStorage(): Promise<{
  supported: boolean;
  persisted: boolean;
}> {
  if (typeof navigator === 'undefined' || !navigator.storage?.persist) {
    return { supported: false, persisted: false };
  }
  try {
    const persisted = await navigator.storage.persist();
    return { supported: true, persisted };
  } catch {
    return { supported: true, persisted: false };
  }
}

export async function loadDirectoryHandles(): Promise<SavedDirectoryEntry[]> {
  try {
    const db = await openDatabase();
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_DIR_HANDLES, 'readonly');
      const req = tx.objectStore(STORE_DIR_HANDLES).getAll();
      req.onsuccess = () => {
        const list = (req.result as SavedDirectoryEntry[]) || [];
        resolve(list.sort((a, b) => b.addedAt - a.addedAt));
      };
      req.onerror = () => reject(req.error);
    });
  } catch {
    return [];
  }
}

export async function saveDirectoryHandle(
  handle: FileSystemDirectoryHandle
): Promise<SavedDirectoryEntry> {
  const existing = await loadDirectoryHandles();
  for (const entry of existing) {
    try {
      if (typeof handle.isSameEntry === 'function' && (await handle.isSameEntry(entry.handle))) {
        return entry;
      }
    } catch {
      if (entry.name === handle.name) return entry;
    }
  }
  const item: SavedDirectoryEntry = {
    id: `dir-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    name: handle.name || 'Carpeta local',
    addedAt: Date.now(),
    handle,
  };
  const db = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_DIR_HANDLES, 'readwrite');
    tx.objectStore(STORE_DIR_HANDLES).put(item);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  return item;
}

export async function deleteDirectoryHandle(id: string): Promise<void> {
  const db = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_DIR_HANDLES, 'readwrite');
    tx.objectStore(STORE_DIR_HANDLES).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function verifyDirectoryPermission(
  handle: FileSystemDirectoryHandle,
  askIfNeeded: boolean
): Promise<boolean> {
  const permHandle = handle as FileSystemDirectoryHandle & {
    queryPermission?: (desc: { mode: 'read' }) => Promise<PermissionState>;
    requestPermission?: (desc: { mode: 'read' }) => Promise<PermissionState>;
  };
  try {
    if (typeof permHandle.queryPermission === 'function') {
      const state = await permHandle.queryPermission({ mode: 'read' });
      if (state === 'granted') return true;
    }
    if (askIfNeeded && typeof permHandle.requestPermission === 'function') {
      const req = await permHandle.requestPermission({ mode: 'read' });
      return req === 'granted';
    }
  } catch {
    return false;
  }
  return false;
}

// Genera una pista de audio WAV local y un clip WebM local con subtítulos SRT de prueba (100% offline, sin internet)
export async function generateOfflineDemoMedia(): Promise<
  Array<{ file: File; subtitleName?: string; subtitleRaw?: string }>
> {
  const results: Array<{ file: File; subtitleName?: string; subtitleRaw?: string }> = [];

  // 1. Pista musical armónica WAV sintetizada localmente (16 segundos, 44.1 kHz estéreo)
  const sampleRate = 44100;
  const durationSec = 16;
  const numSamples = sampleRate * durationSec;
  const buffer = new ArrayBuffer(44 + numSamples * 4);
  const view = new DataView(buffer);

  const writeStr = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeStr(0, 'RIFF');
  view.setUint32(4, 36 + numSamples * 4, true);
  writeStr(8, 'WAVE');
  writeStr(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 2, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 4, true);
  view.setUint16(32, 4, true);
  view.setUint16(34, 16, true);
  writeStr(36, 'data');
  view.setUint32(40, numSamples * 4, true);

  const chords = [
    [130.81, 196.0, 246.94, 293.66], // Cmaj9
    [110.0, 164.81, 220.0, 261.63],  // Am7
    [87.31, 130.81, 174.61, 220.0],  // Fmaj7
    [98.0, 146.83, 196.0, 246.94],   // G6
  ];

  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    const chordIdx = Math.floor(t / 4) % chords.length;
    const localT = t % 4;
    const env = Math.min(1, localT * 2.5) * Math.min(1, (4 - localT) * 1.4);
    const pulse = 0.75 + 0.25 * Math.sin(2 * Math.PI * 1.5 * t);
    const chord = chords[chordIdx];

    let sampleL = 0;
    let sampleR = 0;
    chord.forEach((freq, idx) => {
      const wave = Math.sin(2 * Math.PI * freq * t) + 0.22 * Math.sin(2 * Math.PI * freq * 2 * t);
      const pan = idx % 2 === 0 ? 0.65 : 0.35;
      sampleL += wave * pan;
      sampleR += wave * (1 - pan);
    });

    // Pulso de subgrave suave cada 0.5s para probar el ecualizador
    const beatT = t % 0.5;
    const kick = Math.sin(2 * Math.PI * 55 * beatT) * Math.exp(-beatT * 10) * 0.45;

    const outL = Math.max(-0.95, Math.min(0.95, (sampleL * 0.14 * env * pulse + kick)));
    const outR = Math.max(-0.95, Math.min(0.95, (sampleR * 0.14 * env * pulse + kick)));

    view.setInt16(44 + i * 4, Math.floor(outL * 32767), true);
    view.setInt16(44 + i * 4 + 2, Math.floor(outR * 32767), true);
  }

  const audioFile = new File([buffer], 'Estudio Acústico - Armonía Nocturna.wav', {
    type: 'audio/wav',
  });
  results.push({ file: audioFile });

  // 2. Clip de video WebM local si MediaRecorder soporta canvas stream
  if (typeof MediaRecorder !== 'undefined') {
    try {
      const canvas = document.createElement('canvas');
      canvas.width = 640;
      canvas.height = 360;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        const stream = canvas.captureStream(24);
        const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
          ? 'video/webm;codecs=vp9'
          : 'video/webm';
        const recorder = new MediaRecorder(stream, { mimeType });
        const chunks: Blob[] = [];
        recorder.ondataavailable = (e) => {
          if (e.data.size > 0) chunks.push(e.data);
        };

        const recorded = await new Promise<Blob>((resolve) => {
          recorder.onstop = () => resolve(new Blob(chunks, { type: 'video/webm' }));
          recorder.start();
          let frame = 0;
          const totalFrames = 96; // ~4 segundos
          const draw = () => {
            const p = frame / totalFrames;
            const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
            grad.addColorStop(0, '#0b0d12');
            grad.addColorStop(1, '#1e293b');
            ctx.fillStyle = grad;
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            // Círculos orbitales suaves
            for (let k = 0; k < 5; k++) {
              ctx.beginPath();
              ctx.strokeStyle = `rgba(245, 158, 11, ${0.18 + k * 0.12})`;
              ctx.lineWidth = 2;
              const radius = 36 + k * 26 + Math.sin(p * Math.PI * 4 + k) * 10;
              ctx.arc(canvas.width / 2, canvas.height / 2, radius, 0, Math.PI * 2);
              ctx.stroke();
            }

            frame++;
            if (frame < totalFrames) {
              requestAnimationFrame(draw);
            } else {
              recorder.stop();
            }
          };
          draw();
        });

        const videoFile = new File([recorded], 'Prueba de Video - Horizonte.webm', {
          type: 'video/webm',
        });
        const sampleSrt = [
          '1',
          '00:00:00,200 --> 00:00:02,000',
          'Reproducción local fluida sin conexión a internet.',
          '',
          '2',
          '00:00:02,100 --> 00:00:04,000',
          'Subtítulos personalizados activos en 琥音Hǔyīn.',
        ].join('\n');

        results.push({
          file: videoFile,
          subtitleName: 'subtitulos_prueba.srt',
          subtitleRaw: sampleSrt,
        });
      }
    } catch {
      // Si MediaRecorder no está disponible, omitir clip de prueba
    }
  }

  return results;
}
