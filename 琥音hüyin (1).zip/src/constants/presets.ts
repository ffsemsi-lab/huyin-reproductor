import type {
  AppSettings,
  BackdropId,
  EqualizerPresetId,
  HeadphoneModeId,
  ThemeId,
} from '../types/media';

export const EQ_FREQUENCIES = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000] as const;

export const EQ_BAND_LABELS = [
  '31 Hz',
  '62 Hz',
  '125 Hz',
  '250 Hz',
  '500 Hz',
  '1 kHz',
  '2 kHz',
  '4 kHz',
  '8 kHz',
  '16 kHz',
] as const;

export interface EqualizerPreset {
  id: EqualizerPresetId;
  name: string;
  bands: number[];
}

export const EQ_PRESETS: EqualizerPreset[] = [
  { id: 'plano', name: 'Plano (Normal)', bands: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0] },
  { id: 'graves', name: 'Graves Profundos', bands: [6, 5, 4, 2, 0, -1, 0, 1, 2, 2] },
  { id: 'acustico', name: 'Acústico', bands: [2, 2, 1, 0, 1, 2, 3, 3, 2, 1] },
  { id: 'clasica', name: 'Clásica', bands: [3, 2, 1, 0, -1, 0, 1, 3, 4, 3] },
  { id: 'electronica', name: 'Electrónica', bands: [5, 4, 2, 0, -2, 1, 2, 3, 4, 5] },
  { id: 'pop', name: 'Pop', bands: [-1, 1, 3, 4, 3, 0, -1, 1, 2, 2] },
  { id: 'rock', name: 'Rock', bands: [4, 3, 2, -1, -2, 0, 2, 4, 5, 4] },
  { id: 'vocal', name: 'Vocal y Diálogo', bands: [-3, -2, -1, 1, 4, 5, 4, 2, 0, -1] },
  { id: 'personalizado', name: 'Personalizado', bands: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0] },
];

export interface HeadphoneModeInfo {
  id: HeadphoneModeId;
  name: string;
  subtitle: string;
  description: string;
}

export const HEADPHONE_MODES: HeadphoneModeInfo[] = [
  {
    id: 'estandar',
    name: 'Estándar Directo',
    subtitle: 'Respuesta fiel sin coloración',
    description: 'Señal pura de salida tal como fue masterizada, respetando únicamente tu ecualizador.',
  },
  {
    id: 'estudio',
    name: 'Estudio de Referencia',
    subtitle: 'Crossfeed binaural de monitores',
    description: 'Mezcla sutilmente los canales izquierdo y derecho con retardo acústico para evitar fatiga auditiva en sesiones largas.',
  },
  {
    id: 'espacial',
    name: 'Escenario Envolvente',
    subtitle: 'Amplitud estereofónica 3D',
    description: 'Expande la escena sonora frente a ti mediante reflexión temprana sutil y separación de imagen estéreo.',
  },
  {
    id: 'iem',
    name: 'Monitores In-Ear (IEM Pro)',
    subtitle: 'Subgraves firmes y detalle vocal',
    description: 'Curva acústica calibrada para auriculares intraurales: limpia medios-graves y realza la definición de voces e instrumentos.',
  },
  {
    id: 'nocturno',
    name: 'Modo Nocturno',
    subtitle: 'Volumen equilibrado sin sobresaltos',
    description: 'Comprime el rango dinámico para escuchar diálogos y detalles suaves a bajo volumen sin picos molestos.',
  },
  {
    id: 'concierto',
    name: 'Sala de Conciertos',
    subtitle: 'Acústica cálida de auditorio',
    description: 'Convolución estéreo generada localmente que recrea la reverberación natural de una sala sinfónica.',
  },
];

export interface ThemeInfo {
  id: ThemeId;
  name: string;
  isDark: boolean;
  canvasPreview: string;
  surfacePreview: string;
  accentPreview: string;
}

export const PLAYER_THEMES: ThemeInfo[] = [
  {
    id: 'obsidiana',
    name: 'Obsidiana Nocturna',
    isDark: true,
    canvasPreview: '#0b0d12',
    surfacePreview: '#13161f',
    accentPreview: '#f59e0b',
  },
  {
    id: 'luz',
    name: 'Luz Pura',
    isDark: false,
    canvasPreview: '#f8fafc',
    surfacePreview: '#ffffff',
    accentPreview: '#2563eb',
  },
  {
    id: 'bosque',
    name: 'Bosque Profundo',
    isDark: true,
    canvasPreview: '#08100d',
    surfacePreview: '#101b16',
    accentPreview: '#10b981',
  },
  {
    id: 'ambar',
    name: 'Ámbar Vinilo',
    isDark: true,
    canvasPreview: '#120d0b',
    surfacePreview: '#1c1411',
    accentPreview: '#ea580c',
  },
  {
    id: 'medianoche',
    name: 'Azul Medianoche',
    isDark: true,
    canvasPreview: '#070c18',
    surfacePreview: '#0e1629',
    accentPreview: '#0ea5e9',
  },
];

export interface BackdropInfo {
  id: BackdropId;
  name: string;
  description: string;
  imageUrl: string;
}

export const BUILT_IN_BACKDROPS: BackdropInfo[] = [
  {
    id: 'estudio',
    name: 'Estudio Acústico',
    description: 'Luz cálida sobre madera y pizarra',
    imageUrl: '/src/assets/images/music_bg_studio_1795535300187.jpg',
  },
  {
    id: 'ondas',
    name: 'Ondas Nocturnas',
    description: 'Seda oscura con reflejos dorados',
    imageUrl: '/src/assets/images/music_bg_waves_1795535300544.jpg',
  },
  {
    id: 'vinilo',
    name: 'Vinilo y Nogal',
    description: 'Aluminio cepillado y nogal mate',
    imageUrl: '/src/assets/images/music_bg_vinyl_1795535301829.jpg',
  },
];

export const DEFAULT_APP_SETTINGS: AppSettings = {
  theme: 'obsidiana',
  backdrop: 'estudio',
  headphoneMode: 'estandar',
  equalizer: {
    enabled: true,
    presetId: 'plano',
    preampDb: 0,
    bands: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    bassBoostDb: 0,
    trebleClarityDb: 0,
    compressorEnabled: false,
  },
  subtitleStyle: {
    fontSize: 'mediano',
    color: 'blanco',
    background: 'sombra',
    position: 'inferior',
    syncOffsetSec: 0,
  },
};
