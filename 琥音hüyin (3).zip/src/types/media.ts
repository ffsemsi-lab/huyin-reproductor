export type NavSection = 'musica' | 'video' | 'ajustes';

export type MediaKind = 'audio' | 'video';

export interface SubtitleCue {
  id: number;
  start: number;
  end: number;
  text: string;
}

export interface SubtitleStyle {
  fontSize: 'pequeno' | 'mediano' | 'grande' | 'extragrande';
  color: 'blanco' | 'amarillo' | 'cian';
  background: 'transparente' | 'sombra' | 'caja';
  position: 'inferior' | 'media' | 'superior';
  syncOffsetSec: number;
}

export interface MediaItem {
  id: string;
  name: string;
  title: string;
  artist: string;
  kind: MediaKind;
  format: string;
  mimeType: string;
  size: number;
  duration: number;
  width?: number;
  height?: number;
  thumbnailUrl?: string;
  addedAt: number;
  lastModified: number;
  localPath?: string;
  subtitleName?: string;
  subtitleRaw?: string;
}

export type EqualizerPresetId =
  | 'plano'
  | 'graves'
  | 'acustico'
  | 'clasica'
  | 'electronica'
  | 'pop'
  | 'rock'
  | 'vocal'
  | 'personalizado';

export interface EqualizerSettings {
  enabled: boolean;
  presetId: EqualizerPresetId;
  preampDb: number;
  bands: number[]; // 10 bandas en dB (-12 a +12)
  bassBoostDb: number; // 0 a +10 dB
  trebleClarityDb: number; // 0 a +10 dB
  compressorEnabled: boolean;
}

export type HeadphoneModeId =
  | 'estandar'
  | 'estudio'
  | 'espacial'
  | 'iem'
  | 'nocturno'
  | 'concierto';

export type ThemeId =
  | 'obsidiana'
  | 'luz'
  | 'bosque'
  | 'ambar'
  | 'medianoche';

export type BackdropId = 'estudio' | 'ondas' | 'vinilo';

export type RepeatMode = 'ninguno' | 'lista' | 'pista';

export interface AppSettings {
  theme: ThemeId;
  backdrop: BackdropId;
  headphoneMode: HeadphoneModeId;
  equalizer: EqualizerSettings;
  subtitleStyle: SubtitleStyle;
  batterySaverEnabled: boolean;
}
