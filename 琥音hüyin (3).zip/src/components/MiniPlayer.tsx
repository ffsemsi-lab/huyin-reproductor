import { Disc3, Maximize2, Pause, Play, SkipBack, SkipForward } from 'lucide-react';
import { motion } from 'motion/react';
import { useEffect, useState } from 'react';
import type { MediaItem } from '../types/media';
import { formatDuration } from '../utils/libraryDb';

interface MiniPlayerProps {
  track: MediaItem;
  audioEl: HTMLAudioElement | null;
  isPlaying: boolean;
  duration: number;
  onExpand: () => void;
  onTogglePlay: () => void;
  onPrev: () => void;
  onNext: () => void;
}

export function MiniPlayer({
  track,
  audioEl,
  isPlaying,
  duration,
  onExpand,
  onTogglePlay,
  onPrev,
  onNext,
}: MiniPlayerProps) {
  const [currentTime, setCurrentTime] = useState(() => audioEl?.currentTime || 0);

  useEffect(() => {
    if (!audioEl) return;
    setCurrentTime(audioEl.currentTime || 0);
    const onTimeUpdate = () => {
      if (document.visibilityState === 'hidden') return;
      setCurrentTime(audioEl.currentTime || 0);
    };
    audioEl.addEventListener('timeupdate', onTimeUpdate);
    return () => audioEl.removeEventListener('timeupdate', onTimeUpdate);
  }, [audioEl, track.id]);

  const pct = duration > 0 ? Math.min(100, (currentTime / duration) * 100) : 0;

  return (
    <motion.div
      initial={{ y: 24, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={{ y: 24, opacity: 0 }}
      transition={{ duration: 0.2 }}
      className="fixed bottom-[calc(60px+env(safe-area-inset-bottom))] md:bottom-4 left-0 right-0 md:left-auto md:right-6 md:w-[440px] z-30 border-t md:border md:rounded-2xl shadow-2xl overflow-hidden"
      style={{
        backgroundColor: 'var(--bg-surface)',
        borderColor: 'var(--border-subtle)',
      }}
    >
      <div className="h-0.5 w-full" style={{ backgroundColor: 'var(--border-subtle)' }}>
        <div
          className="h-full transition-all duration-200"
          style={{ width: `${pct}%`, backgroundColor: 'var(--accent)' }}
        />
      </div>

      <div className="flex items-center justify-between gap-3 px-4 py-2.5">
        <button
          type="button"
          onClick={onExpand}
          className="flex min-w-0 flex-1 items-center gap-3 text-left cursor-pointer"
          aria-label="Abrir reproductor de música"
        >
          <div
            className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${
              isPlaying ? 'animate-vinyl' : 'animate-vinyl-paused'
            }`}
            style={{ backgroundColor: 'var(--accent-soft)', color: 'var(--accent)' }}
          >
            <Disc3 className="h-5 w-5" aria-hidden="true" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>
              {track.title}
            </p>
            <p className="font-mono-tabular truncate text-xs" style={{ color: 'var(--text-secondary)' }}>
              {track.artist} · {formatDuration(currentTime)} / {formatDuration(duration || track.duration)}
            </p>
          </div>
        </button>

        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={onPrev}
            aria-label="Anterior"
            className="hidden sm:flex min-h-[40px] min-w-[40px] items-center justify-center rounded-xl transition-colors cursor-pointer"
            style={{ color: 'var(--text-secondary)' }}
          >
            <SkipBack className="h-4 w-4" aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={onTogglePlay}
            aria-label={isPlaying ? 'Pausar' : 'Reproducir'}
            className="flex h-10 w-10 items-center justify-center rounded-xl transition-transform active:scale-95 cursor-pointer"
            style={{ backgroundColor: 'var(--accent)', color: 'var(--accent-contrast)' }}
          >
            {isPlaying ? (
              <Pause className="h-4 w-4 fill-current" aria-hidden="true" />
            ) : (
              <Play className="h-4 w-4 fill-current ml-0.5" aria-hidden="true" />
            )}
          </button>

          <button
            type="button"
            onClick={onNext}
            aria-label="Siguiente"
            className="flex min-h-[40px] min-w-[40px] items-center justify-center rounded-xl transition-colors cursor-pointer"
            style={{ color: 'var(--text-secondary)' }}
          >
            <SkipForward className="h-4 w-4" aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={onExpand}
            aria-label="Expandir reproductor"
            className="flex min-h-[40px] min-w-[40px] items-center justify-center rounded-xl transition-colors cursor-pointer"
            style={{ color: 'var(--text-secondary)' }}
          >
            <Maximize2 className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}
