import {
  ArrowLeft,
  Captions,
  FileText,
  Loader2,
  Lock,
  Maximize,
  Minimize,
  Pause,
  PictureInPicture2,
  Play,
  RotateCcw,
  RotateCw,
  SlidersHorizontal,
  Sun,
  Unlock,
  Upload,
  Volume1,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { MediaItem, SubtitleStyle } from '../types/media';
import { audioEngine } from '../utils/audioEngine';
import { formatDuration, formatResolutionLabel } from '../utils/libraryDb';
import { getActiveSubtitles, parseSubtitleContent, readSubtitleFile } from '../utils/subtitles';

interface VideoPlayerModalProps {
  video: MediaItem;
  videoUrl: string | null;
  subtitleStyle: SubtitleStyle;
  onUpdateSubtitleStyle: (style: SubtitleStyle) => void;
  onAttachSubtitles: (videoId: string, subtitleName: string, subtitleRaw: string) => void;
  onOpenAudioSettings: () => void;
  onClose: () => void;
}

type AspectMode = 'ajustar' | 'rellenar' | '16:9' | '4:3';

export function VideoPlayerModal({
  video,
  videoUrl,
  subtitleStyle,
  onUpdateSubtitleStyle,
  onAttachSubtitles,
  onOpenAudioSettings,
  onClose,
}: VideoPlayerModalProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const subInputRef = useRef<HTMLInputElement | null>(null);
  const hideTimerRef = useRef<number | null>(null);
  const leftTimerRef = useRef<number | null>(null);
  const rightTimerRef = useRef<number | null>(null);
  const lastNonZeroVolumeRef = useRef(1);

  const [isPlaying, setIsPlaying] = useState(true);
  const [isBuffering, setIsBuffering] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(video.duration || 0);
  const [brightness, setBrightness] = useState(1); // 0.15 a 1.0 (máximo 100%)
  const [volume, setVolume] = useState(1); // 0 a 1.0 (máximo 100%, solo en video)
  const [playbackRate, setPlaybackRate] = useState(1);
  const [aspectMode, setAspectMode] = useState<AspectMode>('ajustar');
  const [isLocked, setIsLocked] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [showSubPanel, setShowSubPanel] = useState(false);
  const [subtitlesEnabled, setSubtitlesEnabled] = useState(true);
  const [useEqForVideo, setUseEqForVideo] = useState(false);
  const [codecError, setCodecError] = useState<string | null>(null);

  // Barras laterales: IZQUIERDA Brillo (máx 100%), DERECHA Volumen (máx 100%)
  const [showLeftBrightness, setShowLeftBrightness] = useState(false);
  const [showRightVolume, setShowRightVolume] = useState(false);

  // Estado del gesto vertical táctil/puntero (izquierda: brillo, derecha: volumen)
  const gestureRef = useRef<{
    side: 'left' | 'right' | null;
    startY: number;
    startVal: number;
    moved: boolean;
  }>({ side: null, startY: 0, startVal: 1, moved: false });

  const resolutionLabel = formatResolutionLabel(video.width, video.height);

  const cues = useMemo(
    () => (video.subtitleRaw ? parseSubtitleContent(video.subtitleRaw) : []),
    [video.subtitleRaw]
  );

  const activeCues = useMemo(
    () =>
      subtitlesEnabled
        ? getActiveSubtitles(cues, currentTime, subtitleStyle.syncOffsetSec)
        : [],
    [cues, currentTime, subtitleStyle.syncOffsetSec, subtitlesEnabled]
  );

  const revealLeftBrightness = useCallback(() => {
    setShowLeftBrightness(true);
    if (leftTimerRef.current) window.clearTimeout(leftTimerRef.current);
    leftTimerRef.current = window.setTimeout(() => {
      setShowLeftBrightness(false);
    }, 2400);
  }, []);

  const revealRightVolume = useCallback(() => {
    setShowRightVolume(true);
    if (rightTimerRef.current) window.clearTimeout(rightTimerRef.current);
    rightTimerRef.current = window.setTimeout(() => {
      setShowRightVolume(false);
    }, 2400);
  }, []);

  const scheduleHideControls = useCallback(() => {
    if (hideTimerRef.current) window.clearTimeout(hideTimerRef.current);
    setShowControls(true);
    if (isPlaying && !showSubPanel) {
      hideTimerRef.current = window.setTimeout(() => {
        setShowControls(false);
      }, 3000);
    }
  }, [isPlaying, showSubPanel]);

  useEffect(() => {
    scheduleHideControls();
    return () => {
      if (hideTimerRef.current) window.clearTimeout(hideTimerRef.current);
      if (leftTimerRef.current) window.clearTimeout(leftTimerRef.current);
      if (rightTimerRef.current) window.clearTimeout(rightTimerRef.current);
    };
  }, [scheduleHideControls]);

  // Decodificación directa por hardware por defecto para 2K/4K sin retraso; conecta EQ solo si el usuario lo activa
  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;
    if (useEqForVideo) {
      audioEngine.connectMediaElement(el);
      audioEngine.resume();
    }
  }, [useEqForVideo, videoUrl]);

  // Sincronizar volumen (máx 100%) y velocidad con el elemento de video
  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;
    const clampedVol = Math.max(0, Math.min(1, volume));
    el.volume = clampedVol;
    el.muted = clampedVol === 0;
  }, [volume, videoUrl]);

  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;
    el.playbackRate = playbackRate;
  }, [playbackRate, videoUrl]);

  useEffect(() => {
    const el = videoRef.current;
    if (!el || !videoUrl) return;

    let cancelled = false;
    setIsBuffering(true);
    setCodecError(null);

    const tryStart = () => {
      if (cancelled) return;
      el.volume = Math.max(0, Math.min(1, volume));
      el.muted = volume === 0;
      el.playbackRate = playbackRate;
      el.play()
        .then(() => {
          if (!cancelled) {
            setIsPlaying(true);
            setIsBuffering(false);
          }
        })
        .catch(() => {
          if (cancelled) return;
          const retryOnCanPlay = () => {
            if (cancelled) return;
            el.play()
              .then(() => {
                if (!cancelled) {
                  setIsPlaying(true);
                  setIsBuffering(false);
                }
              })
              .catch(() => {
                if (!cancelled) {
                  setIsPlaying(false);
                  setIsBuffering(false);
                }
              });
          };
          el.addEventListener('canplay', retryOnCanPlay, { once: true });
        });
    };

    tryStart();

    // Liberar memoria de decodificación al cerrar el reproductor o cambiar archivo
    return () => {
      cancelled = true;
      el.pause();
      el.removeAttribute('src');
      el.load();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [videoUrl]);

  useEffect(() => {
    const onFsChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  const togglePlay = useCallback(() => {
    const el = videoRef.current;
    if (!el || !videoUrl) return;
    if (useEqForVideo) audioEngine.resume();
    if (el.paused) {
      el.play().then(() => setIsPlaying(true)).catch(() => {});
    } else {
      el.pause();
      setIsPlaying(false);
    }
  }, [useEqForVideo, videoUrl]);

  const skipBy = useCallback((deltaSec: number) => {
    const el = videoRef.current;
    if (!el) return;
    el.currentTime = Math.max(0, Math.min(el.duration || 0, el.currentTime + deltaSec));
    setCurrentTime(el.currentTime);
  }, []);

  const toggleFullscreen = useCallback(() => {
    const target = containerRef.current;
    if (!target) return;
    if (!document.fullscreenElement) {
      target.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  }, []);

  const togglePiP = useCallback(async () => {
    const el = videoRef.current;
    if (!el || !document.pictureInPictureEnabled) return;
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
      } else {
        await el.requestPictureInPicture();
      }
    } catch {
      // Ignorar si no es compatible
    }
  }, []);

  // Brillo estrictamente limitado de 15% a 100%
  const applyBrightness = useCallback(
    (nextBrightness: number) => {
      const clamped = Math.max(0.15, Math.min(1, nextBrightness));
      setBrightness(clamped);
      revealLeftBrightness();
    },
    [revealLeftBrightness]
  );

  // Volumen estrictamente limitado de 0% a 100% (solo en video)
  const applyVolume = useCallback(
    (nextVolume: number) => {
      const clamped = Math.max(0, Math.min(1, nextVolume));
      if (clamped > 0.01) {
        lastNonZeroVolumeRef.current = clamped;
      }
      setVolume(clamped);
      revealRightVolume();
    },
    [revealRightVolume]
  );

  const toggleMute = useCallback(() => {
    if (volume > 0) {
      lastNonZeroVolumeRef.current = volume;
      applyVolume(0);
    } else {
      applyVolume(lastNonZeroVolumeRef.current > 0.05 ? lastNonZeroVolumeRef.current : 0.75);
    }
  }, [volume, applyVolume]);

  // Atajos de teclado
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (isLocked) return;
      if (e.key === ' ' || e.key === 'k') {
        e.preventDefault();
        togglePlay();
      } else if (e.key === 'ArrowRight') {
        skipBy(10);
      } else if (e.key === 'ArrowLeft') {
        skipBy(-10);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        applyVolume(volume + 0.05);
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        applyVolume(volume - 0.05);
      } else if (e.key === 'm' || e.key === 'M') {
        toggleMute();
      } else if (e.key === 'f' || e.key === 'F') {
        toggleFullscreen();
      } else if (e.key === 'Escape' && !document.fullscreenElement) {
        onClose();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isLocked, togglePlay, skipBy, applyVolume, volume, toggleMute, toggleFullscreen, onClose]);

  const handleSubtitleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const raw = await readSubtitleFile(file);
    onAttachSubtitles(video.id, file.name, raw);
    setSubtitlesEnabled(true);
    e.target.value = '';
  };

  const cycleSpeed = () => {
    const speeds = [0.5, 0.75, 1, 1.25, 1.5, 2];
    const idx = speeds.indexOf(playbackRate);
    const next = speeds[(idx + 1) % speeds.length];
    setPlaybackRate(next);
    if (videoRef.current) videoRef.current.playbackRate = next;
  };

  const cycleAspect = () => {
    const modes: AspectMode[] = ['ajustar', 'rellenar', '16:9', '4:3'];
    const idx = modes.indexOf(aspectMode);
    setAspectMode(modes[(idx + 1) % modes.length]);
  };

  // Gesto táctil / puntero: mitad izquierda = Brillo (máx 100%), mitad derecha = Volumen (máx 100%)
  const handleSurfacePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isLocked) return;
    if (e.pointerType === 'mouse' && e.button !== 0) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const isLeft = e.clientX - rect.left < rect.width / 2;
    const side: 'left' | 'right' = isLeft ? 'left' : 'right';

    gestureRef.current = {
      side,
      startY: e.clientY,
      startVal: side === 'left' ? brightness : volume,
      moved: false,
    };

    if (side === 'left') {
      revealLeftBrightness();
    } else {
      revealRightVolume();
    }
  };

  const handleSurfacePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isLocked) return;
    const g = gestureRef.current;

    if (!g.side) {
      const rect = e.currentTarget.getBoundingClientRect();
      const relX = e.clientX - rect.left;
      if (relX < rect.width * 0.25) {
        revealLeftBrightness();
      } else if (relX > rect.width * 0.75) {
        revealRightVolume();
      }
      scheduleHideControls();
      return;
    }

    const deltaY = g.startY - e.clientY;
    if (Math.abs(deltaY) > 8) {
      g.moved = true;
      const sensitivity = Math.max(180, window.innerHeight * 0.42);
      if (g.side === 'left') {
        const nextB = g.startVal + (deltaY / sensitivity) * 0.85;
        applyBrightness(nextB);
      } else {
        const nextV = g.startVal + (deltaY / sensitivity) * 1.0;
        applyVolume(nextV);
      }
    }
  };

  const handleSurfacePointerUp = () => {
    const g = gestureRef.current;
    const wasTap = !g.moved;
    gestureRef.current = { side: null, startY: 0, startVal: 1, moved: false };
    if (wasTap && !isLocked) {
      if (showControls) {
        setShowControls(false);
      } else {
        scheduleHideControls();
      }
    }
  };

  const videoObjectClass =
    aspectMode === 'rellenar'
      ? 'w-full h-full object-cover'
      : aspectMode === '16:9'
        ? 'w-full aspect-video object-fill max-h-full'
        : aspectMode === '4:3'
          ? 'h-full aspect-[4/3] object-fill max-w-full'
          : 'max-h-full max-w-full object-contain';

  const subFontSizeClass =
    subtitleStyle.fontSize === 'pequeno'
      ? 'text-sm sm:text-base'
      : subtitleStyle.fontSize === 'grande'
        ? 'text-xl sm:text-2xl'
        : subtitleStyle.fontSize === 'extragrande'
          ? 'text-2xl sm:text-3xl'
          : 'text-base sm:text-xl';

  const subColorStyle =
    subtitleStyle.color === 'amarillo'
      ? '#fde047'
      : subtitleStyle.color === 'cian'
        ? '#67e8f9'
        : '#ffffff';

  const subBgStyle =
    subtitleStyle.background === 'caja'
      ? 'bg-black/80 px-3.5 py-1.5 rounded-lg'
      : subtitleStyle.background === 'sombra'
        ? 'px-2 py-1 drop-shadow-[0_2px_6px_rgba(0,0,0,0.95)]'
        : 'px-2 py-1';

  const subPositionClass =
    subtitleStyle.position === 'superior'
      ? 'top-16'
      : subtitleStyle.position === 'media'
        ? 'top-1/2 -translate-y-1/2'
        : 'bottom-24';

  const brightnessPercent = Math.min(100, Math.round(brightness * 100));
  const volumePercent = Math.min(100, Math.round(volume * 100));

  const VolumeIcon = volume === 0 ? VolumeX : volume < 0.5 ? Volume1 : Volume2;

  return (
    <motion.div
      ref={containerRef}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2 }}
      onPointerDown={handleSurfacePointerDown}
      onPointerMove={handleSurfacePointerMove}
      onPointerUp={handleSurfacePointerUp}
      onPointerCancel={() => {
        gestureRef.current.side = null;
      }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black text-white select-none touch-none"
      role="dialog"
      aria-modal="true"
      aria-label={`Reproductor de video: ${video.title}`}
    >
      {/* Elemento de video optimizado para decodificación fluida hasta 2K/4K */}
      {videoUrl && (
        <video
          ref={videoRef}
          src={videoUrl}
          playsInline
          preload="auto"
          onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
          onLoadedMetadata={(e) => {
            const el = e.currentTarget;
            el.volume = Math.max(0, Math.min(1, volume));
            el.muted = volume === 0;
            el.playbackRate = playbackRate;
            setDuration(el.duration || video.duration || 0);
            setCodecError(null);
          }}
          onLoadedData={() => setIsBuffering(false)}
          onCanPlay={() => setIsBuffering(false)}
          onWaiting={() => setIsBuffering(true)}
          onPlaying={() => {
            setIsBuffering(false);
            setIsPlaying(true);
          }}
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
          onEnded={() => setIsPlaying(false)}
          onError={() => {
            setIsBuffering(false);
            setCodecError(
              'Este contenedor o códec de video no es compatible de forma nativa con este navegador. Prueba con MP4 (H.264/AAC) o WebM (VP9/Opus).'
            );
          }}
          style={{
            transform: 'translateZ(0)',
          }}
          className={videoObjectClass}
        />
      )}

      {/* Indicador breve mientras carga el video */}
      {(!videoUrl || isBuffering) && !codecError && (
        <div className="pointer-events-none absolute inset-0 z-10 flex flex-col items-center justify-center gap-2.5 bg-black/40">
          <Loader2 className="h-9 w-9 animate-spin text-amber-400" aria-hidden="true" />
          <span className="text-xs font-medium text-white/80">Cargando video...</span>
        </div>
      )}

      {/* Capa ligera de atenuación de brillo (tope 100%, sin coste de shader) */}
      {brightness < 1 && (
        <div
          className="pointer-events-none absolute inset-0 bg-black"
          style={{ opacity: Math.min(0.85, 1 - brightness) }}
        />
      )}

      {/* Barra lateral IZQUIERDA de Brillo (15% - 100%) */}
      <AnimatePresence>
        {showLeftBrightness && !isLocked && (
          <motion.div
            initial={{ opacity: 0, x: -12 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -12 }}
            transition={{ duration: 0.18 }}
            onPointerDown={(e) => e.stopPropagation()}
            onPointerMove={(e) => e.stopPropagation()}
            onPointerUp={(e) => e.stopPropagation()}
            onClick={(e) => e.stopPropagation()}
            className="absolute left-3 sm:left-5 top-1/2 -translate-y-1/2 z-30 flex flex-col items-center gap-2.5 rounded-2xl border border-white/15 bg-black/75 px-2.5 py-3.5 backdrop-blur-md shadow-2xl"
          >
            <Sun className="h-4 w-4 text-amber-400" aria-hidden="true" />
            <div className="flex h-36 items-center justify-center">
              <input
                type="range"
                min={0.15}
                max={1}
                step={0.02}
                value={brightness}
                onChange={(e) => applyBrightness(Number(e.target.value))}
                aria-label="Brillo de video"
                className="eq-slider h-32 w-8"
              />
            </div>
            <span className="font-mono-tabular text-[11px] font-semibold text-white/90">
              {brightnessPercent}%
            </span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Barra lateral DERECHA de Volumen (0% - 100%, solo en video) */}
      <AnimatePresence>
        {showRightVolume && !isLocked && (
          <motion.div
            initial={{ opacity: 0, x: 12 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 12 }}
            transition={{ duration: 0.18 }}
            onPointerDown={(e) => e.stopPropagation()}
            onPointerMove={(e) => e.stopPropagation()}
            onPointerUp={(e) => e.stopPropagation()}
            onClick={(e) => e.stopPropagation()}
            className="absolute right-3 sm:right-5 top-1/2 -translate-y-1/2 z-30 flex flex-col items-center gap-2.5 rounded-2xl border border-white/15 bg-black/75 px-2.5 py-3.5 backdrop-blur-md shadow-2xl"
          >
            <button
              type="button"
              onClick={toggleMute}
              aria-label={volume === 0 ? 'Activar sonido' : 'Silenciar video'}
              className="flex h-6 w-6 items-center justify-center rounded-md hover:bg-white/10 cursor-pointer"
            >
              <VolumeIcon
                className={`h-4 w-4 ${volume === 0 ? 'text-white/55' : 'text-amber-400'}`}
                aria-hidden="true"
              />
            </button>
            <div className="flex h-36 items-center justify-center">
              <input
                type="range"
                min={0}
                max={1}
                step={0.02}
                value={volume}
                onChange={(e) => applyVolume(Number(e.target.value))}
                aria-label="Volumen del video"
                className="eq-slider h-32 w-8"
              />
            </div>
            <span className="font-mono-tabular text-[11px] font-semibold text-white/90">
              {volumePercent}%
            </span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mensaje si el formato/códec no es soportado */}
      {codecError && (
        <div
          onPointerDown={(e) => e.stopPropagation()}
          className="absolute inset-x-6 max-w-lg mx-auto rounded-2xl border border-white/15 bg-neutral-900/95 p-6 text-center shadow-2xl z-40"
        >
          <p className="font-display text-base font-semibold text-white">
            Formato incompatible con el navegador
          </p>
          <p className="mt-2 text-sm text-white/75">{codecError}</p>
          <button
            type="button"
            onClick={onClose}
            className="mt-4 rounded-xl bg-amber-500 px-5 py-2.5 text-sm font-semibold text-neutral-950 cursor-pointer"
          >
            Volver a Mis videos
          </button>
        </div>
      )}

      {/* Capa de subtítulos personalizados */}
      {activeCues.length > 0 && (
        <div
          className={`pointer-events-none absolute inset-x-4 z-20 flex flex-col items-center text-center transition-all ${subPositionClass}`}
        >
          {activeCues.map((cue) => (
            <p
              key={cue.id}
              className={`max-w-3xl whitespace-pre-line font-semibold leading-snug ${subFontSizeClass} ${subBgStyle}`}
              style={{
                color: subColorStyle,
                textShadow:
                  subtitleStyle.background === 'sombra'
                    ? '0 2px 4px rgba(0,0,0,0.95), 0 0 10px rgba(0,0,0,0.85)'
                    : undefined,
              }}
            >
              {cue.text}
            </p>
          ))}
        </div>
      )}

      {/* Botón de desbloqueo si la pantalla está bloqueada */}
      {isLocked && (
        <button
          type="button"
          onPointerDown={(e) => e.stopPropagation()}
          onClick={(e) => {
            e.stopPropagation();
            setIsLocked(false);
            scheduleHideControls();
          }}
          className="absolute left-6 top-6 z-30 flex min-h-[44px] items-center gap-2 rounded-xl border border-white/20 bg-black/75 px-4 py-2 text-xs font-semibold text-white backdrop-blur-md cursor-pointer"
        >
          <Unlock className="h-4 w-4 text-amber-400" aria-hidden="true" />
          <span>Desbloquear pantalla</span>
        </button>
      )}

      {/* Barra superior */}
      <AnimatePresence>
        {showControls && !isLocked && (
          <motion.div
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.16 }}
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => e.stopPropagation()}
            className="absolute top-0 inset-x-0 z-30 flex items-center justify-between gap-3 bg-gradient-to-b from-black/85 via-black/45 to-transparent px-4 sm:px-6 pt-[max(1rem,env(safe-area-inset-top))] pb-4"
          >
            <div className="flex min-w-0 items-center gap-3">
              <button
                type="button"
                onClick={onClose}
                aria-label="Cerrar reproductor"
                className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl bg-white/10 hover:bg-white/20 transition-colors cursor-pointer"
              >
                <ArrowLeft className="h-5 w-5" aria-hidden="true" />
              </button>
              <div className="min-w-0">
                <h2 className="font-display truncate text-sm sm:text-base font-semibold text-white">
                  {video.title}
                </h2>
                <p className="text-xs text-white/65 truncate">
                  <span className="uppercase">{video.format}</span>
                  {resolutionLabel ? ` · ${resolutionLabel}` : ''}
                  {video.subtitleName ? ` · Subtítulos: ${video.subtitleName}` : ''}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setUseEqForVideo((v) => !v)}
                className="flex min-h-[40px] items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap"
                style={{
                  backgroundColor: useEqForVideo ? 'rgba(245, 158, 11, 0.22)' : 'rgba(255,255,255,0.1)',
                  color: useEqForVideo ? '#fcd34d' : '#ffffff',
                }}
                title={
                  useEqForVideo
                    ? 'Ecualizador activo en video'
                    : 'Audio directo optimizado para 2K'
                }
              >
                <SlidersHorizontal className="h-4 w-4" aria-hidden="true" />
                <span className="hidden md:inline">{useEqForVideo ? 'EQ Activo' : 'Directo 2K'}</span>
              </button>

              <button
                type="button"
                onClick={() => setShowSubPanel((v) => !v)}
                className="flex min-h-[40px] items-center gap-2 rounded-xl px-3 py-2 text-xs font-semibold transition-colors cursor-pointer"
                style={{
                  backgroundColor:
                    showSubPanel || cues.length > 0
                      ? 'rgba(245, 158, 11, 0.22)'
                      : 'rgba(255,255,255,0.1)',
                  color: showSubPanel || cues.length > 0 ? '#fcd34d' : '#ffffff',
                }}
              >
                <Captions className="h-4 w-4" aria-hidden="true" />
                <span className="hidden sm:inline">Subtítulos</span>
              </button>

              <button
                type="button"
                onClick={() => setIsLocked(true)}
                aria-label="Bloquear controles de pantalla"
                title="Bloquear pantalla"
                className="flex min-h-[40px] min-w-[40px] items-center justify-center rounded-xl bg-white/10 hover:bg-white/20 transition-colors cursor-pointer"
              >
                <Lock className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Panel de subtítulos personalizados */}
      <AnimatePresence>
        {showSubPanel && !isLocked && (
          <motion.aside
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 24 }}
            transition={{ duration: 0.18 }}
            onPointerDown={(e) => e.stopPropagation()}
            onPointerMove={(e) => e.stopPropagation()}
            onClick={(e) => e.stopPropagation()}
            className="touch-pan-y absolute right-4 top-20 bottom-28 z-40 w-80 max-w-[calc(100vw-2rem)] overflow-y-auto rounded-2xl border border-white/15 bg-neutral-900/95 p-5 shadow-2xl backdrop-blur-xl"
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <FileText className="h-4 w-4 text-amber-400" aria-hidden="true" />
                <h3 className="font-display text-sm font-semibold">Subtítulos personalizados</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowSubPanel(false)}
                aria-label="Cerrar panel de subtítulos"
                className="flex h-8 w-8 items-center justify-center rounded-lg hover:bg-white/10 cursor-pointer"
              >
                <X className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>

            <div className="mt-4 space-y-5 text-xs">
              <div>
                <input
                  ref={subInputRef}
                  type="file"
                  accept=".srt,.vtt,.ass,.ssa"
                  onChange={handleSubtitleFileChange}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => subInputRef.current?.click()}
                  className="flex w-full min-h-[42px] items-center justify-center gap-2 rounded-xl bg-amber-500 px-4 py-2.5 text-xs font-semibold text-neutral-950 cursor-pointer transition-transform active:scale-[0.98]"
                >
                  <Upload className="h-4 w-4" aria-hidden="true" />
                  <span>Cargar archivo (.SRT, .VTT, .ASS)</span>
                </button>
                {video.subtitleName && (
                  <p className="mt-2 truncate text-[11px] text-white/70">
                    Archivo activo: {video.subtitleName} ({cues.length} líneas)
                  </p>
                )}
              </div>

              <div className="flex items-center justify-between">
                <span className="font-medium text-white/90">Mostrar subtítulos</span>
                <button
                  type="button"
                  onClick={() => setSubtitlesEnabled((v) => !v)}
                  className="rounded-lg px-3 py-1.5 font-semibold transition-colors cursor-pointer"
                  style={{
                    backgroundColor: subtitlesEnabled ? '#f59e0b' : 'rgba(255,255,255,0.12)',
                    color: subtitlesEnabled ? '#0b0d12' : '#ffffff',
                  }}
                >
                  {subtitlesEnabled ? 'Activados' : 'Ocultos'}
                </button>
              </div>

              <div>
                <p className="mb-2 font-medium text-white/80">Tamaño del texto</p>
                <div className="grid grid-cols-4 gap-1 rounded-xl bg-white/5 p-1">
                  {(['pequeno', 'mediano', 'grande', 'extragrande'] as const).map((sz) => {
                    const labels = {
                      pequeno: 'Pequeño',
                      mediano: 'Medio',
                      grande: 'Grande',
                      extragrande: 'Extra',
                    };
                    return (
                      <button
                        key={sz}
                        type="button"
                        onClick={() => onUpdateSubtitleStyle({ ...subtitleStyle, fontSize: sz })}
                        className="rounded-lg py-1.5 font-medium transition-colors cursor-pointer"
                        style={{
                          backgroundColor:
                            subtitleStyle.fontSize === sz ? 'rgba(255,255,255,0.16)' : 'transparent',
                          color: subtitleStyle.fontSize === sz ? '#ffffff' : 'rgba(255,255,255,0.65)',
                        }}
                      >
                        {labels[sz]}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <p className="mb-2 font-medium text-white/80">Color</p>
                <div className="grid grid-cols-3 gap-1.5">
                  {(['blanco', 'amarillo', 'cian'] as const).map((col) => {
                    const labels = { blanco: 'Blanco', amarillo: 'Amarillo', cian: 'Cian' };
                    return (
                      <button
                        key={col}
                        type="button"
                        onClick={() => onUpdateSubtitleStyle({ ...subtitleStyle, color: col })}
                        className="rounded-xl border py-2 font-medium cursor-pointer"
                        style={{
                          borderColor:
                            subtitleStyle.color === col ? '#f59e0b' : 'rgba(255,255,255,0.12)',
                          backgroundColor:
                            subtitleStyle.color === col ? 'rgba(245, 158, 11, 0.14)' : 'transparent',
                        }}
                      >
                        {labels[col]}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <p className="mb-2 font-medium text-white/80">Estilo de fondo</p>
                <div className="grid grid-cols-3 gap-1.5">
                  {(['transparente', 'sombra', 'caja'] as const).map((bg) => {
                    const labels = {
                      transparente: 'Ninguno',
                      sombra: 'Sombra',
                      caja: 'Caja oscura',
                    };
                    return (
                      <button
                        key={bg}
                        type="button"
                        onClick={() => onUpdateSubtitleStyle({ ...subtitleStyle, background: bg })}
                        className="rounded-xl border py-2 font-medium cursor-pointer"
                        style={{
                          borderColor:
                            subtitleStyle.background === bg ? '#f59e0b' : 'rgba(255,255,255,0.12)',
                          backgroundColor:
                            subtitleStyle.background === bg ? 'rgba(245, 158, 11, 0.14)' : 'transparent',
                        }}
                      >
                        {labels[bg]}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <p className="mb-2 font-medium text-white/80">Posición en pantalla</p>
                <div className="grid grid-cols-3 gap-1.5">
                  {(['inferior', 'media', 'superior'] as const).map((pos) => {
                    const labels = { inferior: 'Abajo', media: 'Centro', superior: 'Arriba' };
                    return (
                      <button
                        key={pos}
                        type="button"
                        onClick={() => onUpdateSubtitleStyle({ ...subtitleStyle, position: pos })}
                        className="rounded-xl border py-2 font-medium cursor-pointer"
                        style={{
                          borderColor:
                            subtitleStyle.position === pos ? '#f59e0b' : 'rgba(255,255,255,0.12)',
                          backgroundColor:
                            subtitleStyle.position === pos ? 'rgba(245, 158, 11, 0.14)' : 'transparent',
                        }}
                      >
                        {labels[pos]}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <div className="mb-1.5 flex items-center justify-between">
                  <span className="font-medium text-white/80">Sincronización (desfase)</span>
                  <span className="font-mono-tabular text-amber-400">
                    {subtitleStyle.syncOffsetSec > 0 ? '+' : ''}
                    {subtitleStyle.syncOffsetSec.toFixed(1)} s
                  </span>
                </div>
                <input
                  type="range"
                  min={-5}
                  max={5}
                  step={0.1}
                  value={subtitleStyle.syncOffsetSec}
                  onChange={(e) =>
                    onUpdateSubtitleStyle({
                      ...subtitleStyle,
                      syncOffsetSec: Number(e.target.value),
                    })
                  }
                  aria-label="Ajustar sincronización de subtítulos"
                  className="visha-range w-full"
                />
                <div className="mt-2 flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateSubtitleStyle({
                        ...subtitleStyle,
                        syncOffsetSec: Number((subtitleStyle.syncOffsetSec - 0.5).toFixed(1)),
                      })
                    }
                    className="flex-1 rounded-lg bg-white/10 py-1.5 font-medium hover:bg-white/15 cursor-pointer"
                  >
                    -0.5 s
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateSubtitleStyle({ ...subtitleStyle, syncOffsetSec: 0 })
                    }
                    className="rounded-lg bg-white/10 px-3 py-1.5 font-medium hover:bg-white/15 cursor-pointer"
                  >
                    0.0 s
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateSubtitleStyle({
                        ...subtitleStyle,
                        syncOffsetSec: Number((subtitleStyle.syncOffsetSec + 0.5).toFixed(1)),
                      })
                    }
                    className="flex-1 rounded-lg bg-white/10 py-1.5 font-medium hover:bg-white/15 cursor-pointer"
                  >
                    +0.5 s
                  </button>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenAudioSettings();
                }}
                className="flex w-full min-h-[40px] items-center justify-center gap-2 rounded-xl border border-white/15 py-2 text-xs font-medium text-white/85 hover:bg-white/10 cursor-pointer"
              >
                <SlidersHorizontal className="h-4 w-4 text-amber-400" aria-hidden="true" />
                <span>Ajustes avanzados de ecualizador</span>
              </button>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* Barra inferior de controles */}
      <AnimatePresence>
        {showControls && !isLocked && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 12 }}
            transition={{ duration: 0.16 }}
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => e.stopPropagation()}
            className="absolute bottom-0 inset-x-0 z-30 bg-gradient-to-t from-black/90 via-black/60 to-transparent px-4 sm:px-6 pt-8 pb-[max(1rem,env(safe-area-inset-bottom))]"
          >
            <div className="flex items-center gap-3">
              <span className="font-mono-tabular text-xs text-white/80 w-12 text-right">
                {formatDuration(currentTime)}
              </span>
              <input
                type="range"
                min={0}
                max={Math.max(1, duration || 1)}
                step={0.1}
                value={Math.min(currentTime, Math.max(1, duration || 1))}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  if (videoRef.current) videoRef.current.currentTime = val;
                  setCurrentTime(val);
                  scheduleHideControls();
                }}
                aria-label="Línea de tiempo del video"
                className="visha-range flex-1"
              />
              <span className="font-mono-tabular text-xs text-white/80 w-12">
                {formatDuration(duration)}
              </span>
            </div>

            <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-1 sm:gap-2">
                <button
                  type="button"
                  onClick={() => skipBy(-10)}
                  aria-label="Retroceder 10 segundos"
                  className="flex min-h-[42px] min-w-[42px] items-center justify-center rounded-xl hover:bg-white/10 cursor-pointer"
                >
                  <RotateCcw className="h-5 w-5" aria-hidden="true" />
                </button>

                <button
                  type="button"
                  onClick={togglePlay}
                  aria-label={isPlaying ? 'Pausar' : 'Reproducir'}
                  className="flex h-11 w-11 items-center justify-center rounded-full bg-amber-500 text-neutral-950 cursor-pointer transition-transform active:scale-95"
                >
                  {isPlaying ? (
                    <Pause className="h-5 w-5 fill-current" aria-hidden="true" />
                  ) : (
                    <Play className="h-5 w-5 fill-current ml-0.5" aria-hidden="true" />
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => skipBy(10)}
                  aria-label="Adelantar 10 segundos"
                  className="flex min-h-[42px] min-w-[42px] items-center justify-center rounded-xl hover:bg-white/10 cursor-pointer"
                >
                  <RotateCw className="h-5 w-5" aria-hidden="true" />
                </button>

                <button
                  type="button"
                  onClick={revealLeftBrightness}
                  aria-label="Mostrar control de brillo"
                  title={`Brillo (${brightnessPercent}%)`}
                  className="flex min-h-[40px] min-w-[40px] items-center justify-center rounded-xl hover:bg-white/10 cursor-pointer ml-1"
                >
                  <Sun className="h-4 w-4 text-amber-400" aria-hidden="true" />
                </button>

                <button
                  type="button"
                  onClick={revealRightVolume}
                  aria-label="Mostrar control de volumen"
                  title={`Volumen (${volumePercent}%)`}
                  className="flex min-h-[40px] min-w-[40px] items-center justify-center rounded-xl hover:bg-white/10 cursor-pointer"
                >
                  <VolumeIcon
                    className={`h-4 w-4 ${volume === 0 ? 'text-white/55' : 'text-amber-400'}`}
                    aria-hidden="true"
                  />
                </button>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={cycleSpeed}
                  className="font-mono-tabular min-h-[40px] rounded-xl bg-white/10 px-3 py-1.5 text-xs font-medium hover:bg-white/20 cursor-pointer whitespace-nowrap"
                  title="Velocidad de reproducción"
                >
                  {playbackRate}x
                </button>

                <button
                  type="button"
                  onClick={cycleAspect}
                  className="min-h-[40px] rounded-xl bg-white/10 px-3 py-1.5 text-xs font-medium hover:bg-white/20 cursor-pointer capitalize whitespace-nowrap"
                  title="Relación de aspecto"
                >
                  {aspectMode}
                </button>

                {document.pictureInPictureEnabled && (
                  <button
                    type="button"
                    onClick={togglePiP}
                    aria-label="Ventana flotante"
                    title="Ventana flotante"
                    className="hidden sm:flex min-h-[40px] min-w-[40px] items-center justify-center rounded-xl bg-white/10 hover:bg-white/20 cursor-pointer"
                  >
                    <PictureInPicture2 className="h-4 w-4" aria-hidden="true" />
                  </button>
                )}

                <button
                  type="button"
                  onClick={toggleFullscreen}
                  aria-label={isFullscreen ? 'Salir de pantalla completa' : 'Pantalla completa'}
                  className="flex min-h-[40px] min-w-[40px] items-center justify-center rounded-xl bg-white/10 hover:bg-white/20 cursor-pointer"
                >
                  {isFullscreen ? (
                    <Minimize className="h-4 w-4" aria-hidden="true" />
                  ) : (
                    <Maximize className="h-4 w-4" aria-hidden="true" />
                  )}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
