import {
  Captions,
  ChevronDown,
  CirclePlay,
  FileText,
  Headphones,
  Loader2,
  Lock,
  MoreVertical,
  Pause,
  Play,
  RotateCcw,
  RotateCw,
  Scan,
  SlidersHorizontal,
  Smartphone,
  Sun,
  Unlock,
  Upload,
  Volume1,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { MediaItem, SubtitleStyle } from '../types/media';
import { audioEngine } from '../utils/audioEngine';
import { formatDuration, formatResolutionLabel } from '../utils/libraryDb';
import {
  isNativeAndroidMediaAvailable,
  openExternalAndroidVideo,
  openNativeAndroidVideo,
  setNativeOrientation,
} from '../utils/nativeAndroidMedia';
import { getActiveSubtitles, parseSubtitleContent, readSubtitleFile } from '../utils/subtitles';

interface VideoPlayerModalProps {
  video: MediaItem;
  videoUrl: string | null;
  subtitleStyle: SubtitleStyle;
  batterySaverEnabled: boolean;
  onUpdateSubtitleStyle: (style: SubtitleStyle) => void;
  onAttachSubtitles: (videoId: string, subtitleName: string, subtitleRaw: string) => void;
  onOpenAudioSettings: () => void;
  onClose: () => void;
}

type AspectMode = 'ajustar' | 'rellenar' | '16:9' | '4:3';

const BLANK_VIDEO_POSTER =
  'data:image/gif;base64,R0lGODlhAQABAIAAAAUEBAAAACwAAAAAAQABAAACAkQBADs=';

const NATIVE_ONLY_VIDEO_EXTS = new Set([
  'mkv',
  'avi',
  'wmv',
  'flv',
  'ts',
  'm2ts',
  'mts',
  'mpg',
  'mpeg',
]);

export function VideoPlayerModal({
  video,
  videoUrl,
  subtitleStyle,
  batterySaverEnabled,
  onUpdateSubtitleStyle,
  onAttachSubtitles,
  onOpenAudioSettings,
  onClose,
}: VideoPlayerModalProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const subInputRef = useRef<HTMLInputElement | null>(null);
  const hideTimerRef = useRef<number | null>(null);
  const leftTimerRef = useRef<number | null>(null);
  const rightTimerRef = useRef<number | null>(null);
  const speedBadgeTimerRef = useRef<number | null>(null);
  const lastNonZeroVolumeRef = useRef(1);
  const autoOpenedNativeRef = useRef(false);

  const [isPlaying, setIsPlaying] = useState(true);
  const [isBuffering, setIsBuffering] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(video.duration || 0);
  const [brightness, setBrightness] = useState(1); // 0.15 a 1.0 (máximo 100%)
  const [volume, setVolume] = useState(1); // 0 a 1.0 (máximo 100%)
  const [playbackRate, setPlaybackRate] = useState(1);
  const [aspectMode, setAspectMode] = useState<AspectMode>('ajustar');
  const [isLocked, setIsLocked] = useState(false);
  const [isLandscape, setIsLandscape] = useState(false);
  const [decodedDims, setDecodedDims] = useState<{ width: number; height: number } | null>(null);
  const [showControls, setShowControls] = useState(true);
  const [showSubPanel, setShowSubPanel] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [subtitlesEnabled, setSubtitlesEnabled] = useState(true);
  const [useEqForVideo, setUseEqForVideo] = useState(false);
  const [codecError, setCodecError] = useState<string | null>(null);
  const [speedHudText, setSpeedHudText] = useState<string | null>(null);

  // Barras laterales: IZQUIERDA Brillo (15%–100%), DERECHA Volumen (0%–100%)
  const [showLeftBrightness, setShowLeftBrightness] = useState(false);
  const [showRightVolume, setShowRightVolume] = useState(false);

  // Gesto vertical táctil/puntero
  const gestureRef = useRef<{
    side: 'left' | 'right' | null;
    startY: number;
    startVal: number;
    moved: boolean;
  }>({ side: null, startY: 0, startVal: 1, moved: false });

  const canUseNativePlayer = isNativeAndroidMediaAvailable() && Boolean(video.localPath);
  const videoExt = (video.format || video.name.split('.').pop() || '').toLowerCase();
  const prefersNativeDirectly = canUseNativePlayer && NATIVE_ONLY_VIDEO_EXTS.has(videoExt);

  // Detección interna silenciosa de resolución (144p, 260p, 360p, 480p, 720p, 1080p, 1.5K, 2K, 4K)
  const internalResolution = useMemo(
    () =>
      formatResolutionLabel(
        decodedDims?.width || video.width,
        decodedDims?.height || video.height
      ),
    [decodedDims, video.width, video.height]
  );

  const cues = useMemo(
    () => (video.subtitleRaw ? parseSubtitleContent(video.subtitleRaw) : []),
    [video.subtitleRaw]
  );

  const activeCues = useMemo(
    () =>
      subtitlesEnabled && cues.length > 0
        ? getActiveSubtitles(cues, currentTime, subtitleStyle.syncOffsetSec)
        : [],
    [cues, currentTime, subtitleStyle.syncOffsetSec, subtitlesEnabled]
  );

  const revealLeftBrightness = useCallback(() => {
    setShowLeftBrightness(true);
    if (leftTimerRef.current) window.clearTimeout(leftTimerRef.current);
    leftTimerRef.current = window.setTimeout(() => {
      setShowLeftBrightness(false);
    }, 2200);
  }, []);

  const revealRightVolume = useCallback(() => {
    setShowRightVolume(true);
    if (rightTimerRef.current) window.clearTimeout(rightTimerRef.current);
    rightTimerRef.current = window.setTimeout(() => {
      setShowRightVolume(false);
    }, 2200);
  }, []);

  const showTempHud = useCallback((label: string) => {
    setSpeedHudText(label);
    if (speedBadgeTimerRef.current) window.clearTimeout(speedBadgeTimerRef.current);
    speedBadgeTimerRef.current = window.setTimeout(() => {
      setSpeedHudText(null);
    }, 1400);
  }, []);

  const scheduleHideControls = useCallback(() => {
    if (hideTimerRef.current) window.clearTimeout(hideTimerRef.current);
    setShowControls(true);
    if (isPlaying && !showSubPanel && !showMoreMenu) {
      hideTimerRef.current = window.setTimeout(() => {
        setShowControls(false);
      }, 3000);
    }
  }, [isPlaying, showSubPanel, showMoreMenu]);

  useEffect(() => {
    scheduleHideControls();
    return () => {
      if (hideTimerRef.current) window.clearTimeout(hideTimerRef.current);
      if (leftTimerRef.current) window.clearTimeout(leftTimerRef.current);
      if (rightTimerRef.current) window.clearTimeout(rightTimerRef.current);
      if (speedBadgeTimerRef.current) window.clearTimeout(speedBadgeTimerRef.current);
    };
  }, [scheduleHideControls]);

  useEffect(() => {
    return () => {
      void setNativeOrientation('unspecified');
      audioEngine.suspendIdle();
    };
  }, []);

  // Audio directo por defecto para cero latencia/calor; EQ solo bajo demanda
  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;
    if (useEqForVideo) {
      audioEngine.connectMediaElement(el);
      audioEngine.resume();
    } else if (audioEngine.hasConnectedElement(el)) {
      audioEngine.suspendIdle();
    }
  }, [useEqForVideo, videoUrl]);

  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;
    const clampedVol = Math.max(0, Math.min(1, volume));
    el.volume = clampedVol;
    el.muted = clampedVol === 0;
  }, [volume, videoUrl]);

  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;
    el.playbackRate = playbackRate;
  }, [playbackRate, videoUrl]);

  useEffect(() => {
    autoOpenedNativeRef.current = false;
  }, [video.id]);

  useEffect(() => {
    const el = videoRef.current;
    if (!el || !videoUrl) return;

    if (prefersNativeDirectly && video.localPath && !autoOpenedNativeRef.current) {
      autoOpenedNativeRef.current = true;
      void openNativeAndroidVideo(video.localPath, video.title, 0).then((opened) => {
        if (opened) onClose();
      });
      return;
    }

    let cancelled = false;
    setIsBuffering(true);
    setCodecError(null);

    const tryStart = () => {
      if (cancelled) return;
      el.volume = Math.max(0, Math.min(1, volume));
      el.muted = volume === 0;
      el.playbackRate = playbackRate;
      el.play()
        .then(() => {
          if (!cancelled) {
            setIsPlaying(true);
            setIsBuffering(false);
          }
        })
        .catch(() => {
          if (cancelled) return;
          const retryOnCanPlay = () => {
            if (cancelled) return;
            el.play()
              .then(() => {
                if (!cancelled) {
                  setIsPlaying(true);
                  setIsBuffering(false);
                }
              })
              .catch(() => {
                if (!cancelled) {
                  setIsPlaying(false);
                  setIsBuffering(false);
                }
              });
          };
          el.addEventListener('canplay', retryOnCanPlay, { once: true });
        });
    };

    tryStart();

    return () => {
      cancelled = true;
      el.pause();
      el.removeAttribute('src');
      el.load();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [videoUrl]);

  // Ahorro térmico y de batería: suspender AudioContext si se pausa o se oculta la app
  useEffect(() => {
    if (!isPlaying && batterySaverEnabled) {
      audioEngine.suspendIdle();
    }
  }, [isPlaying, batterySaverEnabled]);

  const toggleOrientation = useCallback(() => {
    setIsLandscape((prev) => {
      const next = !prev;
      void setNativeOrientation(next ? 'landscape' : 'portrait');
      return next;
    });
  }, []);

  const handleOpenNativePlayer = useCallback(async () => {
    if (!video.localPath) return;
    const el = videoRef.current;
    const resumeAt = el && Number.isFinite(el.currentTime) ? el.currentTime : currentTime;
    if (el && !el.paused) {
      el.pause();
      setIsPlaying(false);
    }
    const opened = await openNativeAndroidVideo(video.localPath, video.title, resumeAt);
    if (opened) {
      onClose();
    }
  }, [video.localPath, video.title, currentTime, onClose]);

  const handleOpenExternalPlayer = useCallback(async () => {
    if (!video.localPath) return;
    const opened = await openExternalAndroidVideo(video.localPath, video.title);
    if (opened) {
      onClose();
    }
  }, [video.localPath, video.title, onClose]);

  const togglePlay = useCallback(() => {
    const el = videoRef.current;
    if (!el || !videoUrl) return;
    if (useEqForVideo) audioEngine.resume();
    if (el.paused) {
      el.play().then(() => setIsPlaying(true)).catch(() => {});
    } else {
      el.pause();
      setIsPlaying(false);
      if (batterySaverEnabled) audioEngine.suspendIdle();
    }
  }, [useEqForVideo, videoUrl, batterySaverEnabled]);

  const skipBy = useCallback((deltaSec: number) => {
    const el = videoRef.current;
    if (!el) return;
    el.currentTime = Math.max(0, Math.min(el.duration || 0, el.currentTime + deltaSec));
    setCurrentTime(el.currentTime);
  }, []);

  const applyBrightness = useCallback(
    (nextBrightness: number) => {
      const clamped = Math.max(0.15, Math.min(1, nextBrightness));
      setBrightness(clamped);
      revealLeftBrightness();
    },
    [revealLeftBrightness]
  );

  const applyVolume = useCallback(
    (nextVolume: number) => {
      const clamped = Math.max(0, Math.min(1, nextVolume));
      if (clamped > 0.01) {
        lastNonZeroVolumeRef.current = clamped;
      }
      setVolume(clamped);
      revealRightVolume();
    },
    [revealRightVolume]
  );

  const toggleMute = useCallback(() => {
    if (volume > 0) {
      lastNonZeroVolumeRef.current = volume;
      applyVolume(0);
    } else {
      applyVolume(lastNonZeroVolumeRef.current > 0.05 ? lastNonZeroVolumeRef.current : 0.75);
    }
  }, [volume, applyVolume]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (isLocked) return;
      if (e.key === ' ' || e.key === 'k') {
        e.preventDefault();
        togglePlay();
      } else if (e.key === 'ArrowRight') {
        skipBy(10);
      } else if (e.key === 'ArrowLeft') {
        skipBy(-10);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        applyVolume(volume + 0.05);
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        applyVolume(volume - 0.05);
      } else if (e.key === 'm' || e.key === 'M') {
        toggleMute();
      } else if (e.key === 'Escape') {
        if (showMoreMenu || showSubPanel) {
          setShowMoreMenu(false);
          setShowSubPanel(false);
        } else {
          onClose();
        }
      }
    };
    const onBack = (e: Event) => {
      e.preventDefault();
      if (isLocked) {
        return;
      }
      if (showMoreMenu || showSubPanel) {
        setShowMoreMenu(false);
        setShowSubPanel(false);
        return;
      }
      onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('huyin-back-press', onBack);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('huyin-back-press', onBack);
    };
  }, [
    isLocked,
    togglePlay,
    skipBy,
    applyVolume,
    volume,
    toggleMute,
    showMoreMenu,
    showSubPanel,
    onClose,
  ]);

  const handleSubtitleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const raw = await readSubtitleFile(file);
    onAttachSubtitles(video.id, file.name, raw);
    setSubtitlesEnabled(true);
    e.target.value = '';
  };

  const cycleSpeed = () => {
    const speeds = [0.5, 0.75, 1, 1.25, 1.5, 2];
    const idx = speeds.indexOf(playbackRate);
    const next = speeds[(idx + 1) % speeds.length];
    setPlaybackRate(next);
    if (videoRef.current) videoRef.current.playbackRate = next;
    showTempHud(`Velocidad ${next}x`);
  };

  const cycleAspect = () => {
    const modes: AspectMode[] = ['ajustar', 'rellenar', '16:9', '4:3'];
    const labels: Record<AspectMode, string> = {
      ajustar: 'Ajuste original',
      rellenar: 'Ajustar al marco',
      '16:9': 'Relación 16:9',
      '4:3': 'Relación 4:3',
    };
    const next = modes[(modes.indexOf(aspectMode) + 1) % modes.length];
    setAspectMode(next);
    showTempHud(labels[next]);
  };

  // Gestos táctiles del reproductor
  const handleSurfacePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isLocked) return;
    if (e.pointerType === 'mouse' && e.button !== 0) return;

    if (showMoreMenu) {
      setShowMoreMenu(false);
    }

    const rect = e.currentTarget.getBoundingClientRect();
    const isLeft = e.clientX - rect.left < rect.width / 2;
    const side: 'left' | 'right' = isLeft ? 'left' : 'right';

    gestureRef.current = {
      side,
      startY: e.clientY,
      startVal: side === 'left' ? brightness : volume,
      moved: false,
    };
  };

  const handleSurfacePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isLocked) return;
    const g = gestureRef.current;
    if (!g.side) return;

    const deltaY = g.startY - e.clientY;
    if (Math.abs(deltaY) > 10) {
      g.moved = true;
      const sensitivity = Math.max(180, window.innerHeight * 0.42);
      if (g.side === 'left') {
        applyBrightness(g.startVal + (deltaY / sensitivity) * 0.85);
      } else {
        applyVolume(g.startVal + (deltaY / sensitivity) * 1.0);
      }
    }
  };

  const handleSurfacePointerUp = () => {
    const g = gestureRef.current;
    const wasTap = !g.moved;
    gestureRef.current = { side: null, startY: 0, startVal: 1, moved: false };
    if (wasTap && !isLocked) {
      if (showSubPanel) {
        setShowSubPanel(false);
        return;
      }
      if (showControls) {
        setShowControls(false);
      } else {
        scheduleHideControls();
      }
    }
  };

  const videoObjectClass =
    aspectMode === 'rellenar'
      ? 'w-full h-full object-cover'
      : aspectMode === '16:9'
        ? 'w-full aspect-video object-contain max-h-full'
        : aspectMode === '4:3'
          ? 'h-full aspect-[4/3] object-contain max-w-full'
          : 'w-full h-full object-contain';

  const subFontSizeClass =
    subtitleStyle.fontSize === 'pequeno'
      ? 'text-sm sm:text-base'
      : subtitleStyle.fontSize === 'grande'
        ? 'text-xl sm:text-2xl'
        : subtitleStyle.fontSize === 'extragrande'
          ? 'text-2xl sm:text-3xl'
          : 'text-base sm:text-xl';

  const subColorStyle =
    subtitleStyle.color === 'amarillo'
      ? '#fde047'
      : subtitleStyle.color === 'cian'
        ? '#67e8f9'
        : '#ffffff';

  const subBgStyle =
    subtitleStyle.background === 'caja'
      ? 'bg-black/80 px-3.5 py-1.5 rounded-lg'
      : subtitleStyle.background === 'sombra'
        ? 'px-2 py-1 drop-shadow-[0_2px_6px_rgba(0,0,0,0.95)]'
        : 'px-2 py-1';

  const subPositionClass =
    subtitleStyle.position === 'superior'
      ? 'top-16'
      : subtitleStyle.position === 'media'
        ? 'top-1/2 -translate-y-1/2'
        : 'bottom-24';

  const brightnessPercent = Math.min(100, Math.round(brightness * 100));
  const brightnessFillPercent = Math.max(0, Math.min(100, ((brightness - 0.15) / 0.85) * 100));
  const volumePercent = Math.min(100, Math.round(volume * 100));
  const VolumeIcon = volume === 0 ? VolumeX : volume < 0.5 ? Volume1 : Volume2;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.18 }}
      onPointerDown={handleSurfacePointerDown}
      onPointerMove={handleSurfacePointerMove}
      onPointerUp={handleSurfacePointerUp}
      onPointerCancel={() => {
        gestureRef.current.side = null;
      }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black text-white select-none touch-none"
      role="dialog"
      aria-modal="true"
      aria-label={`Reproductor de video: ${video.title}`}
    >
      {/* Elemento de video con póster transparente (evita ícono gris de fallo en Android WebView) */}
      {videoUrl && !prefersNativeDirectly && (
        <video
          ref={videoRef}
          src={videoUrl}
          poster={BLANK_VIDEO_POSTER}
          playsInline
          preload={batterySaverEnabled ? 'metadata' : 'auto'}
          onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
          onLoadedMetadata={(e) => {
            const el = e.currentTarget;
            el.volume = Math.max(0, Math.min(1, volume));
            el.muted = volume === 0;
            el.playbackRate = playbackRate;
            setDuration(el.duration || video.duration || 0);
            if (el.videoWidth && el.videoHeight) {
              setDecodedDims({ width: el.videoWidth, height: el.videoHeight });
            }
            setCodecError(null);
          }}
          onResize={(e) => {
            const el = e.currentTarget;
            if (el.videoWidth && el.videoHeight) {
              setDecodedDims({ width: el.videoWidth, height: el.videoHeight });
            }
          }}
          onLoadedData={() => setIsBuffering(false)}
          onCanPlay={() => setIsBuffering(false)}
          onWaiting={() => setIsBuffering(true)}
          onPlaying={() => {
            setIsBuffering(false);
            setIsPlaying(true);
          }}
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
          onEnded={() => setIsPlaying(false)}
          onError={() => {
            setIsBuffering(false);
            if (canUseNativePlayer && video.localPath && !autoOpenedNativeRef.current) {
              autoOpenedNativeRef.current = true;
              void openNativeAndroidVideo(video.localPath, video.title, currentTime).then((opened) => {
                if (opened) {
                  onClose();
                } else {
                  setCodecError(
                    'Este video requiere un reproductor externo o el visor nativo del sistema.'
                  );
                }
              });
              return;
            }
            setCodecError(
              'Este archivo no es compatible con el visor web integrado. Puedes abrirlo con el reproductor del sistema.'
            );
          }}
          className={codecError ? 'hidden' : videoObjectClass}
        />
      )}

      {/* Indicador breve mientras carga */}
      {(!videoUrl || isBuffering) && !codecError && (
        <div className="pointer-events-none absolute inset-0 z-10 flex flex-col items-center justify-center gap-2 bg-black/50">
          <Loader2 className="h-7 w-7 animate-spin text-white" aria-hidden="true" />
          <span className="text-xs font-medium text-white/80">Cargando video...</span>
        </div>
      )}

      {/* Capa ligera de atenuación de brillo (sin blur, 15% a 100%) */}
      {brightness < 0.99 && (
        <div
          className="pointer-events-none absolute inset-0 bg-black"
          style={{ opacity: Math.min(0.85, 1 - brightness) }}
        />
      )}
          {/* Barra lateral IZQUIERDA de Brillo (15% - 100%, píldora oscura limpia sin blur) */}
          <AnimatePresence>
            {showLeftBrightness && !isLocked && (
              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.14 }}
                onPointerDown={(e) => e.stopPropagation()}
                onPointerMove={(e) => e.stopPropagation()}
                onPointerUp={(e) => e.stopPropagation()}
                onClick={(e) => e.stopPropagation()}
                className="absolute left-3 sm:left-5 top-1/2 -translate-y-1/2 z-30 flex flex-col items-center gap-2.5 rounded-full bg-black/75 border border-white/10 px-2.5 py-4"
              >
                <div className="relative flex h-36 w-5 items-center justify-center">
                  <div className="relative h-full w-2 overflow-hidden rounded-full bg-white/25">
                    <div
                      className="absolute bottom-0 inset-x-0 rounded-full bg-white"
                      style={{ height: `${brightnessFillPercent}%` }}
                    />
                  </div>
                  <input
                    type="range"
                    min={0.15}
                    max={1}
                    step={0.02}
                    value={brightness}
                    onChange={(e) => applyBrightness(Number(e.target.value))}
                    aria-label="Brillo de video"
                    className="eq-slider absolute inset-0 h-36 w-8 opacity-0 cursor-pointer"
                  />
                </div>
                <Sun className="h-5 w-5 text-white" aria-hidden="true" />
                <span className="font-mono-tabular text-[11px] font-medium text-white/90">
                  {brightnessPercent}%
                </span>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Barra lateral DERECHA de Volumen (0% - 100%, píldora oscura limpia sin blur) */}
          <AnimatePresence>
            {showRightVolume && !isLocked && (
              <motion.div
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.14 }}
                onPointerDown={(e) => e.stopPropagation()}
                onPointerMove={(e) => e.stopPropagation()}
                onPointerUp={(e) => e.stopPropagation()}
                onClick={(e) => e.stopPropagation()}
                className="absolute right-3 sm:right-5 top-1/2 -translate-y-1/2 z-30 flex flex-col items-center gap-2.5 rounded-full bg-black/75 border border-white/10 px-2.5 py-4"
              >
                <div className="relative flex h-36 w-5 items-center justify-center">
                  <div className="relative h-full w-2 overflow-hidden rounded-full bg-white/25">
                    <div
                      className="absolute bottom-0 inset-x-0 rounded-full bg-white"
                      style={{ height: `${volumePercent}%` }}
                    />
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.02}
                    value={volume}
                    onChange={(e) => applyVolume(Number(e.target.value))}
                    aria-label="Volumen del video"
                    className="eq-slider absolute inset-0 h-36 w-8 opacity-0 cursor-pointer"
                  />
                </div>
                <button
                  type="button"
                  onClick={toggleMute}
                  aria-label={volume === 0 ? 'Activar sonido' : 'Silenciar video'}
                  className="flex h-6 w-6 items-center justify-center text-white cursor-pointer"
                >
                  <VolumeIcon className="h-5 w-5" aria-hidden="true" />
                </button>
                <span className="font-mono-tabular text-[11px] font-medium text-white/90">
                  {volumePercent}%
                </span>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Aviso breve de velocidad o aspecto */}
          {speedHudText && (
            <div className="pointer-events-none absolute top-16 left-1/2 -translate-x-1/2 z-30 rounded-full bg-black/80 border border-white/15 px-3.5 py-1 text-xs font-medium text-white">
              {speedHudText}
            </div>
          )}

          {/* Mensaje si el formato/códec requiere visor externo */}
          {codecError && (
            <div
              onPointerDown={(e) => e.stopPropagation()}
              className="absolute inset-x-6 max-w-md mx-auto rounded-2xl border border-white/15 bg-neutral-900 p-6 text-center shadow-2xl z-40"
            >
              <p className="font-display text-base font-semibold text-white">
                Abrir con reproductor del sistema
              </p>
              <p className="mt-2 text-sm text-white/75">{codecError}</p>
              <div className="mt-4 flex flex-wrap items-center justify-center gap-2.5">
                {canUseNativePlayer && (
                  <button
                    type="button"
                    onClick={() => void handleOpenExternalPlayer()}
                    className="rounded-xl bg-amber-500 px-5 py-2.5 text-sm font-semibold text-neutral-950 cursor-pointer"
                  >
                    Abrir con otra app del teléfono
                  </button>
                )}
                <button
                  type="button"
                  onClick={onClose}
                  className="rounded-xl border border-white/20 bg-white/10 px-5 py-2.5 text-sm font-semibold text-white cursor-pointer"
                >
                  Volver a Mis videos
                </button>
              </div>
            </div>
          )}

          {/* Capa de subtítulos */}
          {activeCues.length > 0 && (
            <div
              className={`pointer-events-none absolute inset-x-4 z-20 flex flex-col items-center text-center ${subPositionClass}`}
            >
              {activeCues.map((cue) => (
                <p
                  key={cue.id}
                  className={`max-w-3xl whitespace-pre-line font-semibold leading-snug ${subFontSizeClass} ${subBgStyle}`}
                  style={{
                    color: subColorStyle,
                    textShadow:
                      subtitleStyle.background === 'sombra'
                        ? '0 2px 4px rgba(0,0,0,0.95), 0 0 10px rgba(0,0,0,0.85)'
                        : undefined,
                  }}
                >
                  {cue.text}
                </p>
              ))}
            </div>
          )}

          {/* Botón desbloquear si la pantalla está bloqueada */}
          {isLocked && (
            <button
              type="button"
              onPointerDown={(e) => e.stopPropagation()}
              onClick={(e) => {
                e.stopPropagation();
                setIsLocked(false);
                scheduleHideControls();
              }}
              className="absolute left-5 top-[max(1rem,env(safe-area-inset-top))] z-30 flex min-h-[42px] items-center gap-2 rounded-full border border-white/20 bg-black/80 px-4 py-2 text-xs font-semibold text-white cursor-pointer"
            >
              <Unlock className="h-4 w-4 text-amber-400" aria-hidden="true" />
              <span>Desbloquear</span>
            </button>
          )}

          {/* Barra superior limpia (∨ + título + subtítulos + ⋮) */}
          <AnimatePresence>
            {showControls && !isLocked && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.14 }}
                onPointerDown={(e) => e.stopPropagation()}
                onClick={(e) => e.stopPropagation()}
                className="absolute top-0 inset-x-0 z-30 flex items-center justify-between gap-2 bg-gradient-to-b from-black/80 via-black/40 to-transparent px-3 sm:px-5 pt-[max(0.75rem,env(safe-area-inset-top))] pb-4"
              >
                <div className="flex min-w-0 flex-1 items-center gap-2">
                  <button
                    type="button"
                    onClick={onClose}
                    aria-label="Cerrar video"
                    className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-white hover:bg-white/10 transition-colors cursor-pointer"
                  >
                    <ChevronDown className="h-6 w-6" aria-hidden="true" />
                  </button>
                  <h2 className="truncate text-sm sm:text-base font-medium text-white">
                    {video.title}
                  </h2>
                </div>

                <div className="relative flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      setShowSubPanel((v) => !v);
                      setShowMoreMenu(false);
                    }}
                    aria-label="Subtítulos"
                    className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/10 transition-colors cursor-pointer"
                    style={{ color: showSubPanel || cues.length > 0 ? '#f59e0b' : '#ffffff' }}
                  >
                    <Captions className="h-5 w-5" aria-hidden="true" />
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setShowMoreMenu((v) => !v);
                      setShowSubPanel(false);
                    }}
                    aria-label="Más opciones"
                    className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/10 transition-colors cursor-pointer"
                  >
                    <MoreVertical className="h-5 w-5" aria-hidden="true" />
                  </button>

                  {showMoreMenu && (
                    <div className="absolute right-0 top-12 z-40 w-60 rounded-2xl border border-white/15 bg-neutral-900 p-1.5 shadow-2xl">
                      <button
                        type="button"
                        onClick={() => {
                          setShowMoreMenu(false);
                          setShowSubPanel(true);
                        }}
                        className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-left text-xs font-medium text-white hover:bg-white/10 cursor-pointer"
                      >
                        <Captions className="h-4 w-4 text-white/80" aria-hidden="true" />
                        <span>Subtítulos y sincronización</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setUseEqForVideo((v) => !v);
                          setShowMoreMenu(false);
                        }}
                        className="flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left text-xs font-medium text-white hover:bg-white/10 cursor-pointer"
                      >
                        <span className="flex items-center gap-2.5">
                          <Headphones className="h-4 w-4 text-white/80" aria-hidden="true" />
                          <span>Ecualizador en video</span>
                        </span>
                        <span className="text-[11px] font-semibold text-amber-400">
                          {useEqForVideo ? 'Activo' : 'Directo'}
                        </span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setShowMoreMenu(false);
                          onClose();
                          onOpenAudioSettings();
                        }}
                        className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-left text-xs font-medium text-white hover:bg-white/10 cursor-pointer"
                      >
                        <SlidersHorizontal className="h-4 w-4 text-white/80" aria-hidden="true" />
                        <span>Ajustes de audio</span>
                      </button>

                      {canUseNativePlayer && (
                        <button
                          type="button"
                          onClick={() => {
                            setShowMoreMenu(false);
                            void handleOpenNativePlayer();
                          }}
                          className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-left text-xs font-medium text-white hover:bg-white/10 cursor-pointer"
                        >
                          <Play className="h-4 w-4 text-white/80" aria-hidden="true" />
                          <span>Visor nativo de hardware</span>
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Controles centrales limpios (↺10, || / ▶, ↻10 en blanco limpio) */}
          <AnimatePresence>
            {showControls && !isLocked && !codecError && !showSubPanel && (
              <motion.div
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.96 }}
                transition={{ duration: 0.14 }}
                onPointerDown={(e) => e.stopPropagation()}
                onClick={(e) => e.stopPropagation()}
                className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center gap-10 sm:gap-16"
              >
                <button
                  type="button"
                  onClick={() => {
                    skipBy(-10);
                    scheduleHideControls();
                  }}
                  aria-label="Retroceder 10 segundos"
                  className="pointer-events-auto relative flex h-12 w-12 items-center justify-center rounded-full text-white hover:bg-white/10 active:scale-95 transition-transform cursor-pointer"
                >
                  <RotateCcw className="h-8 w-8 stroke-[1.75]" aria-hidden="true" />
                  <span className="absolute mt-1 text-[10px] font-bold leading-none">10</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    togglePlay();
                    scheduleHideControls();
                  }}
                  aria-label={isPlaying ? 'Pausar' : 'Reproducir'}
                  className="pointer-events-auto flex h-16 w-16 items-center justify-center rounded-full text-white hover:bg-white/10 active:scale-95 transition-transform cursor-pointer"
                >
                  {isPlaying ? (
                    <Pause className="h-11 w-11 fill-white" aria-hidden="true" />
                  ) : (
                    <Play className="h-11 w-11 fill-white ml-1" aria-hidden="true" />
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    skipBy(10);
                    scheduleHideControls();
                  }}
                  aria-label="Adelantar 10 segundos"
                  className="pointer-events-auto relative flex h-12 w-12 items-center justify-center rounded-full text-white hover:bg-white/10 active:scale-95 transition-transform cursor-pointer"
                >
                  <RotateCw className="h-8 w-8 stroke-[1.75]" aria-hidden="true" />
                  <span className="absolute mt-1 text-[10px] font-bold leading-none">10</span>
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Panel lateral de subtítulos (sin blur pesado para ahorro térmico) */}
          <AnimatePresence>
            {showSubPanel && !isLocked && (
              <motion.aside
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ duration: 0.16 }}
                onPointerDown={(e) => e.stopPropagation()}
                onPointerMove={(e) => e.stopPropagation()}
                onClick={(e) => e.stopPropagation()}
                className="touch-pan-y absolute right-3 top-16 bottom-24 z-40 w-80 max-w-[calc(100vw-1.5rem)] overflow-y-auto rounded-2xl border border-white/15 bg-neutral-900 p-5 shadow-2xl"
              >
                <div className="flex items-center justify-between pb-3 border-b border-white/10">
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4 text-amber-400" aria-hidden="true" />
                    <h3 className="font-display text-sm font-semibold">Subtítulos</h3>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowSubPanel(false)}
                    aria-label="Cerrar panel de subtítulos"
                    className="flex h-8 w-8 items-center justify-center rounded-lg hover:bg-white/10 cursor-pointer"
                  >
                    <X className="h-4 w-4" aria-hidden="true" />
                  </button>
                </div>

                <div className="mt-4 space-y-5 text-xs">
                  <div>
                    <input
                      ref={subInputRef}
                      type="file"
                      accept=".srt,.vtt,.ass,.ssa"
                      onChange={handleSubtitleFileChange}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => subInputRef.current?.click()}
                      className="flex w-full min-h-[42px] items-center justify-center gap-2 rounded-xl bg-amber-500 px-4 py-2.5 text-xs font-semibold text-neutral-950 cursor-pointer"
                    >
                      <Upload className="h-4 w-4" aria-hidden="true" />
                      <span>Cargar archivo (.SRT, .VTT, .ASS)</span>
                    </button>
                    {video.subtitleName && (
                      <p className="mt-2 truncate text-[11px] text-white/70">
                        Activo: {video.subtitleName} ({cues.length} líneas)
                      </p>
                    )}
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="font-medium text-white/90">Mostrar subtítulos</span>
                    <button
                      type="button"
                      onClick={() => setSubtitlesEnabled((v) => !v)}
                      className="rounded-lg px-3 py-1.5 font-semibold cursor-pointer"
                      style={{
                        backgroundColor: subtitlesEnabled ? '#f59e0b' : 'rgba(255,255,255,0.12)',
                        color: subtitlesEnabled ? '#0b0d12' : '#ffffff',
                      }}
                    >
                      {subtitlesEnabled ? 'Activados' : 'Ocultos'}
                    </button>
                  </div>

                  <div>
                    <p className="mb-2 font-medium text-white/80">Tamaño del texto</p>
                    <div className="grid grid-cols-4 gap-1 rounded-xl bg-white/5 p-1">
                      {(['pequeno', 'mediano', 'grande', 'extragrande'] as const).map((sz) => {
                        const labels = {
                          pequeno: 'Pequeño',
                          mediano: 'Medio',
                          grande: 'Grande',
                          extragrande: 'Extra',
                        };
                        return (
                          <button
                            key={sz}
                            type="button"
                            onClick={() => onUpdateSubtitleStyle({ ...subtitleStyle, fontSize: sz })}
                            className="rounded-lg py-1.5 font-medium cursor-pointer"
                            style={{
                              backgroundColor:
                                subtitleStyle.fontSize === sz
                                  ? 'rgba(255,255,255,0.16)'
                                  : 'transparent',
                              color:
                                subtitleStyle.fontSize === sz ? '#ffffff' : 'rgba(255,255,255,0.65)',
                            }}
                          >
                            {labels[sz]}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <p className="mb-2 font-medium text-white/80">Color</p>
                    <div className="grid grid-cols-3 gap-1.5">
                      {(['blanco', 'amarillo', 'cian'] as const).map((col) => {
                        const labels = { blanco: 'Blanco', amarillo: 'Amarillo', cian: 'Cian' };
                        return (
                          <button
                            key={col}
                            type="button"
                            onClick={() => onUpdateSubtitleStyle({ ...subtitleStyle, color: col })}
                            className="rounded-xl border py-2 font-medium cursor-pointer"
                            style={{
                              borderColor:
                                subtitleStyle.color === col ? '#f59e0b' : 'rgba(255,255,255,0.12)',
                              backgroundColor:
                                subtitleStyle.color === col
                                  ? 'rgba(245, 158, 11, 0.14)'
                                  : 'transparent',
                            }}
                          >
                            {labels[col]}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <p className="mb-2 font-medium text-white/80">Fondo</p>
                    <div className="grid grid-cols-3 gap-1.5">
                      {(['transparente', 'sombra', 'caja'] as const).map((bg) => {
                        const labels = {
                          transparente: 'Ninguno',
                          sombra: 'Sombra',
                          caja: 'Caja oscura',
                        };
                        return (
                          <button
                            key={bg}
                            type="button"
                            onClick={() =>
                              onUpdateSubtitleStyle({ ...subtitleStyle, background: bg })
                            }
                            className="rounded-xl border py-2 font-medium cursor-pointer"
                            style={{
                              borderColor:
                                subtitleStyle.background === bg
                                  ? '#f59e0b'
                                  : 'rgba(255,255,255,0.12)',
                              backgroundColor:
                                subtitleStyle.background === bg
                                  ? 'rgba(245, 158, 11, 0.14)'
                                  : 'transparent',
                            }}
                          >
                            {labels[bg]}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <p className="mb-2 font-medium text-white/80">Posición</p>
                    <div className="grid grid-cols-3 gap-1.5">
                      {(['inferior', 'media', 'superior'] as const).map((pos) => {
                        const labels = { inferior: 'Abajo', media: 'Centro', superior: 'Arriba' };
                        return (
                          <button
                            key={pos}
                            type="button"
                            onClick={() =>
                              onUpdateSubtitleStyle({ ...subtitleStyle, position: pos })
                            }
                            className="rounded-xl border py-2 font-medium cursor-pointer"
                            style={{
                              borderColor:
                                subtitleStyle.position === pos
                                  ? '#f59e0b'
                                  : 'rgba(255,255,255,0.12)',
                              backgroundColor:
                                subtitleStyle.position === pos
                                  ? 'rgba(245, 158, 11, 0.14)'
                                  : 'transparent',
                            }}
                          >
                            {labels[pos]}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <div className="mb-1.5 flex items-center justify-between">
                      <span className="font-medium text-white/80">Sincronización</span>
                      <span className="font-mono-tabular text-amber-400">
                        {subtitleStyle.syncOffsetSec > 0 ? '+' : ''}
                        {subtitleStyle.syncOffsetSec.toFixed(1)} s
                      </span>
                    </div>
                    <input
                      type="range"
                      min={-5}
                      max={5}
                      step={0.1}
                      value={subtitleStyle.syncOffsetSec}
                      onChange={(e) =>
                        onUpdateSubtitleStyle({
                          ...subtitleStyle,
                          syncOffsetSec: Number(e.target.value),
                        })
                      }
                      aria-label="Sincronización de subtítulos"
                      className="visha-range w-full"
                    />
                  </div>
                </div>
              </motion.aside>
            )}
          </AnimatePresence>

          {/* Barra inferior limpia (línea blanca + MM:SS + fila única de iconos blancos) */}
          <AnimatePresence>
            {showControls && !isLocked && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                transition={{ duration: 0.14 }}
                onPointerDown={(e) => e.stopPropagation()}
                onClick={(e) => e.stopPropagation()}
                className="absolute bottom-0 inset-x-0 z-30 bg-gradient-to-t from-black/90 via-black/60 to-transparent px-4 sm:px-6 pt-8 pb-[max(1rem,env(safe-area-inset-bottom))]"
              >
                {/* Progreso blanco limpio */}
                <div>
                  <input
                    type="range"
                    min={0}
                    max={Math.max(1, duration || 1)}
                    step={0.1}
                    value={Math.min(currentTime, Math.max(1, duration || 1))}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      if (videoRef.current) videoRef.current.currentTime = val;
                      setCurrentTime(val);
                      scheduleHideControls();
                    }}
                    aria-label="Línea de tiempo del video"
                    style={{ accentColor: '#ffffff' }}
                    className="w-full h-1.5 rounded-full cursor-pointer"
                  />
                  <div className="font-mono-tabular mt-1.5 flex items-center justify-between text-xs text-white/85">
                    <span>{formatDuration(currentTime)}</span>
                    <span>{formatDuration(duration)}</span>
                  </div>
                </div>

                {/* Fila inferior única de íconos limpios (sin pantalla completa) */}
                <div className="mt-3 flex items-center justify-between sm:justify-start sm:gap-6">
                  <button
                    type="button"
                    onClick={() => setIsLocked(true)}
                    aria-label="Bloquear pantalla"
                    title="Bloquear controles"
                    className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/10 cursor-pointer"
                  >
                    <Lock className="h-5 w-5 stroke-[1.75]" aria-hidden="true" />
                  </button>

                  <button
                    type="button"
                    onClick={revealRightVolume}
                    aria-label="Volumen"
                    title={`Volumen (${volumePercent}%)`}
                    className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/10 cursor-pointer"
                  >
                    <VolumeIcon className="h-5 w-5 stroke-[1.75]" aria-hidden="true" />
                  </button>

                  <button
                    type="button"
                    onClick={cycleAspect}
                    aria-label="Ajustar proporción de video"
                    title={`Proporción: ${aspectMode}`}
                    className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/10 cursor-pointer"
                  >
                    <Scan className="h-5 w-5 stroke-[1.75]" aria-hidden="true" />
                  </button>

                  <button
                    type="button"
                    onClick={cycleSpeed}
                    aria-label="Velocidad de reproducción"
                    title={`Velocidad: ${playbackRate}x`}
                    className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/10 cursor-pointer"
                  >
                    <CirclePlay
                      className={`h-5 w-5 stroke-[1.75] ${playbackRate !== 1 ? 'text-amber-400' : ''}`}
                      aria-hidden="true"
                    />
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setUseEqForVideo((v) => !v);
                      showTempHud(useEqForVideo ? 'Audio directo' : 'Ecualizador activo');
                    }}
                    aria-label="Ecualizador de auriculares"
                    title={useEqForVideo ? 'Ecualizador activo' : 'Audio directo'}
                    className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/10 cursor-pointer"
                  >
                    <Headphones
                      className={`h-5 w-5 stroke-[1.75] ${useEqForVideo ? 'text-amber-400' : ''}`}
                      aria-hidden="true"
                    />
                  </button>

                  <button
                    type="button"
                    onClick={toggleOrientation}
                    aria-label="Girar video horizontal o vertical"
                    title={isLandscape ? 'Cambiar a vertical' : 'Girar a horizontal'}
                    className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/10 cursor-pointer"
                  >
                    <Smartphone
                      className={`h-5 w-5 stroke-[1.75] transition-transform ${
                        isLandscape ? 'rotate-90 text-amber-400' : ''
                      }`}
                      aria-hidden="true"
                    />
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
    </motion.div>
  );
}
