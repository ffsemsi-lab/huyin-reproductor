export interface NativeDirectoryItem {
  name: string;
  path: string;
  mediaCount: number;
}

export interface NativeMediaFile {
  name: string;
  path: string;
  size: number;
  lastModified: number;
  kind: 'audio' | 'video';
}

export interface NativeDirListing {
  currentPath: string;
  parentPath: string | null;
  rootPath: string;
  directories: NativeDirectoryItem[];
  mediaCountHere: number;
  shortcuts: Array<{ name: string; path: string }>;
}

interface LocalMediaPluginBridge {
  ensurePermissions(): Promise<{ granted: boolean }>;
  listDirectory(options?: { path?: string }): Promise<NativeDirListing>;
  scanDirectory(options: { path: string; maxFiles?: number }): Promise<{
    files: NativeMediaFile[];
  }>;
}

interface CapacitorWindow {
  Capacitor?: {
    isNativePlatform?: () => boolean;
    getPlatform?: () => string;
    convertFileSrc?: (filePath: string) => string;
    Plugins?: {
      LocalMedia?: LocalMediaPluginBridge;
    };
  };
}

function getCap(): CapacitorWindow['Capacitor'] | undefined {
  if (typeof window === 'undefined') return undefined;
  return (window as unknown as CapacitorWindow).Capacitor;
}

export function isCapacitorNative(): boolean {
  const cap = getCap();
  if (!cap) return false;
  if (typeof cap.isNativePlatform === 'function') {
    return Boolean(cap.isNativePlatform());
  }
  return Boolean(cap.Plugins?.LocalMedia);
}

export function isNativeAndroidMediaAvailable(): boolean {
  const cap = getCap();
  return Boolean(cap?.Plugins?.LocalMedia);
}

export function convertNativeFileSrc(filePath: string): string {
  const cap = getCap();
  if (cap && typeof cap.convertFileSrc === 'function') {
    return cap.convertFileSrc(filePath);
  }
  return filePath;
}

export async function ensureNativeMediaPermissions(): Promise<boolean> {
  const plugin = getCap()?.Plugins?.LocalMedia;
  if (!plugin) return false;
  try {
    const res = await plugin.ensurePermissions();
    return Boolean(res?.granted);
  } catch {
    return false;
  }
}

export async function listNativeDirectory(path?: string): Promise<NativeDirListing> {
  const plugin = getCap()?.Plugins?.LocalMedia;
  if (!plugin) {
    throw new Error('LocalMedia plugin not available');
  }
  return await plugin.listDirectory(path ? { path } : {});
}

export async function scanNativeDirectory(
  path: string,
  maxFiles = 500
): Promise<NativeMediaFile[]> {
  const plugin = getCap()?.Plugins?.LocalMedia;
  if (!plugin) return [];
  const res = await plugin.scanDirectory({ path, maxFiles });
  return Array.isArray(res?.files) ? res.files : [];
}
