package com.huyin.reproductor;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import androidx.activity.OnBackPressedCallback;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    private boolean insetsConfigured = false;

    private void applySafeWindowBounds() {
        WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
        getWindow().clearFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION
        );
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

        int barColor = Color.parseColor("#0B0D12");
        getWindow().setStatusBarColor(barColor);
        getWindow().setNavigationBarColor(barColor);
        getWindow().getDecorView().setBackgroundColor(barColor);

        WindowInsetsControllerCompat controller =
            WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (controller != null) {
            controller.setAppearanceLightStatusBars(false);
            controller.setAppearanceLightNavigationBars(false);
            controller.show(WindowInsetsCompat.Type.systemBars());
        }

        View content = findViewById(android.R.id.content);
        if (content != null) {
            content.setBackgroundColor(barColor);
            if (!insetsConfigured) {
                insetsConfigured = true;
                ViewCompat.setOnApplyWindowInsetsListener(content, (v, windowInsets) -> {
                    Insets bars = windowInsets.getInsets(
                        WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout()
                    );
                    if (v.getPaddingLeft() != bars.left
                        || v.getPaddingTop() != bars.top
                        || v.getPaddingRight() != bars.right
                        || v.getPaddingBottom() != bars.bottom) {
                        v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                    }
                    return WindowInsetsCompat.CONSUMED;
                });
            }
            ViewCompat.requestApplyInsets(content);
        }
    }

    private void handleSmartBack() {
        WebView webView = getBridge() != null ? getBridge().getWebView() : null;
        if (webView == null) {
            finish();
            return;
        }
        webView.evaluateJavascript(
            "(function(){try{return window.__huyinHandleBackPress?window.__huyinHandleBackPress():'exit';}catch(e){return 'exit';}})()",
            value -> {
                String action = value != null ? value.replace("\"", "").trim() : "exit";
                if ("handled".equals(action)) {
                    return;
                }
                if ("background".equals(action)) {
                    moveTaskToBack(true);
                    return;
                }
                finish();
            }
        );
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(LocalMediaPlugin.class);
        super.onCreate(savedInstanceState);
        if (getBridge() != null && getBridge().getWebView() != null) {
            WebView wv = getBridge().getWebView();
            wv.setLayerType(View.LAYER_TYPE_NONE, null);
            wv.getSettings().setMediaPlaybackRequiresUserGesture(false);
            wv.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        applySafeWindowBounds();

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                handleSmartBack();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        applySafeWindowBounds();
    }
}
