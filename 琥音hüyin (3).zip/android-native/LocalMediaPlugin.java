package com.huyin.reproductor;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import androidx.core.content.ContextCompat;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.lang.ref.WeakReference;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@CapacitorPlugin(
    name = "LocalMedia",
    permissions = {
        @Permission(
            strings = { Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO },
            alias = "media"
        ),
        @Permission(
            strings = { Manifest.permission.READ_EXTERNAL_STORAGE },
            alias = "storage"
        ),
        @Permission(
            strings = { "android.permission.POST_NOTIFICATIONS" },
            alias = "notifications"
        )
    }
)
public class LocalMediaPlugin extends Plugin {
    private static WeakReference<LocalMediaPlugin> activeInstance = new WeakReference<>(null);

    @Override
    public void load() {
        super.load();
        activeInstance = new WeakReference<>(this);
    }

    public static void dispatchMediaAction(String action, Double positionSec) {
        LocalMediaPlugin plugin = activeInstance != null ? activeInstance.get() : null;
        if (plugin == null) return;
        JSObject data = new JSObject();
        data.put("action", action);
        if (positionSec != null) {
            data.put("positionSec", positionSec);
        }
        if (plugin.getActivity() != null) {
            plugin.getActivity().runOnUiThread(() -> plugin.notifyListeners("mediaControlAction", data));
        } else {
            plugin.notifyListeners("mediaControlAction", data);
        }
    }
    private static final Set<String> AUDIO_EXTS = new HashSet<>(Arrays.asList(
        "mp3", "wav", "ogg", "oga", "flac", "aac", "m4a", "opus", "weba", "wma", "aiff", "alac"
    ));
    private static final Set<String> VIDEO_EXTS = new HashSet<>(Arrays.asList(
        "mp4", "m4v", "webm", "mkv", "mov", "avi", "ogv", "3gp", "ts", "flv", "wmv", "mpg", "mpeg", "m2ts", "mts"
    ));

    private static final Object STREAM_LOCK = new Object();
    private static ServerSocket streamServerSocket = null;
    private static int streamPort = -1;
    private static ExecutorService streamExecutor = null;
    private static final ConcurrentHashMap<String, String> TOKEN_TO_PATH = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<String, String> PATH_TO_TOKEN = new ConcurrentHashMap<>();

    private String guessMimeType(String filePath) {
        int dot = filePath.lastIndexOf('.');
        String ext = (dot >= 0 && dot < filePath.length() - 1)
            ? filePath.substring(dot + 1).toLowerCase(Locale.ROOT)
            : "";
        switch (ext) {
            case "mp4":
            case "m4v":
                return "video/mp4";
            case "webm":
                return "video/webm";
            case "mkv":
                return "video/x-matroska";
            case "mov":
                return "video/quicktime";
            case "avi":
                return "video/x-msvideo";
            case "3gp":
                return "video/3gpp";
            case "ogv":
                return "video/ogg";
            case "ts":
            case "m2ts":
            case "mts":
                return "video/mp2t";
            case "flv":
                return "video/x-flv";
            case "wmv":
                return "video/x-ms-wmv";
            case "mpg":
            case "mpeg":
                return "video/mpeg";
            case "mp3":
                return "audio/mpeg";
            case "m4a":
            case "aac":
                return "audio/mp4";
            case "flac":
                return "audio/flac";
            case "ogg":
            case "oga":
            case "opus":
                return "audio/ogg";
            case "wav":
                return "audio/wav";
            case "weba":
                return "audio/webm";
            default:
                return "application/octet-stream";
        }
    }

    private Uri findMediaStoreUri(String filePath) {
        ContentResolver cr = getContext().getContentResolver();
        Uri[] uris = new Uri[] {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            MediaStore.Files.getContentUri("external")
        };
        String[] proj = new String[] { MediaStore.MediaColumns._ID };
        for (Uri base : uris) {
            try (Cursor c = cr.query(base, proj, MediaStore.MediaColumns.DATA + "=?", new String[] { filePath }, null)) {
                if (c != null && c.moveToFirst()) {
                    long id = c.getLong(0);
                    return ContentUris.withAppendedId(base, id);
                }
            } catch (Exception ignored) {
            }
        }
        return null;
    }

    private int ensureStreamServerStarted() throws IOException {
        synchronized (STREAM_LOCK) {
            if (streamServerSocket != null && !streamServerSocket.isClosed() && streamPort > 0) {
                return streamPort;
            }
            streamServerSocket = new ServerSocket(0, 32, InetAddress.getByName("127.0.0.1"));
            streamPort = streamServerSocket.getLocalPort();
            streamExecutor = Executors.newFixedThreadPool(4);
            final ServerSocket serverRef = streamServerSocket;
            Thread acceptThread = new Thread(() -> {
                while (!serverRef.isClosed()) {
                    try {
                        Socket client = serverRef.accept();
                        ExecutorService exec = streamExecutor;
                        if (exec != null && !exec.isShutdown()) {
                            exec.execute(() -> handleStreamClient(client));
                        } else {
                            client.close();
                        }
                    } catch (IOException ignored) {
                        if (serverRef.isClosed()) break;
                    }
                }
            }, "HuyinStreamServer");
            acceptThread.setDaemon(true);
            acceptThread.start();
            return streamPort;
        }
    }

    private void writeSimpleHttpError(OutputStream out, int code, String reason) throws IOException {
        String body = code + " " + reason + "\n";
        String resp = "HTTP/1.1 " + code + " " + reason + "\r\n"
            + "Content-Type: text/plain; charset=utf-8\r\n"
            + "Content-Length: " + body.length() + "\r\n"
            + "Access-Control-Allow-Origin: *\r\n"
            + "Connection: close\r\n\r\n" + body;
        out.write(resp.getBytes(StandardCharsets.US_ASCII));
        out.flush();
    }

    private void handleStreamClient(Socket socket) {
        try {
            socket.setSoTimeout(30000);
            BufferedReader reader = new BufferedReader(
                new InputStreamReader(socket.getInputStream(), StandardCharsets.US_ASCII)
            );
            OutputStream rawOut = new BufferedOutputStream(socket.getOutputStream(), 65536);

            String requestLine = reader.readLine();
            if (requestLine == null || requestLine.trim().isEmpty()) {
                return;
            }
            String[] parts = requestLine.split("\\s+");
            if (parts.length < 2) {
                writeSimpleHttpError(rawOut, 400, "Bad Request");
                return;
            }
            String method = parts[0].toUpperCase(Locale.ROOT);
            String target = parts[1];
            int qIdx = target.indexOf('?');
            if (qIdx >= 0) target = target.substring(0, qIdx);

            String rangeHeader = null;
            String headerLine;
            while ((headerLine = reader.readLine()) != null && !headerLine.isEmpty()) {
                int colon = headerLine.indexOf(':');
                if (colon > 0) {
                    String hName = headerLine.substring(0, colon).trim().toLowerCase(Locale.ROOT);
                    if ("range".equals(hName)) {
                        rangeHeader = headerLine.substring(colon + 1).trim();
                    }
                }
            }

            if ("OPTIONS".equals(method)) {
                String resp = "HTTP/1.1 204 No Content\r\n"
                    + "Access-Control-Allow-Origin: *\r\n"
                    + "Access-Control-Allow-Methods: GET, HEAD, OPTIONS\r\n"
                    + "Access-Control-Allow-Headers: Range\r\n"
                    + "Connection: close\r\n\r\n";
                rawOut.write(resp.getBytes(StandardCharsets.US_ASCII));
                rawOut.flush();
                return;
            }

            if (!"GET".equals(method) && !"HEAD".equals(method)) {
                writeSimpleHttpError(rawOut, 405, "Method Not Allowed");
                return;
            }

            if (!target.startsWith("/media/")) {
                writeSimpleHttpError(rawOut, 404, "Not Found");
                return;
            }
            String rest = target.substring("/media/".length());
            int slashIdx = rest.indexOf('/');
            String token = slashIdx >= 0 ? rest.substring(0, slashIdx) : rest;
            String filePath = TOKEN_TO_PATH.get(token);
            if (filePath == null) {
                writeSimpleHttpError(rawOut, 404, "Not Found");
                return;
            }

            File file = new File(filePath);
            boolean canReadFile = file.exists() && file.isFile() && file.canRead();
            AssetFileDescriptor afd = null;
            long totalLen = canReadFile ? file.length() : -1L;

            if (!canReadFile || totalLen <= 0) {
                Uri contentUri = findMediaStoreUri(filePath);
                if (contentUri != null) {
                    afd = getContext().getContentResolver().openAssetFileDescriptor(contentUri, "r");
                    if (afd != null) {
                        totalLen = afd.getLength();
                    }
                }
            }

            if (totalLen <= 0 && !canReadFile && afd == null) {
                writeSimpleHttpError(rawOut, 404, "Not Found");
                return;
            }

            try {
                if (totalLen < 0 && afd != null) {
                    try (FileInputStream probe = afd.createInputStream()) {
                        totalLen = probe.getChannel().size();
                    } catch (Exception ignored) {
                    }
                }
                if (totalLen <= 0) {
                    writeSimpleHttpError(rawOut, 404, "Empty Or Unreadable");
                    return;
                }

                long start = 0;
                long end = totalLen - 1;
                boolean hasRange = false;

                if (rangeHeader != null && rangeHeader.toLowerCase(Locale.ROOT).startsWith("bytes=")) {
                    String spec = rangeHeader.substring("bytes=".length()).trim();
                    int comma = spec.indexOf(',');
                    if (comma >= 0) spec = spec.substring(0, comma).trim();
                    int dash = spec.indexOf('-');
                    if (dash >= 0) {
                        String sStart = spec.substring(0, dash).trim();
                        String sEnd = spec.substring(dash + 1).trim();
                        try {
                            if (sStart.isEmpty() && !sEnd.isEmpty()) {
                                long suffix = Long.parseLong(sEnd);
                                start = Math.max(0L, totalLen - suffix);
                                end = totalLen - 1;
                                hasRange = true;
                            } else if (!sStart.isEmpty()) {
                                start = Long.parseLong(sStart);
                                end = sEnd.isEmpty() ? (totalLen - 1) : Math.min(totalLen - 1, Long.parseLong(sEnd));
                                hasRange = true;
                            }
                        } catch (NumberFormatException ignored) {
                            hasRange = false;
                        }
                    }
                }

                if (hasRange && (start < 0 || start >= totalLen || end < start)) {
                    String resp = "HTTP/1.1 416 Range Not Satisfiable\r\n"
                        + "Content-Range: bytes */" + totalLen + "\r\n"
                        + "Access-Control-Allow-Origin: *\r\n"
                        + "Connection: close\r\n\r\n";
                    rawOut.write(resp.getBytes(StandardCharsets.US_ASCII));
                    rawOut.flush();
                    return;
                }

                long contentLength = (end - start) + 1;
                String mime = guessMimeType(filePath);
                StringBuilder headers = new StringBuilder();
                headers.append(hasRange ? "HTTP/1.1 206 Partial Content\r\n" : "HTTP/1.1 200 OK\r\n");
                headers.append("Content-Type: ").append(mime).append("\r\n");
                headers.append("Accept-Ranges: bytes\r\n");
                headers.append("Content-Length: ").append(contentLength).append("\r\n");
                if (hasRange) {
                    headers.append("Content-Range: bytes ").append(start).append('-').append(end)
                        .append('/').append(totalLen).append("\r\n");
                }
                headers.append("Access-Control-Allow-Origin: *\r\n");
                headers.append("Cache-Control: no-store\r\n");
                headers.append("Connection: close\r\n\r\n");

                rawOut.write(headers.toString().getBytes(StandardCharsets.US_ASCII));
                rawOut.flush();

                if ("HEAD".equals(method)) {
                    return;
                }

                byte[] buf = new byte[65536];
                long remaining = contentLength;
                if (canReadFile) {
                    try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
                        raf.seek(start);
                        while (remaining > 0) {
                            int toRead = (int) Math.min(buf.length, remaining);
                            int read = raf.read(buf, 0, toRead);
                            if (read < 0) break;
                            rawOut.write(buf, 0, read);
                            remaining -= read;
                        }
                        rawOut.flush();
                    }
                } else if (afd != null) {
                    try (FileInputStream fis = afd.createInputStream()) {
                        fis.getChannel().position(start);
                        while (remaining > 0) {
                            int toRead = (int) Math.min(buf.length, remaining);
                            int read = fis.read(buf, 0, toRead);
                            if (read < 0) break;
                            rawOut.write(buf, 0, read);
                            remaining -= read;
                        }
                        rawOut.flush();
                    }
                }
            } finally {
                if (afd != null) {
                    try {
                        afd.close();
                    } catch (IOException ignored) {
                    }
                }
            }
        } catch (IOException ignored) {
            // El visor cerró la conexión al adelantar o salir
        } finally {
            try {
                socket.close();
            } catch (IOException ignored) {
            }
        }
    }

    private String activeAlias() {
        return Build.VERSION.SDK_INT >= 33 ? "media" : "storage";
    }

    private String detectKind(String name) {
        int dot = name.lastIndexOf('.');
        if (dot < 0 || dot >= name.length() - 1) return null;
        String ext = name.substring(dot + 1).toLowerCase(Locale.ROOT);
        if (AUDIO_EXTS.contains(ext)) return "audio";
        if (VIDEO_EXTS.contains(ext)) return "video";
        return null;
    }

    @PluginMethod
    public void ensurePermissions(PluginCall call) {
        String alias = activeAlias();
        if (getPermissionState(alias) == PermissionState.GRANTED) {
            JSObject ret = new JSObject();
            ret.put("granted", true);
            call.resolve(ret);
            return;
        }
        requestPermissionForAlias(alias, call, "mediaPermCallback");
    }

    @PermissionCallback
    private void mediaPermCallback(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("granted", getPermissionState(activeAlias()) == PermissionState.GRANTED);
        call.resolve(ret);
    }

    private void queryMediaStoreCounts(Map<String, Integer> folderCounts) {
        ContentResolver cr = getContext().getContentResolver();
        Uri[] uris = new Uri[] {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        };
        String[] proj = new String[] { MediaStore.MediaColumns.DATA };
        for (Uri uri : uris) {
            try (Cursor c = cr.query(uri, proj, null, null, null)) {
                if (c == null) continue;
                int idx = c.getColumnIndex(MediaStore.MediaColumns.DATA);
                if (idx < 0) continue;
                while (c.moveToNext()) {
                    String filePath = c.getString(idx);
                    if (filePath == null) continue;
                    File f = new File(filePath);
                    String parent = f.getParent();
                    if (parent != null) {
                        folderCounts.put(parent, folderCounts.getOrDefault(parent, 0) + 1);
                    }
                }
            } catch (Exception ignored) {
            }
        }
    }

    @PluginMethod
    public void listDirectory(PluginCall call) {
        File root = Environment.getExternalStorageDirectory();
        String rootPath = root.getAbsolutePath();
        String reqPath = call.getString("path");
        File current = (reqPath != null && !reqPath.trim().isEmpty()) ? new File(reqPath) : root;
        if (!current.exists() || !current.isDirectory()) {
            current = root;
        }
        String currentPath = current.getAbsolutePath();

        Map<String, Integer> mediaStoreCounts = new HashMap<>();
        queryMediaStoreCounts(mediaStoreCounts);

        int mediaCountHere = 0;
        Map<String, JSObject> dirMap = new LinkedHashMap<>();
        Map<String, JSObject> fileMap = new LinkedHashMap<>();

        File[] children = current.listFiles();
        if (children != null) {
            Arrays.sort(children, Comparator.comparing(File::getName, String.CASE_INSENSITIVE_ORDER));
            int dirProbeBudget = 24;
            for (File child : children) {
                String name = child.getName();
                if (name.startsWith(".")) continue;
                if (child.isDirectory()) {
                    if ("Android".equals(name) && currentPath.equals(rootPath)) continue;
                    int count = mediaStoreCounts.getOrDefault(child.getAbsolutePath(), 0);
                    if (count == 0 && dirProbeBudget > 0) {
                        dirProbeBudget--;
                        File[] sub = child.listFiles();
                        if (sub != null) {
                            int limit = Math.min(sub.length, 250);
                            for (int i = 0; i < limit; i++) {
                                File s = sub[i];
                                if (s.isFile() && detectKind(s.getName()) != null) count++;
                            }
                        }
                    }
                    JSObject d = new JSObject();
                    d.put("name", name);
                    d.put("path", child.getAbsolutePath());
                    d.put("mediaCount", count);
                    dirMap.put(child.getAbsolutePath(), d);
                } else if (child.isFile()) {
                    String kind = detectKind(name);
                    if (kind != null) {
                        mediaCountHere++;
                        JSObject fObj = new JSObject();
                        fObj.put("name", name);
                        fObj.put("path", child.getAbsolutePath());
                        fObj.put("size", child.length());
                        fObj.put("lastModified", child.lastModified());
                        fObj.put("kind", kind);
                        fileMap.put(child.getAbsolutePath(), fObj);
                    }
                }
            }
        }

        for (Map.Entry<String, Integer> entry : mediaStoreCounts.entrySet()) {
            String folderPath = entry.getKey();
            if (folderPath.equals(currentPath)) {
                if (mediaCountHere == 0) mediaCountHere = entry.getValue();
                continue;
            }
            if (folderPath.startsWith(currentPath + "/")) {
                String rest = folderPath.substring(currentPath.length() + 1);
                int slash = rest.indexOf('/');
                String directChildName = slash >= 0 ? rest.substring(0, slash) : rest;
                if (!directChildName.isEmpty() && !directChildName.startsWith(".")) {
                    String directChildPath = currentPath + "/" + directChildName;
                    if (!dirMap.containsKey(directChildPath)) {
                        JSObject d = new JSObject();
                        d.put("name", directChildName);
                        d.put("path", directChildPath);
                        d.put("mediaCount", slash < 0 ? entry.getValue() : 0);
                        dirMap.put(directChildPath, d);
                    }
                }
            }
        }

        if (fileMap.isEmpty() && mediaCountHere > 0) {
            ContentResolver cr = getContext().getContentResolver();
            String prefix = currentPath + "/";
            Uri[] uris = new Uri[] {
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            };
            String[] proj = new String[] {
                MediaStore.MediaColumns.DATA,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.SIZE,
                MediaStore.MediaColumns.DATE_MODIFIED
            };
            for (int u = 0; u < uris.length; u++) {
                String kindFallback = u == 0 ? "audio" : "video";
                try (Cursor c = cr.query(uris[u], proj, MediaStore.MediaColumns.DATA + " LIKE ?", new String[] { prefix + "%" }, null)) {
                    if (c == null) continue;
                    int dataIdx = c.getColumnIndex(MediaStore.MediaColumns.DATA);
                    int nameIdx = c.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME);
                    int sizeIdx = c.getColumnIndex(MediaStore.MediaColumns.SIZE);
                    int modIdx = c.getColumnIndex(MediaStore.MediaColumns.DATE_MODIFIED);
                    while (c.moveToNext()) {
                        String p = dataIdx >= 0 ? c.getString(dataIdx) : null;
                        if (p == null || !p.startsWith(prefix)) continue;
                        if (p.substring(prefix.length()).contains("/")) continue;
                        if (fileMap.containsKey(p)) continue;
                        File f = new File(p);
                        String n = (nameIdx >= 0 && c.getString(nameIdx) != null) ? c.getString(nameIdx) : f.getName();
                        String kind = detectKind(n);
                        if (kind == null) kind = kindFallback;
                        JSObject fObj = new JSObject();
                        fObj.put("name", n);
                        fObj.put("path", p);
                        fObj.put("size", sizeIdx >= 0 ? c.getLong(sizeIdx) : f.length());
                        fObj.put("lastModified", modIdx >= 0 ? c.getLong(modIdx) * 1000L : f.lastModified());
                        fObj.put("kind", kind);
                        fileMap.put(p, fObj);
                    }
                } catch (Exception ignored) {
                }
            }
        }

        JSArray directories = new JSArray();
        List<JSObject> sortedDirs = new ArrayList<>(dirMap.values());
        Collections.sort(sortedDirs, (a, b) -> a.optString("name", "").compareToIgnoreCase(b.optString("name", "")));
        for (JSObject d : sortedDirs) {
            directories.put(d);
        }

        JSArray files = new JSArray();
        List<JSObject> sortedFiles = new ArrayList<>(fileMap.values());
        Collections.sort(sortedFiles, (a, b) -> a.optString("name", "").compareToIgnoreCase(b.optString("name", "")));
        for (JSObject fObj : sortedFiles) {
            files.put(fObj);
        }

        JSArray shortcuts = new JSArray();
        String[][] quickCandidates = new String[][] {
            { "Almacenamiento interno", rootPath },
            { "Música", Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC).getAbsolutePath() },
            { "Descargas", Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() },
            { "Películas", Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES).getAbsolutePath() },
            { "Podcasts", Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PODCASTS).getAbsolutePath() }
        };
        for (String[] item : quickCandidates) {
            File f = new File(item[1]);
            if (f.exists() && f.isDirectory()) {
                JSObject s = new JSObject();
                s.put("name", item[0]);
                s.put("path", f.getAbsolutePath());
                shortcuts.put(s);
            }
        }

        String parentPath = null;
        if (!currentPath.equals(rootPath)) {
            File p = current.getParentFile();
            if (p != null && p.getAbsolutePath().startsWith(rootPath)) {
                parentPath = p.getAbsolutePath();
            }
        }

        JSObject res = new JSObject();
        res.put("currentPath", currentPath);
        res.put("parentPath", parentPath);
        res.put("rootPath", rootPath);
        res.put("directories", directories);
        res.put("files", files);
        res.put("mediaCountHere", Math.max(mediaCountHere, sortedFiles.size()));
        res.put("shortcuts", shortcuts);
        call.resolve(res);
    }

    @PluginMethod
    public void scanDirectory(PluginCall call) {
        String dirPath = call.getString("path");
        int maxFiles = call.getInt("maxFiles", 600);
        if (dirPath == null || dirPath.trim().isEmpty()) {
            JSObject empty = new JSObject();
            empty.put("files", new JSArray());
            call.resolve(empty);
            return;
        }

        File rootDir = new File(dirPath);
        List<JSObject> found = new ArrayList<>();
        Set<String> seenPaths = new HashSet<>();

        List<File> queue = new ArrayList<>();
        queue.add(rootDir);
        for (int i = 0; i < queue.size() && found.size() < maxFiles; i++) {
            File dir = queue.get(i);
            File[] items = dir.listFiles();
            if (items == null) continue;
            Arrays.sort(items, Comparator.comparing(File::getName, String.CASE_INSENSITIVE_ORDER));
            for (File item : items) {
                if (found.size() >= maxFiles) break;
                String name = item.getName();
                if (name.startsWith(".")) continue;
                if (item.isDirectory()) {
                    if (!"Android".equals(name)) {
                        queue.add(item);
                    }
                } else if (item.isFile()) {
                    String kind = detectKind(name);
                    if (kind != null && seenPaths.add(item.getAbsolutePath())) {
                        JSObject obj = new JSObject();
                        obj.put("name", name);
                        obj.put("path", item.getAbsolutePath());
                        obj.put("size", item.length());
                        obj.put("lastModified", item.lastModified());
                        obj.put("kind", kind);
                        found.add(obj);
                    }
                }
            }
        }

        if (found.size() < maxFiles) {
            ContentResolver cr = getContext().getContentResolver();
            String prefix = rootDir.getAbsolutePath() + "/";
            Uri[] uris = new Uri[] {
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            };
            String[] proj = new String[] {
                MediaStore.MediaColumns.DATA,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.SIZE,
                MediaStore.MediaColumns.DATE_MODIFIED
            };
            for (int u = 0; u < uris.length && found.size() < maxFiles; u++) {
                String kindFallback = u == 0 ? "audio" : "video";
                try (Cursor c = cr.query(uris[u], proj, MediaStore.MediaColumns.DATA + " LIKE ?", new String[] { prefix + "%" }, null)) {
                    if (c == null) continue;
                    int dataIdx = c.getColumnIndex(MediaStore.MediaColumns.DATA);
                    int nameIdx = c.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME);
                    int sizeIdx = c.getColumnIndex(MediaStore.MediaColumns.SIZE);
                    int modIdx = c.getColumnIndex(MediaStore.MediaColumns.DATE_MODIFIED);
                    while (c.moveToNext() && found.size() < maxFiles) {
                        String p = dataIdx >= 0 ? c.getString(dataIdx) : null;
                        if (p == null || !seenPaths.add(p)) continue;
                        File f = new File(p);
                        String n = (nameIdx >= 0 && c.getString(nameIdx) != null) ? c.getString(nameIdx) : f.getName();
                        String kind = detectKind(n);
                        if (kind == null) kind = kindFallback;
                        long sz = sizeIdx >= 0 ? c.getLong(sizeIdx) : f.length();
                        long mod = modIdx >= 0 ? c.getLong(modIdx) * 1000L : f.lastModified();
                        JSObject obj = new JSObject();
                        obj.put("name", n);
                        obj.put("path", p);
                        obj.put("size", sz);
                        obj.put("lastModified", mod);
                        obj.put("kind", kind);
                        found.add(obj);
                    }
                } catch (Exception ignored) {
                }
            }
        }

        JSArray arr = new JSArray();
        for (JSObject o : found) {
            arr.put(o);
        }
        JSObject res = new JSObject();
        res.put("files", arr);
        call.resolve(res);
    }

    @PluginMethod
    public void setOrientation(PluginCall call) {
        String mode = call.getString("mode", "unspecified");
        if (getActivity() == null) {
            call.resolve();
            return;
        }
        getActivity().runOnUiThread(() -> {
            if ("landscape".equals(mode)) {
                getActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            } else if ("portrait".equals(mode)) {
                getActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            } else {
                getActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
            }
            call.resolve();
        });
    }

    @PluginMethod
    public void getStreamUrl(PluginCall call) {
        String path = call.getString("path");
        if (path == null || path.trim().isEmpty()) {
            call.reject("Missing file path");
            return;
        }
        try {
            int port = ensureStreamServerStarted();
            String token = PATH_TO_TOKEN.get(path);
            if (token == null) {
                token = UUID.randomUUID().toString().replace("-", "");
                PATH_TO_TOKEN.put(path, token);
                TOKEN_TO_PATH.put(token, path);
            }
            String fileName = new File(path).getName();
            String encodedName = URLEncoder.encode(fileName.isEmpty() ? "media" : fileName, "UTF-8").replace("+", "%20");
            JSObject ret = new JSObject();
            ret.put("url", "http://127.0.0.1:" + port + "/media/" + token + "/" + encodedName);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Stream server failed", e);
        }
    }

    @PluginMethod
    public void openNativeVideo(PluginCall call) {
        String path = call.getString("path");
        String title = call.getString("title", "Video");
        Double startSecObj = call.getDouble("startSec");
        double startSec = startSecObj != null ? startSecObj : 0.0;
        if (path == null || path.trim().isEmpty() || getActivity() == null) {
            call.reject("Missing video path");
            return;
        }
        getActivity().runOnUiThread(() -> {
            Intent intent = new Intent(getContext(), NativeVideoActivity.class);
            intent.putExtra("path", path);
            intent.putExtra("title", title);
            intent.putExtra("startSec", startSec);
            getActivity().startActivity(intent);
            call.resolve();
        });
    }

    @PluginMethod
    public void openExternalVideo(PluginCall call) {
        String path = call.getString("path");
        String title = call.getString("title", "Abrir video");
        if (path == null || path.trim().isEmpty() || getActivity() == null) {
            call.reject("Missing video path");
            return;
        }
        Uri contentUri = findMediaStoreUri(path);
        if (contentUri == null) {
            call.reject("Content URI not found");
            return;
        }
        getActivity().runOnUiThread(() -> {
            try {
                Intent viewIntent = new Intent(Intent.ACTION_VIEW);
                viewIntent.setDataAndType(contentUri, "video/*");
                viewIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                getActivity().startActivity(Intent.createChooser(viewIntent, title));
                call.resolve();
            } catch (Exception e) {
                call.reject("No external player", e);
            }
        });
    }

    @PluginMethod
    public void ensureNotificationPermission(PluginCall call) {
        if (Build.VERSION.SDK_INT < 33) {
            JSObject ret = new JSObject();
            ret.put("granted", true);
            call.resolve(ret);
            return;
        }
        if (getPermissionState("notifications") == PermissionState.GRANTED) {
            JSObject ret = new JSObject();
            ret.put("granted", true);
            call.resolve(ret);
            return;
        }
        requestPermissionForAlias("notifications", call, "notifPermCallback");
    }

    @PermissionCallback
    private void notifPermCallback(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("granted", Build.VERSION.SDK_INT < 33 || getPermissionState("notifications") == PermissionState.GRANTED);
        call.resolve(ret);
    }

    @PluginMethod
    public void updateMediaNotification(PluginCall call) {
        try {
            boolean isPlaying = Boolean.TRUE.equals(call.getBoolean("isPlaying", false));
            boolean alreadyRunning = MediaNotificationService.isRunning();
            if (!isPlaying && !alreadyRunning) {
                call.resolve();
                return;
            }

            Intent intent = new Intent(getContext(), MediaNotificationService.class);
            intent.setAction(MediaNotificationService.ACTION_UPDATE);
            intent.putExtra("title", call.getString("title", "琥音Hǔyīn"));
            intent.putExtra("artist", call.getString("artist", "Biblioteca local"));
            intent.putExtra("album", call.getString("album", "琥音Hǔyīn"));
            intent.putExtra("isPlaying", isPlaying);

            Double durationObj = call.getDouble("durationSec");
            Double positionObj = call.getDouble("positionSec");
            Double rateObj = call.getDouble("playbackRate");
            double durationSec = durationObj != null ? durationObj : 0.0;
            double positionSec = positionObj != null ? positionObj : 0.0;
            double playbackRate = rateObj != null ? rateObj : 1.0;
            intent.putExtra("durationMs", (long) Math.max(0.0, durationSec * 1000.0));
            intent.putExtra("positionMs", (long) Math.max(0.0, positionSec * 1000.0));
            intent.putExtra("playbackRate", (float) Math.max(0.25, playbackRate));

            if (isPlaying || !alreadyRunning) {
                intent.putExtra("fromForegroundStart", true);
                ContextCompat.startForegroundService(getContext(), intent);
            } else {
                intent.putExtra("fromForegroundStart", false);
                getContext().startService(intent);
            }
        } catch (Exception ignored) {
        }
        call.resolve();
    }

    @PluginMethod
    public void clearMediaNotification(PluginCall call) {
        try {
            Intent intent = new Intent(getContext(), MediaNotificationService.class);
            getContext().stopService(intent);
        } catch (Exception ignored) {
        }
        call.resolve();
    }

    @Override
    protected void handleOnDestroy() {
        synchronized (STREAM_LOCK) {
            if (streamServerSocket != null) {
                try {
                    streamServerSocket.close();
                } catch (IOException ignored) {
                }
                streamServerSocket = null;
            }
            streamPort = -1;
            if (streamExecutor != null) {
                streamExecutor.shutdownNow();
                streamExecutor = null;
            }
        }
        super.handleOnDestroy();
    }
}
