from pathlib import Path
import re
import shutil
import subprocess

manifest_path = Path("android/app/src/main/AndroidManifest.xml")
manifest = manifest_path.read_text(encoding="utf-8")

perms = [
    '    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />',
    '    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />',
    '    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />',
    '    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
    '    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />',
    '    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />',
]
missing = [p for p in perms if p.split('"')[1] not in manifest]
if missing:
    manifest = re.sub(r"<application\b", "\n".join(missing) + "\n\n    <application", manifest, count=1)

app_attrs = [
    ('android:requestLegacyExternalStorage', 'true'),
    ('android:hardwareAccelerated', 'true'),
    ('android:usesCleartextTraffic', 'true'),
]
for attr, val in app_attrs:
    if attr not in manifest:
        manifest = re.sub(r"<application\b", f'<application {attr}="{val}"', manifest, count=1)

native_activity_xml = (
    '        <activity\n'
    '            android:name="com.huyin.reproductor.NativeVideoActivity"\n'
    '            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|smallestScreenSize|screenLayout"\n'
    '            android:exported="false"\n'
    '            android:hardwareAccelerated="true"\n'
    '            android:theme="@style/AppTheme.NoActionBar" />\n'
)
if "com.huyin.reproductor.NativeVideoActivity" not in manifest:
    manifest = manifest.replace("</application>", native_activity_xml + "    </application>", 1)

media_service_xml = (
    '        <service\n'
    '            android:name="com.huyin.reproductor.MediaNotificationService"\n'
    '            android:exported="false"\n'
    '            android:foregroundServiceType="mediaPlayback" />\n'
)
if "com.huyin.reproductor.MediaNotificationService" not in manifest:
    manifest = manifest.replace("</application>", media_service_xml + "    </application>", 1)

manifest_path.write_text(manifest, encoding="utf-8")

java_dir = Path("android/app/src/main/java/com/huyin/reproductor")
java_dir.mkdir(parents=True, exist_ok=True)
shutil.copy2("android-native/LocalMediaPlugin.java", java_dir / "LocalMediaPlugin.java")
shutil.copy2("android-native/MainActivity.java", java_dir / "MainActivity.java")
shutil.copy2("android-native/NativeVideoActivity.java", java_dir / "NativeVideoActivity.java")
shutil.copy2("android-native/MediaNotificationService.java", java_dir / "MediaNotificationService.java")

icon_src = Path("public/pwa-512x512.png") if Path("public/pwa-512x512.png").exists() else Path("public/pwa-192x192.png")
fallback_icon = Path("public/pwa-192x192.png") if Path("public/pwa-192x192.png").exists() else icon_src

if icon_src.exists():
    anydpi = Path("android/app/src/main/res/mipmap-anydpi-v26")
    if anydpi.exists():
        shutil.rmtree(anydpi)
    density_sizes = {
        "mipmap-mdpi": 48,
        "mipmap-hdpi": 72,
        "mipmap-xhdpi": 96,
        "mipmap-xxhdpi": 144,
        "mipmap-xxxhdpi": 192,
    }
    magick_bin = shutil.which("convert") or shutil.which("magick")
    for density, px in density_sizes.items():
        target_dir = Path("android/app/src/main/res") / density
        if not target_dir.exists():
            continue
        out_main = target_dir / "ic_launcher.png"
        out_round = target_dir / "ic_launcher_round.png"
        resized = False
        if magick_bin:
            try:
                subprocess.run(
                    [magick_bin, str(icon_src), "-resize", f"{px}x{px}", str(out_main)],
                    check=True,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
                shutil.copy2(out_main, out_round)
                resized = True
            except Exception:
                resized = False
        if not resized:
            shutil.copy2(fallback_icon, out_main)
            shutil.copy2(fallback_icon, out_round)

print("Android native setup completed.")
