package com.huyin.reproductor;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import java.io.File;
import java.io.FileInputStream;
import java.util.Locale;

public class NativeVideoActivity extends AppCompatActivity implements SurfaceHolder.Callback {
    private SurfaceView surfaceView;
    private MediaPlayer mediaPlayer;
    private FrameLayout rootLayout;
    private LinearLayout topBar;
    private LinearLayout bottomBar;
    private TextView titleView;
    private TextView resView;
    private TextView timeCurrentView;
    private TextView timeTotalView;
    private TextView playPauseBtn;
    private TextView hudBadge;
    private SeekBar seekBar;

    private String videoPath;
    private String videoTitle;
    private double startSec = 0.0;
    private int videoWidth = 0;
    private int videoHeight = 0;
    private boolean isLandscape = true;
    private boolean controlsVisible = true;
    private boolean isSeeking = false;
    private boolean isPrepared = false;
    private boolean isActivityPaused = false;
    private boolean errorFallbackLaunched = false;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable hideControlsTask = () -> setControlsVisible(false);
    private final Runnable hideHudTask = () -> {
        if (hudBadge != null) hudBadge.setVisibility(View.GONE);
    };
    private final Runnable progressTask = new Runnable() {
        @Override
        public void run() {
            if (isActivityPaused || mediaPlayer == null || !isPrepared) return;
            try {
                int pos = mediaPlayer.getCurrentPosition();
                int dur = mediaPlayer.getDuration();
                if (!isSeeking && dur > 0) {
                    seekBar.setMax(dur);
                    seekBar.setProgress(pos);
                    timeCurrentView.setText(formatMs(pos));
                    timeTotalView.setText(formatMs(dur));
                }
                if (mediaPlayer.isPlaying()) {
                    handler.postDelayed(this, 450);
                }
            } catch (Exception ignored) {
            }
        }
    };

    private float gestureStartY = 0f;
    private float gestureStartX = 0f;
    private boolean gestureMoved = false;
    private float startBrightness = 1f;
    private int startVolume = 0;
    private int maxVolume = 15;
    private AudioManager audioManager;

    private int dp(int v) {
        return Math.round(TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()
        ));
    }

    private String formatMs(int ms) {
        int totalSec = Math.max(0, ms / 1000);
        int h = totalSec / 3600;
        int m = (totalSec % 3600) / 60;
        int s = totalSec % 60;
        if (h > 0) {
            return String.format(Locale.US, "%d:%02d:%02d", h, m, s);
        }
        return String.format(Locale.US, "%02d:%02d", m, s);
    }

    private TextView makePillButton(String text, int textColor, int bgColor) {
        TextView btn = new TextView(this);
        btn.setText(text);
        btn.setTextColor(textColor);
        btn.setBackgroundColor(bgColor);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(dp(12), dp(8), dp(12), dp(8));
        return btn;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        videoPath = getIntent().getStringExtra("path");
        videoTitle = getIntent().getStringExtra("title");
        startSec = getIntent().getDoubleExtra("startSec", 0.0);
        if (videoTitle == null || videoTitle.trim().isEmpty()) {
            videoTitle = "Video local";
        }

        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (audioManager != null) {
            maxVolume = Math.max(1, audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        }

        rootLayout = new FrameLayout(this);
        rootLayout.setBackgroundColor(Color.BLACK);

        surfaceView = new SurfaceView(this);
        FrameLayout.LayoutParams svParams = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            Gravity.CENTER
        );
        rootLayout.addView(surfaceView, svParams);
        surfaceView.getHolder().addCallback(this);

        // Barra superior
        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackgroundColor(Color.argb(190, 8, 10, 14));
        topBar.setPadding(dp(14), dp(10), dp(14), dp(10));

        TextView backBtn = makePillButton("← Volver", Color.WHITE, Color.argb(60, 255, 255, 255));
        backBtn.setOnClickListener(v -> finish());
        topBar.addView(backBtn);

        LinearLayout infoCol = new LinearLayout(this);
        infoCol.setOrientation(LinearLayout.VERTICAL);
        infoCol.setPadding(dp(12), 0, dp(12), 0);

        titleView = new TextView(this);
        titleView.setText(videoTitle);
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        titleView.setSingleLine(true);
        titleView.setEllipsize(TextUtils.TruncateAt.END);
        infoCol.addView(titleView);

        resView = new TextView(this);
        resView.setText("Reproducción directa");
        resView.setTextColor(Color.parseColor("#F59E0B"));
        resView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        infoCol.addView(resView);

        LinearLayout.LayoutParams infoParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        topBar.addView(infoCol, infoParams);

        TextView rotateBtn = makePillButton("↻ Girar", Color.BLACK, Color.parseColor("#F59E0B"));
        rotateBtn.setOnClickListener(v -> {
            isLandscape = !isLandscape;
            setRequestedOrientation(
                isLandscape
                    ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            );
            scheduleHideControls();
        });
        topBar.addView(rotateBtn);

        FrameLayout.LayoutParams topParams = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP
        );
        rootLayout.addView(topBar, topParams);

        // Barra inferior
        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.VERTICAL);
        bottomBar.setBackgroundColor(Color.argb(200, 8, 10, 14));
        bottomBar.setPadding(dp(14), dp(10), dp(14), dp(14));

        LinearLayout seekRow = new LinearLayout(this);
        seekRow.setOrientation(LinearLayout.HORIZONTAL);
        seekRow.setGravity(Gravity.CENTER_VERTICAL);

        timeCurrentView = new TextView(this);
        timeCurrentView.setText("00:00");
        timeCurrentView.setTextColor(Color.WHITE);
        timeCurrentView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        seekRow.addView(timeCurrentView);

        seekBar = new SeekBar(this);
        LinearLayout.LayoutParams sbParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        sbParams.setMargins(dp(8), 0, dp(8), 0);
        seekRow.addView(seekBar, sbParams);

        timeTotalView = new TextView(this);
        timeTotalView.setText("00:00");
        timeTotalView.setTextColor(Color.WHITE);
        timeTotalView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        seekRow.addView(timeTotalView);

        bottomBar.addView(seekRow);

        LinearLayout ctrlRow = new LinearLayout(this);
        ctrlRow.setOrientation(LinearLayout.HORIZONTAL);
        ctrlRow.setGravity(Gravity.CENTER);
        ctrlRow.setPadding(0, dp(8), 0, 0);

        TextView rewBtn = makePillButton("-10s", Color.WHITE, Color.argb(55, 255, 255, 255));
        rewBtn.setOnClickListener(v -> skipBy(-10000));
        ctrlRow.addView(rewBtn);

        playPauseBtn = makePillButton("Pausar", Color.BLACK, Color.parseColor("#F59E0B"));
        LinearLayout.LayoutParams ppParams = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        ppParams.setMargins(dp(12), 0, dp(12), 0);
        playPauseBtn.setOnClickListener(v -> togglePlay());
        ctrlRow.addView(playPauseBtn, ppParams);

        TextView fwdBtn = makePillButton("+10s", Color.WHITE, Color.argb(55, 255, 255, 255));
        fwdBtn.setOnClickListener(v -> skipBy(10000));
        ctrlRow.addView(fwdBtn);

        bottomBar.addView(ctrlRow);

        FrameLayout.LayoutParams bottomParams = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM
        );
        rootLayout.addView(bottomBar, bottomParams);

        // HUD flotante para brillo/volumen
        hudBadge = new TextView(this);
        hudBadge.setTextColor(Color.WHITE);
        hudBadge.setBackgroundColor(Color.argb(200, 15, 18, 25));
        hudBadge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        hudBadge.setPadding(dp(16), dp(10), dp(16), dp(10));
        hudBadge.setVisibility(View.GONE);
        FrameLayout.LayoutParams hudParams = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.CENTER
        );
        rootLayout.addView(hudBadge, hudParams);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                if (fromUser) {
                    timeCurrentView.setText(formatMs(progress));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
                isSeeking = true;
                handler.removeCallbacks(hideControlsTask);
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                isSeeking = false;
                if (mediaPlayer != null && isPrepared) {
                    mediaPlayer.seekTo(bar.getProgress());
                }
                scheduleHideControls();
            }
        });

        rootLayout.setOnTouchListener((v, event) -> handleTouch(event));

        ViewCompat.setOnApplyWindowInsetsListener(rootLayout, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            topBar.setPadding(dp(14) + bars.left, dp(10) + bars.top, dp(14) + bars.right, dp(10));
            bottomBar.setPadding(dp(14) + bars.left, dp(10), dp(14) + bars.right, dp(14) + bars.bottom);
            return insets;
        });

        setContentView(rootLayout);
        applySystemUi(true);
        scheduleHideControls();
    }

    private boolean handleTouch(MotionEvent event) {
        int w = Math.max(1, rootLayout.getWidth());
        int h = Math.max(1, rootLayout.getHeight());
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                gestureStartX = event.getX();
                gestureStartY = event.getY();
                gestureMoved = false;
                float curBright = getWindow().getAttributes().screenBrightness;
                startBrightness = curBright > 0 ? curBright : 0.8f;
                if (audioManager != null) {
                    startVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                float dy = gestureStartY - event.getY();
                if (Math.abs(dy) > dp(12)) {
                    gestureMoved = true;
                    float ratio = dy / (h * 0.55f);
                    if (gestureStartX < w * 0.5f) {
                        float nextB = Math.max(0.15f, Math.min(1.0f, startBrightness + ratio));
                        WindowManager.LayoutParams lp = getWindow().getAttributes();
                        lp.screenBrightness = nextB;
                        getWindow().setAttributes(lp);
                        showHud("Brillo: " + Math.round(nextB * 100f) + "%");
                    } else if (audioManager != null) {
                        int nextV = Math.max(0, Math.min(maxVolume, Math.round(startVolume + ratio * maxVolume)));
                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, nextV, 0);
                        int pct = Math.round((nextV * 100f) / maxVolume);
                        showHud("Volumen: " + pct + "%");
                    }
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (!gestureMoved) {
                    setControlsVisible(!controlsVisible);
                }
                return true;
        }
        return false;
    }

    private void showHud(String text) {
        hudBadge.setText(text);
        hudBadge.setVisibility(View.VISIBLE);
        handler.removeCallbacks(hideHudTask);
        handler.postDelayed(hideHudTask, 1400);
    }

    private void setControlsVisible(boolean visible) {
        controlsVisible = visible;
        int vis = visible ? View.VISIBLE : View.GONE;
        topBar.setVisibility(vis);
        bottomBar.setVisibility(vis);
        applySystemUi(visible);
        handler.removeCallbacks(hideControlsTask);
        if (visible) {
            handler.postDelayed(hideControlsTask, 3200);
        }
    }

    private void scheduleHideControls() {
        handler.removeCallbacks(hideControlsTask);
        handler.postDelayed(hideControlsTask, 3200);
    }

    private void applySystemUi(boolean showBars) {
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowInsetsControllerCompat controller =
            WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (controller != null) {
            controller.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            );
            if (showBars) {
                controller.show(WindowInsetsCompat.Type.systemBars());
            } else {
                controller.hide(WindowInsetsCompat.Type.systemBars());
            }
        }
    }

    private void togglePlay() {
        if (mediaPlayer == null || !isPrepared) return;
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
            playPauseBtn.setText("Reproducir");
            handler.removeCallbacks(progressTask);
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            mediaPlayer.start();
            playPauseBtn.setText("Pausar");
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            handler.removeCallbacks(progressTask);
            handler.post(progressTask);
        }
        scheduleHideControls();
    }

    private void skipBy(int deltaMs) {
        if (mediaPlayer == null || !isPrepared) return;
        int dur = Math.max(0, mediaPlayer.getDuration());
        int target = Math.max(0, Math.min(dur, mediaPlayer.getCurrentPosition() + deltaMs));
        mediaPlayer.seekTo(target);
        seekBar.setProgress(target);
        timeCurrentView.setText(formatMs(target));
        scheduleHideControls();
    }

    private void resizeVideoSurface() {
        if (rootLayout == null || surfaceView == null || videoWidth <= 0 || videoHeight <= 0) return;
        int rw = rootLayout.getWidth();
        int rh = rootLayout.getHeight();
        if (rw <= 0 || rh <= 0) return;

        float videoRatio = (float) videoWidth / (float) videoHeight;
        float screenRatio = (float) rw / (float) rh;

        int targetW;
        int targetH;
        if (videoRatio > screenRatio) {
            targetW = rw;
            targetH = Math.round(rw / videoRatio);
        } else {
            targetH = rh;
            targetW = Math.round(rh * videoRatio);
        }

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(targetW, targetH, Gravity.CENTER);
        surfaceView.setLayoutParams(lp);
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (surfaceView != null) {
            surfaceView.post(this::resizeVideoSurface);
        }
    }

    private String formatResolutionTag(int w, int h) {
        if (w <= 0 && h <= 0) return "";
        int maxDim = Math.max(w, h);
        int minDim = (w > 0 && h > 0) ? Math.min(w, h) : maxDim;
        if (maxDim >= 3800 || minDim >= 2100) return "4K";
        if (maxDim >= 2500 || minDim >= 1400) return "2K";
        if (maxDim >= 2000 || minDim >= 1200) return "1.5K";
        if (maxDim >= 1900 || minDim >= 1060) return "1080p";
        if (maxDim >= 1260 || minDim >= 700) return "720p";
        if (maxDim >= 840 || minDim >= 460) return "480p";
        if (maxDim >= 620 || minDim >= 350) return "360p";
        if (maxDim >= 440 || minDim >= 240) return "260p";
        if (minDim >= 120 || maxDim >= 200) return "144p";
        return minDim + "p";
    }

    private Uri findMediaStoreVideoUri(String path) {
        ContentResolver cr = getContentResolver();
        Uri[] uris = new Uri[] {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            MediaStore.Files.getContentUri("external")
        };
        String[] proj = new String[] { MediaStore.MediaColumns._ID };
        for (Uri base : uris) {
            try (Cursor c = cr.query(base, proj, MediaStore.MediaColumns.DATA + "=?", new String[] { path }, null)) {
                if (c != null && c.moveToFirst()) {
                    long id = c.getLong(0);
                    return ContentUris.withAppendedId(base, id);
                }
            } catch (Exception ignored) {
            }
        }
        return null;
    }

    private void openWithSystemChooser() {
        if (errorFallbackLaunched || videoPath == null) return;
        errorFallbackLaunched = true;
        releasePlayer();
        Uri contentUri = findMediaStoreVideoUri(videoPath);
        if (contentUri == null) {
            showHud("Códec no compatible con el teléfono");
            return;
        }
        try {
            Intent viewIntent = new Intent(Intent.ACTION_VIEW);
            viewIntent.setDataAndType(contentUri, "video/*");
            viewIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(viewIntent, videoTitle));
            finish();
        } catch (Exception ignored) {
            showHud("No hay reproductor compatible instalado");
        }
    }

    private void bindMediaDataSource(MediaPlayer mp, String path) throws Exception {
        File file = new File(path);
        if (file.exists() && file.canRead()) {
            try (FileInputStream fis = new FileInputStream(file)) {
                mp.setDataSource(fis.getFD());
                return;
            } catch (Exception ignored) {
            }
        }
        Uri contentUri = findMediaStoreVideoUri(path);
        if (contentUri != null) {
            mp.setDataSource(this, contentUri);
            return;
        }
        mp.setDataSource(path);
    }

    @Override
    public void surfaceCreated(@NonNull SurfaceHolder holder) {
        if (videoPath == null || videoPath.trim().isEmpty()) {
            finish();
            return;
        }
        releasePlayer();
        try {
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setAudioAttributes(
                new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                    .build()
            );
            mediaPlayer.setDisplay(holder);
            bindMediaDataSource(mediaPlayer, videoPath);
            mediaPlayer.setOnPreparedListener(mp -> {
                isPrepared = true;
                videoWidth = mp.getVideoWidth();
                videoHeight = mp.getVideoHeight();
                if (videoWidth > 0 && videoHeight > 0) {
                    String tag = formatResolutionTag(videoWidth, videoHeight);
                    resView.setText(tag.isEmpty() ? (videoWidth + "×" + videoHeight) : tag);
                }
                resizeVideoSurface();
                if (startSec > 0.5) {
                    int targetMs = (int) Math.round(startSec * 1000.0);
                    int dur = mp.getDuration();
                    if (dur <= 0 || targetMs < dur - 500) {
                        mp.seekTo(targetMs);
                    }
                    startSec = 0.0;
                }
                mp.start();
                playPauseBtn.setText("Pausar");
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                handler.post(progressTask);
            });
            mediaPlayer.setOnVideoSizeChangedListener((mp, width, height) -> {
                if (width > 0 && height > 0) {
                    videoWidth = width;
                    videoHeight = height;
                    String tag = formatResolutionTag(width, height);
                    resView.setText(tag.isEmpty() ? (width + "×" + height) : tag);
                    resizeVideoSurface();
                }
            });
            mediaPlayer.setOnCompletionListener(mp -> {
                handler.removeCallbacks(progressTask);
                playPauseBtn.setText("Reproducir");
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                setControlsVisible(true);
            });
            mediaPlayer.setOnErrorListener((mp, what, extra) -> {
                openWithSystemChooser();
                return true;
            });
            mediaPlayer.prepareAsync();
        } catch (Exception e) {
            openWithSystemChooser();
        }
    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder holder, int format, int width, int height) {
        resizeVideoSurface();
    }

    @Override
    public void surfaceDestroyed(@NonNull SurfaceHolder holder) {
        releasePlayer();
    }

    @Override
    protected void onPause() {
        isActivityPaused = true;
        handler.removeCallbacks(progressTask);
        handler.removeCallbacks(hideControlsTask);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (mediaPlayer != null && isPrepared) {
            try {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.pause();
                    playPauseBtn.setText("Reproducir");
                }
            } catch (Exception ignored) {
            }
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        isActivityPaused = false;
        if (mediaPlayer != null && isPrepared) {
            try {
                if (mediaPlayer.isPlaying()) {
                    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    handler.removeCallbacks(progressTask);
                    handler.post(progressTask);
                }
            } catch (Exception ignored) {
            }
        }
    }

    private void releasePlayer() {
        handler.removeCallbacks(progressTask);
        handler.removeCallbacks(hideControlsTask);
        handler.removeCallbacks(hideHudTask);
        isPrepared = false;
        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) mediaPlayer.stop();
            } catch (Exception ignored) {
            }
            try {
                mediaPlayer.release();
            } catch (Exception ignored) {
            }
            mediaPlayer = null;
        }
    }

    @Override
    protected void onDestroy() {
        releasePlayer();
        super.onDestroy();
    }
}
