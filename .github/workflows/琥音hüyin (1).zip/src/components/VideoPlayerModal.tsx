import {
  Captions,
  ChevronDown,
  CirclePlay,
  FileText,
  Headphones,
  Loader2,
  Lock,
  Maximize2,
  MoreVertical,
  Pause,
  PictureInPicture2,
  Play,
  RotateCcw,
  RotateCw,
  Scan,
  Settings,
  SkipBack,
  SkipForward,
  SlidersHorizontal,
  Smartphone,
  Sun,
  Unlock,
  Upload,
  Volume1,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { MediaItem, SubtitleStyle } from '../types/media';
import { audioEngine } from '../utils/audioEngine';
import { formatDuration, formatResolutionLabel } from '../utils/libraryDb';
import {
  isNativeAndroidMediaAvailable,
  openNativeAndroidVideo,
  setNativeOrientation,
} from '../utils/nativeAndroidMedia';
import { getActiveSubtitles, parseSubtitleContent, readSubtitleFile } from '../utils/subtitles';

interface VideoPlayerModalProps {
  video: MediaItem;
  videoUrl: string | null;
  subtitleStyle: SubtitleStyle;
  videoPipEnabled: boolean;
  videoPipPrompted: boolean;
  batterySaverEnabled: boolean;
  isPipMode: boolean;
  onSetPipMode: (pip: boolean) => void;
  onUpdatePipPreference: (enabled: boolean, prompted: boolean) => void;
  onUpdateSubtitleStyle: (style: SubtitleStyle) => void;
  onAttachSubtitles: (videoId: string, subtitleName: string, subtitleRaw: string) => void;
  onOpenAudioSettings: () => void;
  onClose: () => void;
}

type AspectMode = 'ajustar' | 'rellenar' | '16:9' | '4:3';

export function VideoPlayerModal({
  video,
  videoUrl,
  subtitleStyle,
  videoPipEnabled,
  videoPipPrompted,
  batterySaverEnabled,
  isPipMode,
  onSetPipMode,
  onUpdatePipPreference,
  onUpdateSubtitleStyle,
  onAttachSubtitles,
  onOpenAudioSettings,
  onClose,
}: VideoPlayerModalProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const subInputRef = useRef<HTMLInputElement | null>(null);
  const hideTimerRef = useRef<number | null>(null);
  const leftTimerRef = useRef<number | null>(null);
  const rightTimerRef = useRef<number | null>(null);
  const speedBadgeTimerRef = useRef<number | null>(null);
  const lastNonZeroVolumeRef = useRef(1);

  const [isPlaying, setIsPlaying] = useState(true);
  const [isBuffering, setIsBuffering] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(video.duration || 0);
  const [brightness, setBrightness] = useState(1); // 0.15 a 1.0 (máximo 100%)
  const [volume, setVolume] = useState(1); // 0 a 1.0 (máximo 100%)
  const [playbackRate, setPlaybackRate] = useState(1);
  const [aspectMode, setAspectMode] = useState<AspectMode>('ajustar');
  const [isLocked, setIsLocked] = useState(false);
  const [isLandscape, setIsLandscape] = useState(false);
  const [decodedDims, setDecodedDims] = useState<{ width: number; height: number } | null>(null);
  const [showControls, setShowControls] = useState(true);
  const [showSubPanel, setShowSubPanel] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [showPipPrompt, setShowPipPrompt] = useState(false);
  const [subtitlesEnabled, setSubtitlesEnabled] = useState(true);
  const [useEqForVideo, setUseEqForVideo] = useState(false);
  const [codecError, setCodecError] = useState<string | null>(null);
  const [speedHudText, setSpeedHudText] = useState<string | null>(null);

  // Barras laterales: IZQUIERDA Brillo (15%–100%), DERECHA Volumen (0%–100%)
  const [showLeftBrightness, setShowLeftBrightness] = useState(false);
  const [showRightVolume, setShowRightVolume] = useState(false);

  // Estado para PiP flotante arrastrable
  const [pipControlsVisible, setPipControlsVisible] = useState(true);
  const [pipPos, setPipPos] = useState<{ x: number; y: number }>(() => {
    if (typeof window === 'undefined') return { x: 16, y: 120 };
    const w = window.innerWidth < 640 ? 236 : 284;
    const h = Math.round((w * 9) / 16);
    return {
      x: Math.max(12, window.innerWidth - w - 14),
      y: Math.max(16, window.innerHeight - h - 92),
    };
  });
  const pipDragRef = useRef<{
    active: boolean;
    startX: number;
    startY: number;
    origX: number;
    origY: number;
    moved: boolean;
  }>({ active: false, startX: 0, startY: 0, origX: 0, origY: 0, moved: false });

  // Gesto vertical táctil/puntero en vista normal
  const gestureRef = useRef<{
    side: 'left' | 'right' | null;
    startY: number;
    startVal: number;
    moved: boolean;
  }>({ side: null, startY: 0, startVal: 1, moved: false });

  const canUseNativePlayer = isNativeAndroidMediaAvailable() && Boolean(video.localPath);

  // Detección interna silenciosa de resolución (144p, 260p, 360p, 480p, 720p, 1080p, 1.5K, 2K, 4K)
  const internalResolution = useMemo(
    () =>
      formatResolutionLabel(
        decodedDims?.width || video.width,
        decodedDims?.height || video.height
      ),
    [decodedDims, video.width, video.height]
  );

  // Ajuste interno silencioso de orientación inicial / ajuste visual sin alterar nitidez ni mostrar avisos
  useEffect(() => {
    if (!decodedDims || isPipMode) return;
    // Mantiene ajuste limpio sin deformar según relación de aspecto real del video
    if (decodedDims.width > 0 && decodedDims.height > 0 && aspectMode !== 'ajustar') {
      return;
    }
  }, [decodedDims, internalResolution, isPipMode, aspectMode]);

  const cues = useMemo(
    () => (video.subtitleRaw ? parseSubtitleContent(video.subtitleRaw) : []),
    [video.subtitleRaw]
  );

  const activeCues = useMemo(
    () =>
      subtitlesEnabled && cues.length > 0 && !isPipMode
        ? getActiveSubtitles(cues, currentTime, subtitleStyle.syncOffsetSec)
        : [],
    [cues, currentTime, subtitleStyle.syncOffsetSec, subtitlesEnabled, isPipMode]
  );

  const revealLeftBrightness = useCallback(() => {
    setShowLeftBrightness(true);
    if (leftTimerRef.current) window.clearTimeout(leftTimerRef.current);
    leftTimerRef.current = window.setTimeout(() => {
      setShowLeftBrightness(false);
    }, 2200);
  }, []);

  const revealRightVolume = useCallback(() => {
    setShowRightVolume(true);
    if (rightTimerRef.current) window.clearTimeout(rightTimerRef.current);
    rightTimerRef.current = window.setTimeout(() => {
      setShowRightVolume(false);
    }, 2200);
  }, []);

  const showTempHud = useCallback((label: string) => {
    setSpeedHudText(label);
    if (speedBadgeTimerRef.current) window.clearTimeout(speedBadgeTimerRef.current);
    speedBadgeTimerRef.current = window.setTimeout(() => {
      setSpeedHudText(null);
    }, 1400);
  }, []);

  const scheduleHideControls = useCallback(() => {
    if (hideTimerRef.current) window.clearTimeout(hideTimerRef.current);
    setShowControls(true);
    if (isPlaying && !showSubPanel && !showMoreMenu && !showPipPrompt) {
      hideTimerRef.current = window.setTimeout(() => {
        setShowControls(false);
      }, 3000);
    }
  }, [isPlaying, showSubPanel, showMoreMenu, showPipPrompt]);

  useEffect(() => {
    scheduleHideControls();
    return () => {
      if (hideTimerRef.current) window.clearTimeout(hideTimerRef.current);
      if (leftTimerRef.current) window.clearTimeout(leftTimerRef.current);
      if (rightTimerRef.current) window.clearTimeout(rightTimerRef.current);
      if (speedBadgeTimerRef.current) window.clearTimeout(speedBadgeTimerRef.current);
    };
  }, [scheduleHideControls]);

  // Restaurar orientación normal del dispositivo al cerrar o entrar en PiP
  useEffect(() => {
    if (isPipMode) {
      void setNativeOrientation('unspecified');
      setIsLandscape(false);
    }
  }, [isPipMode]);

  useEffect(() => {
    return () => {
      void setNativeOrientation('unspecified');
      audioEngine.suspendIdle();
    };
  }, []);

  // Audio directo por defecto para cero latencia/calor; EQ solo bajo demanda
  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;
    if (useEqForVideo) {
      audioEngine.connectMediaElement(el);
      audioEngine.resume();
    } else if (audioEngine.hasConnectedElement(el)) {
      audioEngine.suspendIdle();
    }
  }, [useEqForVideo, videoUrl]);

  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;
    const clampedVol = Math.max(0, Math.min(1, volume));
    el.volume = clampedVol;
    el.muted = clampedVol === 0;
  }, [volume, videoUrl]);

  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;
    el.playbackRate = playbackRate;
  }, [playbackRate, videoUrl]);

  useEffect(() => {
    const el = videoRef.current;
    if (!el || !videoUrl) return;

    let cancelled = false;
    setIsBuffering(true);
    setCodecError(null);

    const tryStart = () => {
      if (cancelled) return;
      el.volume = Math.max(0, Math.min(1, volume));
      el.muted = volume === 0;
      el.playbackRate = playbackRate;
      el.play()
        .then(() => {
          if (!cancelled) {
            setIsPlaying(true);
            setIsBuffering(false);
          }
        })
        .catch(() => {
          if (cancelled) return;
          const retryOnCanPlay = () => {
            if (cancelled) return;
            el.play()
              .then(() => {
                if (!cancelled) {
                  setIsPlaying(true);
                  setIsBuffering(false);
                }
              })
              .catch(() => {
                if (!cancelled) {
                  setIsPlaying(false);
                  setIsBuffering(false);
                }
              });
          };
          el.addEventListener('canplay', retryOnCanPlay, { once: true });
        });
    };

    tryStart();

    return () => {
      cancelled = true;
      el.pause();
      el.removeAttribute('src');
      el.load();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [videoUrl]);

  // Ahorro térmico y de batería: suspender AudioContext si se pausa o se oculta la app
  useEffect(() => {
    if (!isPlaying && batterySaverEnabled) {
      audioEngine.suspendIdle();
    }
  }, [isPlaying, batterySaverEnabled]);

  const toggleOrientation = useCallback(() => {
    setIsLandscape((prev) => {
      const next = !prev;
      void setNativeOrientation(next ? 'landscape' : 'portrait');
      return next;
    });
  }, []);

  const handleOpenNativePlayer = useCallback(async () => {
    if (!video.localPath) return;
    const el = videoRef.current;
    if (el && !el.paused) {
      el.pause();
      setIsPlaying(false);
    }
    await openNativeAndroidVideo(video.localPath, video.title);
  }, [video.localPath, video.title]);

  const togglePlay = useCallback(() => {
    const el = videoRef.current;
    if (!el || !videoUrl) return;
    if (useEqForVideo) audioEngine.resume();
    if (el.paused) {
      el.play().then(() => setIsPlaying(true)).catch(() => {});
    } else {
      el.pause();
      setIsPlaying(false);
      if (batterySaverEnabled) audioEngine.suspendIdle();
    }
  }, [useEqForVideo, videoUrl, batterySaverEnabled]);

  const skipBy = useCallback((deltaSec: number) => {
    const el = videoRef.current;
    if (!el) return;
    el.currentTime = Math.max(0, Math.min(el.duration || 0, el.currentTime + deltaSec));
    setCurrentTime(el.currentTime);
  }, []);

  const handleRequestPip = useCallback(() => {
    setShowMoreMenu(false);
    setShowSubPanel(false);
    if (videoPipEnabled) {
      onSetPipMode(true);
      setPipControlsVisible(true);
      return;
    }
    setShowPipPrompt(true);
  }, [videoPipEnabled, onSetPipMode]);

  const applyBrightness = useCallback(
    (nextBrightness: number) => {
      const clamped = Math.max(0.15, Math.min(1, nextBrightness));
      setBrightness(clamped);
      revealLeftBrightness();
    },
    [revealLeftBrightness]
  );

  const applyVolume = useCallback(
    (nextVolume: number) => {
      const clamped = Math.max(0, Math.min(1, nextVolume));
      if (clamped > 0.01) {
        lastNonZeroVolumeRef.current = clamped;
      }
      setVolume(clamped);
      revealRightVolume();
    },
    [revealRightVolume]
  );

  const toggleMute = useCallback(() => {
    if (volume > 0) {
      lastNonZeroVolumeRef.current = volume;
      applyVolume(0);
    } else {
      applyVolume(lastNonZeroVolumeRef.current > 0.05 ? lastNonZeroVolumeRef.current : 0.75);
    }
  }, [volume, applyVolume]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (isLocked || isPipMode) return;
      if (e.key === ' ' || e.key === 'k') {
        e.preventDefault();
        togglePlay();
      } else if (e.key === 'ArrowRight') {
        skipBy(10);
      } else if (e.key === 'ArrowLeft') {
        skipBy(-10);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        applyVolume(volume + 0.05);
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        applyVolume(volume - 0.05);
      } else if (e.key === 'm' || e.key === 'M') {
        toggleMute();
      } else if (e.key === 'Escape') {
        if (showMoreMenu || showSubPanel || showPipPrompt) {
          setShowMoreMenu(false);
          setShowSubPanel(false);
          setShowPipPrompt(false);
        } else {
          onClose();
        }
      }
    };
    const onBack = (e: Event) => {
      if (isPipMode) return;
      e.preventDefault();
      if (isLocked) {
        return;
      }
      if (showMoreMenu || showSubPanel || showPipPrompt) {
        setShowMoreMenu(false);
        setShowSubPanel(false);
        setShowPipPrompt(false);
        return;
      }
      onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('huyin-back-press', onBack);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('huyin-back-press', onBack);
    };
  }, [
    isLocked,
    isPipMode,
    togglePlay,
    skipBy,
    applyVolume,
    volume,
    toggleMute,
    showMoreMenu,
    showSubPanel,
    showPipPrompt,
    onClose,
  ]);

  const handleSubtitleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const raw = await readSubtitleFile(file);
    onAttachSubtitles(video.id, file.name, raw);
    setSubtitlesEnabled(true);
    e.target.value = '';
  };

  const cycleSpeed = () => {
    const speeds = [0.5, 0.75, 1, 1.25, 1.5, 2];
    const idx = speeds.indexOf(playbackRate);
    const next = speeds[(idx + 1) % speeds.length];
    setPlaybackRate(next);
    if (videoRef.current) videoRef.current.playbackRate = next;
    showTempHud(`Velocidad ${next}x`);
  };

  const cycleAspect = () => {
    const modes: AspectMode[] = ['ajustar', 'rellenar', '16:9', '4:3'];
    const labels: Record<AspectMode, string> = {
      ajustar: 'Ajuste original',
      rellenar: 'Ajustar al marco',
      '16:9': 'Relación 16:9',
      '4:3': 'Relación 4:3',
    };
    const next = modes[(modes.indexOf(aspectMode) + 1) % modes.length];
    setAspectMode(next);
    showTempHud(labels[next]);
  };

  // Gestos táctiles vista normal
  const handleSurfacePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isPipMode) {
      pipDragRef.current = {
        active: true,
        startX: e.clientX,
        startY: e.clientY,
        origX: pipPos.x,
        origY: pipPos.y,
        moved: false,
      };
      return;
    }

    if (isLocked) return;
    if (e.pointerType === 'mouse' && e.button !== 0) return;

    if (showMoreMenu || showPipPrompt) {
      setShowMoreMenu(false);
      setShowPipPrompt(false);
    }

    const rect = e.currentTarget.getBoundingClientRect();
    const isLeft = e.clientX - rect.left < rect.width / 2;
    const side: 'left' | 'right' = isLeft ? 'left' : 'right';

    gestureRef.current = {
      side,
      startY: e.clientY,
      startVal: side === 'left' ? brightness : volume,
      moved: false,
    };
  };

  const handleSurfacePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isPipMode) {
      const drag = pipDragRef.current;
      if (!drag.active) return;
      const dx = e.clientX - drag.startX;
      const dy = e.clientY - drag.startY;
      if (Math.abs(dx) > 5 || Math.abs(dy) > 5) {
        drag.moved = true;
        const cardW = window.innerWidth < 640 ? 236 : 284;
        const cardH = Math.round((cardW * 9) / 16);
        const maxX = Math.max(8, window.innerWidth - cardW - 8);
        const maxY = Math.max(8, window.innerHeight - cardH - 8);
        setPipPos({
          x: Math.max(8, Math.min(maxX, drag.origX + dx)),
          y: Math.max(8, Math.min(maxY, drag.origY + dy)),
        });
      }
      return;
    }

    if (isLocked) return;
    const g = gestureRef.current;
    if (!g.side) return;

    const deltaY = g.startY - e.clientY;
    if (Math.abs(deltaY) > 10) {
      g.moved = true;
      const sensitivity = Math.max(180, window.innerHeight * 0.42);
      if (g.side === 'left') {
        applyBrightness(g.startVal + (deltaY / sensitivity) * 0.85);
      } else {
        applyVolume(g.startVal + (deltaY / sensitivity) * 1.0);
      }
    }
  };

  const handleSurfacePointerUp = () => {
    if (isPipMode) {
      const wasTap = !pipDragRef.current.moved;
      pipDragRef.current.active = false;
      if (wasTap) {
        setPipControlsVisible((v) => !v);
      }
      return;
    }

    const g = gestureRef.current;
    const wasTap = !g.moved;
    gestureRef.current = { side: null, startY: 0, startVal: 1, moved: false };
    if (wasTap && !isLocked) {
      if (showSubPanel) {
        setShowSubPanel(false);
        return;
      }
      if (showControls) {
        setShowControls(false);
      } else {
        scheduleHideControls();
      }
    }
  };

  const videoObjectClass = isPipMode
    ? 'w-full h-full object-cover'
    : aspectMode === 'rellenar'
      ? 'w-full h-full object-cover'
      : aspectMode === '16:9'
        ? 'w-full aspect-video object-contain max-h-full'
        : aspectMode === '4:3'
          ? 'h-full aspect-[4/3] object-contain max-w-full'
          : 'w-full h-full object-contain';

  const subFontSizeClass =
    subtitleStyle.fontSize === 'pequeno'
      ? 'text-sm sm:text-base'
      : subtitleStyle.fontSize === 'grande'
        ? 'text-xl sm:text-2xl'
        : subtitleStyle.fontSize === 'extragrande'
          ? 'text-2xl sm:text-3xl'
          : 'text-base sm:text-xl';

  const subColorStyle =
    subtitleStyle.color === 'amarillo'
      ? '#fde047'
      : subtitleStyle.color === 'cian'
        ? '#67e8f9'
        : '#ffffff';

  const subBgStyle =
    subtitleStyle.background === 'caja'
      ? 'bg-black/80 px-3.5 py-1.5 rounded-lg'
      : subtitleStyle.background === 'sombra'
        ? 'px-2 py-1 drop-shadow-[0_2px_6px_rgba(0,0,0,0.95)]'
        : 'px-2 py-1';

  const subPositionClass =
    subtitleStyle.position === 'superior'
      ? 'top-16'
      : subtitleStyle.position === 'media'
        ? 'top-1/2 -translate-y-1/2'
        : 'bottom-24';

  const brightnessPercent = Math.min(100, Math.round(brightness * 100));
  const brightnessFillPercent = Math.max(0, Math.min(100, ((brightness - 0.15) / 0.85) * 100));
  const volumePercent = Math.min(100, Math.round(volume * 100));
  const VolumeIcon = volume === 0 ? VolumeX : volume < 0.5 ? Volume1 : Volume2;
  const showPipAction = videoPipEnabled || !videoPipPrompted;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.18 }}
      onPointerDown={handleSurfacePointerDown}
      onPointerMove={handleSurfacePointerMove}
      onPointerUp={handleSurfacePointerUp}
      onPointerCancel={() => {
        gestureRef.current.side = null;
        pipDragRef.current.active = false;
      }}
      style={
        isPipMode
          ? {
              left: `${pipPos.x}px`,
              top: `${pipPos.y}px`,
            }
          : undefined
      }
      className={
        isPipMode
          ? 'fixed z-50 w-[236px] sm:w-[284px] aspect-video rounded-2xl bg-black text-white shadow-2xl border border-white/20 overflow-hidden select-none touch-none'
          : 'fixed inset-0 z-50 flex items-center justify-center bg-black text-white select-none touch-none'
      }
      role="dialog"
      aria-modal={!isPipMode}
      aria-label={`Reproductor de video: ${video.title}`}
    >
      {/* Elemento de video único: permanece montado al cambiar entre vista normal y PiP */}
      {videoUrl && (
        <video
          ref={videoRef}
          src={videoUrl}
          playsInline
          preload={batterySaverEnabled ? 'metadata' : 'auto'}
          onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
          onLoadedMetadata={(e) => {
            const el = e.currentTarget;
            el.volume = Math.max(0, Math.min(1, volume));
            el.muted = volume === 0;
            el.playbackRate = playbackRate;
            setDuration(el.duration || video.duration || 0);
            if (el.videoWidth && el.videoHeight) {
              setDecodedDims({ width: el.videoWidth, height: el.videoHeight });
            }
            setCodecError(null);
          }}
          onResize={(e) => {
            const el = e.currentTarget;
            if (el.videoWidth && el.videoHeight) {
              setDecodedDims({ width: el.videoWidth, height: el.videoHeight });
            }
          }}
          onLoadedData={() => setIsBuffering(false)}
          onCanPlay={() => setIsBuffering(false)}
          onWaiting={() => setIsBuffering(true)}
          onPlaying={() => {
            setIsBuffering(false);
            setIsPlaying(true);
          }}
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
          onEnded={() => setIsPlaying(false)}
          onError={() => {
            setIsBuffering(false);
            setCodecError(
              'Este archivo no es compatible con el visor integrado. Puedes intentar abrirlo con el reproductor del sistema.'
            );
          }}
          className={videoObjectClass}
        />
      )}

      {/* Indicador breve mientras carga */}
      {(!videoUrl || isBuffering) && !codecError && (
        <div className="pointer-events-none absolute inset-0 z-10 flex flex-col items-center justify-center gap-2 bg-black/40">
          <Loader2 className="h-7 w-7 animate-spin text-white" aria-hidden="true" />
          {!isPipMode && <span className="text-xs font-medium text-white/80">Cargando video...</span>}
        </div>
      )}

      {/* Capa ligera de atenuación de brillo (sin blur, 15% a 100%) */}
      {!isPipMode && brightness < 0.99 && (
        <div
          className="pointer-events-none absolute inset-0 bg-black"
          style={{ opacity: Math.min(0.85, 1 - brightness) }}
        />
      )}

      {/* ==================== CONTROLES DE VENTANA FLOTANTE PiP ==================== */}
      {isPipMode && pipControlsVisible && (
        <div className="absolute inset-0 z-30 flex flex-col justify-between bg-black/35 p-2.5">
          <div
            onPointerDown={(e) => e.stopPropagation()}
            className="flex items-center justify-between"
          >
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onSetPipMode(false);
                setShowMoreMenu(true);
              }}
              aria-label="Opciones del video"
              className="flex h-8 w-8 items-center justify-center rounded-full bg-black/45 text-white hover:bg-black/70 cursor-pointer"
            >
              <Settings className="h-4 w-4" aria-hidden="true" />
            </button>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onClose();
              }}
              aria-label="Cerrar ventana flotante"
              className="flex h-8 w-8 items-center justify-center rounded-full bg-black/45 text-white hover:bg-black/70 cursor-pointer"
            >
              <X className="h-4 w-4" aria-hidden="true" />
            </button>
          </div>

          <div
            onPointerDown={(e) => e.stopPropagation()}
            className="flex items-center justify-center"
          >
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onSetPipMode(false);
              }}
              aria-label="Expandir reproductor"
              className="flex h-9 w-9 items-center justify-center rounded-full bg-black/45 text-white hover:bg-black/70 cursor-pointer"
            >
              <Maximize2 className="h-5 w-5" aria-hidden="true" />
            </button>
          </div>

          <div
            onPointerDown={(e) => e.stopPropagation()}
            className="flex items-center justify-center gap-6"
          >
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                skipBy(-10);
              }}
              aria-label="Retroceder 10 segundos"
              className="flex h-8 w-8 items-center justify-center text-white hover:opacity-80 cursor-pointer"
            >
              <SkipBack className="h-5 w-5 fill-current" aria-hidden="true" />
            </button>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                togglePlay();
              }}
              aria-label={isPlaying ? 'Pausar' : 'Reproducir'}
              className="flex h-9 w-9 items-center justify-center text-white hover:opacity-80 cursor-pointer"
            >
              {isPlaying ? (
                <Pause className="h-6 w-6 fill-current" aria-hidden="true" />
              ) : (
                <Play className="h-6 w-6 fill-current ml-0.5" aria-hidden="true" />
              )}
            </button>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                skipBy(10);
              }}
              aria-label="Adelantar 10 segundos"
              className="flex h-8 w-8 items-center justify-center text-white hover:opacity-80 cursor-pointer"
            >
              <SkipForward className="h-5 w-5 fill-current" aria-hidden="true" />
            </button>
          </div>
        </div>
      )}

      {/* ==================== MODO NORMAL ==================== */}
      {!isPipMode && (
        <>
          {/* Barra lateral IZQUIERDA de Brillo (15% - 100%, píldora oscura limpia sin blur) */}
          <AnimatePresence>
            {showLeftBrightness && !isLocked && (
              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.14 }}
                onPointerDown={(e) => e.stopPropagation()}
                onPointerMove={(e) => e.stopPropagation()}
                onPointerUp={(e) => e.stopPropagation()}
                onClick={(e) => e.stopPropagation()}
                className="absolute left-3 sm:left-5 top-1/2 -translate-y-1/2 z-30 flex flex-col items-center gap-2.5 rounded-full bg-black/75 border border-white/10 px-2.5 py-4"
              >
                <div className="relative flex h-36 w-5 items-center justify-center">
                  <div className="relative h-full w-2 overflow-hidden rounded-full bg-white/25">
                    <div
                      className="absolute bottom-0 inset-x-0 rounded-full bg-white"
                      style={{ height: `${brightnessFillPercent}%` }}
                    />
                  </div>
                  <input
                    type="range"
                    min={0.15}
                    max={1}
                    step={0.02}
                    value={brightness}
                    onChange={(e) => applyBrightness(Number(e.target.value))}
                    aria-label="Brillo de video"
                    className="eq-slider absolute inset-0 h-36 w-8 opacity-0 cursor-pointer"
                  />
                </div>
                <Sun className="h-5 w-5 text-white" aria-hidden="true" />
                <span className="font-mono-tabular text-[11px] font-medium text-white/90">
                  {brightnessPercent}%
                </span>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Barra lateral DERECHA de Volumen (0% - 100%, píldora oscura limpia sin blur) */}
          <AnimatePresence>
            {showRightVolume && !isLocked && (
              <motion.div
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.14 }}
                onPointerDown={(e) => e.stopPropagation()}
                onPointerMove={(e) => e.stopPropagation()}
                onPointerUp={(e) => e.stopPropagation()}
                onClick={(e) => e.stopPropagation()}
                className="absolute right-3 sm:right-5 top-1/2 -translate-y-1/2 z-30 flex flex-col items-center gap-2.5 rounded-full bg-black/75 border border-white/10 px-2.5 py-4"
              >
                <div className="relative flex h-36 w-5 items-center justify-center">
                  <div className="relative h-full w-2 overflow-hidden rounded-full bg-white/25">
                    <div
                      className="absolute bottom-0 inset-x-0 rounded-full bg-white"
                      style={{ height: `${volumePercent}%` }}
                    />
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.02}
                    value={volume}
                    onChange={(e) => applyVolume(Number(e.target.value))}
                    aria-label="Volumen del video"
                    className="eq-slider absolute inset-0 h-36 w-8 opacity-0 cursor-pointer"
                  />
                </div>
                <button
                  type="button"
                  onClick={toggleMute}
                  aria-label={volume === 0 ? 'Activar sonido' : 'Silenciar video'}
                  className="flex h-6 w-6 items-center justify-center text-white cursor-pointer"
                >
                  <VolumeIcon className="h-5 w-5" aria-hidden="true" />
                </button>
                <span className="font-mono-tabular text-[11px] font-medium text-white/90">
                  {volumePercent}%
                </span>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Aviso breve de velocidad o aspecto */}
          {speedHudText && (
            <div className="pointer-events-none absolute top-16 left-1/2 -translate-x-1/2 z-30 rounded-full bg-black/80 border border-white/15 px-3.5 py-1 text-xs font-medium text-white">
              {speedHudText}
            </div>
          )}

          {/* Mensaje si el formato/códec no es soportado */}
          {codecError && (
            <div
              onPointerDown={(e) => e.stopPropagation()}
              className="absolute inset-x-6 max-w-md mx-auto rounded-2xl border border-white/15 bg-neutral-900 p-6 text-center shadow-2xl z-40"
            >
              <p className="font-display text-base font-semibold text-white">
                Formato incompatible con el visor integrado
              </p>
              <p className="mt-2 text-sm text-white/75">{codecError}</p>
              <div className="mt-4 flex flex-wrap items-center justify-center gap-2.5">
                {canUseNativePlayer && (
                  <button
                    type="button"
                    onClick={() => void handleOpenNativePlayer()}
                    className="rounded-xl bg-amber-500 px-5 py-2.5 text-sm font-semibold text-neutral-950 cursor-pointer"
                  >
                    Abrir con reproductor del sistema
                  </button>
                )}
                <button
                  type="button"
                  onClick={onClose}
                  className="rounded-xl border border-white/20 bg-white/10 px-5 py-2.5 text-sm font-semibold text-white cursor-pointer"
                >
                  Volver a Mis videos
                </button>
              </div>
            </div>
          )}

          {/* Diálogo de activación única para PiP (Imagen sobre imagen) */}
          {showPipPrompt && (
            <div
              onPointerDown={(e) => e.stopPropagation()}
              onClick={(e) => e.stopPropagation()}
              className="absolute inset-0 z-40 flex items-center justify-center bg-black/70 p-5"
            >
              <div className="w-full max-w-sm rounded-2xl border border-white/15 bg-neutral-900 p-5 text-white shadow-2xl">
                <div className="flex items-center gap-2.5">
                  <PictureInPicture2 className="h-5 w-5 text-amber-400" aria-hidden="true" />
                  <h3 className="font-display text-base font-bold">
                    Reproducción en ventana flotante (PiP)
                  </h3>
                </div>
                <p className="mt-2 text-xs leading-relaxed text-white/75">
                  ¿Quieres activar Imagen sobre imagen (PiP) para minimizar videos en una ventana flotante? Siempre podrás cambiarlo después en Ajustes.
                </p>
                <div className="mt-4 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      onUpdatePipPreference(false, true);
                      setShowPipPrompt(false);
                    }}
                    className="rounded-xl border border-white/15 px-3.5 py-2 text-xs font-medium text-white/80 hover:bg-white/10 cursor-pointer"
                  >
                    No activar
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onUpdatePipPreference(true, true);
                      setShowPipPrompt(false);
                      onSetPipMode(true);
                      setPipControlsVisible(true);
                    }}
                    className="rounded-xl bg-amber-500 px-4 py-2 text-xs font-semibold text-neutral-950 cursor-pointer"
                  >
                    Activar PiP
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Capa de subtítulos */}
          {activeCues.length > 0 && (
            <div
              className={`pointer-events-none absolute inset-x-4 z-20 flex flex-col items-center text-center ${subPositionClass}`}
            >
              {activeCues.map((cue) => (
                <p
                  key={cue.id}
                  className={`max-w-3xl whitespace-pre-line font-semibold leading-snug ${subFontSizeClass} ${subBgStyle}`}
                  style={{
                    color: subColorStyle,
                    textShadow:
                      subtitleStyle.background === 'sombra'
                        ? '0 2px 4px rgba(0,0,0,0.95), 0 0 10px rgba(0,0,0,0.85)'
                        : undefined,
                  }}
                >
                  {cue.text}
                </p>
              ))}
            </div>
          )}

          {/* Botón desbloquear si la pantalla está bloqueada */}
          {isLocked && (
            <button
              type="button"
              onPointerDown={(e) => e.stopPropagation()}
              onClick={(e) => {
                e.stopPropagation();
                setIsLocked(false);
                scheduleHideControls();
              }}
              className="absolute left-5 top-[max(1rem,env(safe-area-inset-top))] z-30 flex min-h-[42px] items-center gap-2 rounded-full border border-white/20 bg-black/80 px-4 py-2 text-xs font-semibold text-white cursor-pointer"
            >
              <Unlock className="h-4 w-4 text-amber-400" aria-hidden="true" />
              <span>Desbloquear</span>
            </button>
          )}

          {/* Barra superior limpia (∨ + título + subtítulos + ⋮) */}
          <AnimatePresence>
            {showControls && !isLocked && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.14 }}
                onPointerDown={(e) => e.stopPropagation()}
                onClick={(e) => e.stopPropagation()}
                className="absolute top-0 inset-x-0 z-30 flex items-center justify-between gap-2 bg-gradient-to-b from-black/80 via-black/40 to-transparent px-3 sm:px-5 pt-[max(0.75rem,env(safe-area-inset-top))] pb-4"
              >
                <div className="flex min-w-0 flex-1 items-center gap-2">
                  <button
                    type="button"
                    onClick={onClose}
                    aria-label="Cerrar video"
                    className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-white hover:bg-white/10 transition-colors cursor-pointer"
                  >
                    <ChevronDown className="h-6 w-6" aria-hidden="true" />
                  </button>
                  <h2 className="truncate text-sm sm:text-base font-medium text-white">
                    {video.title}
                  </h2>
                </div>

                <div className="relative flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      setShowSubPanel((v) => !v);
                      setShowMoreMenu(false);
                    }}
                    aria-label="Subtítulos"
                    className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/10 transition-colors cursor-pointer"
                    style={{ color: showSubPanel || cues.length > 0 ? '#f59e0b' : '#ffffff' }}
                  >
                    <Captions className="h-5 w-5" aria-hidden="true" />
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setShowMoreMenu((v) => !v);
                      setShowSubPanel(false);
                    }}
                    aria-label="Más opciones"
                    className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/10 transition-colors cursor-pointer"
                  >
                    <MoreVertical className="h-5 w-5" aria-hidden="true" />
                  </button>

                  {showMoreMenu && (
                    <div className="absolute right-0 top-12 z-40 w-60 rounded-2xl border border-white/15 bg-neutral-900 p-1.5 shadow-2xl">
                      <button
                        type="button"
                        onClick={() => {
                          setShowMoreMenu(false);
                          setShowSubPanel(true);
                        }}
                        className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-left text-xs font-medium text-white hover:bg-white/10 cursor-pointer"
                      >
                        <Captions className="h-4 w-4 text-white/80" aria-hidden="true" />
                        <span>Subtítulos y sincronización</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setUseEqForVideo((v) => !v);
                          setShowMoreMenu(false);
                        }}
                        className="flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left text-xs font-medium text-white hover:bg-white/10 cursor-pointer"
                      >
                        <span className="flex items-center gap-2.5">
                          <Headphones className="h-4 w-4 text-white/80" aria-hidden="true" />
                          <span>Ecualizador en video</span>
                        </span>
                        <span className="text-[11px] font-semibold text-amber-400">
                          {useEqForVideo ? 'Activo' : 'Directo'}
                        </span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setShowMoreMenu(false);
                          onClose();
                          onOpenAudioSettings();
                        }}
                        className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-left text-xs font-medium text-white hover:bg-white/10 cursor-pointer"
                      >
                        <SlidersHorizontal className="h-4 w-4 text-white/80" aria-hidden="true" />
                        <span>Ajustes de audio y PiP</span>
                      </button>

                      {canUseNativePlayer && (
                        <button
                          type="button"
                          onClick={() => {
                            setShowMoreMenu(false);
                            void handleOpenNativePlayer();
                          }}
                          className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-left text-xs font-medium text-white hover:bg-white/10 cursor-pointer"
                        >
                          <CirclePlay className="h-4 w-4 text-white/80" aria-hidden="true" />
                          <span>Abrir con visor del sistema</span>
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Controles centrales limpios (↺10, || / ▶, ↻10 en blanco limpio) */}
          <AnimatePresence>
            {showControls && !isLocked && !codecError && !showSubPanel && !showPipPrompt && (
              <motion.div
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.96 }}
                transition={{ duration: 0.14 }}
                onPointerDown={(e) => e.stopPropagation()}
                onClick={(e) => e.stopPropagation()}
                className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center gap-10 sm:gap-16"
              >
                <button
                  type="button"
                  onClick={() => {
                    skipBy(-10);
                    scheduleHideControls();
                  }}
                  aria-label="Retroceder 10 segundos"
                  className="pointer-events-auto relative flex h-12 w-12 items-center justify-center rounded-full text-white hover:bg-white/10 active:scale-95 transition-transform cursor-pointer"
                >
                  <RotateCcw className="h-8 w-8 stroke-[1.75]" aria-hidden="true" />
                  <span className="absolute mt-1 text-[10px] font-bold leading-none">10</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    togglePlay();
                    scheduleHideControls();
                  }}
                  aria-label={isPlaying ? 'Pausar' : 'Reproducir'}
                  className="pointer-events-auto flex h-16 w-16 items-center justify-center rounded-full text-white hover:bg-white/10 active:scale-95 transition-transform cursor-pointer"
                >
                  {isPlaying ? (
                    <Pause className="h-11 w-11 fill-white" aria-hidden="true" />
                  ) : (
                    <Play className="h-11 w-11 fill-white ml-1" aria-hidden="true" />
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    skipBy(10);
                    scheduleHideControls();
                  }}
                  aria-label="Adelantar 10 segundos"
                  className="pointer-events-auto relative flex h-12 w-12 items-center justify-center rounded-full text-white hover:bg-white/10 active:scale-95 transition-transform cursor-pointer"
                >
                  <RotateCw className="h-8 w-8 stroke-[1.75]" aria-hidden="true" />
                  <span className="absolute mt-1 text-[10px] font-bold leading-none">10</span>
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Panel lateral de subtítulos (sin blur pesado para ahorro térmico) */}
          <AnimatePresence>
            {showSubPanel && !isLocked && (
              <motion.aside
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ duration: 0.16 }}
                onPointerDown={(e) => e.stopPropagation()}
                onPointerMove={(e) => e.stopPropagation()}
                onClick={(e) => e.stopPropagation()}
                className="touch-pan-y absolute right-3 top-16 bottom-24 z-40 w-80 max-w-[calc(100vw-1.5rem)] overflow-y-auto rounded-2xl border border-white/15 bg-neutral-900 p-5 shadow-2xl"
              >
                <div className="flex items-center justify-between pb-3 border-b border-white/10">
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4 text-amber-400" aria-hidden="true" />
                    <h3 className="font-display text-sm font-semibold">Subtítulos</h3>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowSubPanel(false)}
                    aria-label="Cerrar panel de subtítulos"
                    className="flex h-8 w-8 items-center justify-center rounded-lg hover:bg-white/10 cursor-pointer"
                  >
                    <X className="h-4 w-4" aria-hidden="true" />
                  </button>
                </div>

                <div className="mt-4 space-y-5 text-xs">
                  <div>
                    <input
                      ref={subInputRef}
                      type="file"
                      accept=".srt,.vtt,.ass,.ssa"
                      onChange={handleSubtitleFileChange}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => subInputRef.current?.click()}
                      className="flex w-full min-h-[42px] items-center justify-center gap-2 rounded-xl bg-amber-500 px-4 py-2.5 text-xs font-semibold text-neutral-950 cursor-pointer"
                    >
                      <Upload className="h-4 w-4" aria-hidden="true" />
                      <span>Cargar archivo (.SRT, .VTT, .ASS)</span>
                    </button>
                    {video.subtitleName && (
                      <p className="mt-2 truncate text-[11px] text-white/70">
                        Activo: {video.subtitleName} ({cues.length} líneas)
                      </p>
                    )}
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="font-medium text-white/90">Mostrar subtítulos</span>
                    <button
                      type="button"
                      onClick={() => setSubtitlesEnabled((v) => !v)}
                      className="rounded-lg px-3 py-1.5 font-semibold cursor-pointer"
                      style={{
                        backgroundColor: subtitlesEnabled ? '#f59e0b' : 'rgba(255,255,255,0.12)',
                        color: subtitlesEnabled ? '#0b0d12' : '#ffffff',
                      }}
                    >
                      {subtitlesEnabled ? 'Activados' : 'Ocultos'}
                    </button>
                  </div>

                  <div>
                    <p className="mb-2 font-medium text-white/80">Tamaño del texto</p>
                    <div className="grid grid-cols-4 gap-1 rounded-xl bg-white/5 p-1">
                      {(['pequeno', 'mediano', 'grande', 'extragrande'] as const).map((sz) => {
                        const labels = {
                          pequeno: 'Pequeño',
                          mediano: 'Medio',
                          grande: 'Grande',
                          extragrande: 'Extra',
                        };
                        return (
                          <button
                            key={sz}
                            type="button"
                            onClick={() => onUpdateSubtitleStyle({ ...subtitleStyle, fontSize: sz })}
                            className="rounded-lg py-1.5 font-medium cursor-pointer"
                            style={{
                              backgroundColor:
                                subtitleStyle.fontSize === sz
                                  ? 'rgba(255,255,255,0.16)'
                                  : 'transparent',
                              color:
                                subtitleStyle.fontSize === sz ? '#ffffff' : 'rgba(255,255,255,0.65)',
                            }}
                          >
                            {labels[sz]}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <p className="mb-2 font-medium text-white/80">Color</p>
                    <div className="grid grid-cols-3 gap-1.5">
                      {(['blanco', 'amarillo', 'cian'] as const).map((col) => {
                        const labels = { blanco: 'Blanco', amarillo: 'Amarillo', cian: 'Cian' };
                        return (
                          <button
                            key={col}
                            type="button"
                            onClick={() => onUpdateSubtitleStyle({ ...subtitleStyle, color: col })}
                            className="rounded-xl border py-2 font-medium cursor-pointer"
                            style={{
                              borderColor:
                                subtitleStyle.color === col ? '#f59e0b' : 'rgba(255,255,255,0.12)',
                              backgroundColor:
                                subtitleStyle.color === col
                                  ? 'rgba(245, 158, 11, 0.14)'
                                  : 'transparent',
                            }}
                          >
                            {labels[col]}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <p className="mb-2 font-medium text-white/80">Fondo</p>
                    <div className="grid grid-cols-3 gap-1.5">
                      {(['transparente', 'sombra', 'caja'] as const).map((bg) => {
                        const labels = {
                          transparente: 'Ninguno',
                          sombra: 'Sombra',
                          caja: 'Caja oscura',
                        };
                        return (
                          <button
                            key={bg}
                            type="button"
                            onClick={() =>
                              onUpdateSubtitleStyle({ ...subtitleStyle, background: bg })
                            }
                            className="rounded-xl border py-2 font-medium cursor-pointer"
                            style={{
                              borderColor:
                                subtitleStyle.background === bg
                                  ? '#f59e0b'
                                  : 'rgba(255,255,255,0.12)',
                              backgroundColor:
                                subtitleStyle.background === bg
                                  ? 'rgba(245, 158, 11, 0.14)'
                                  : 'transparent',
                            }}
                          >
                            {labels[bg]}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <p className="mb-2 font-medium text-white/80">Posición</p>
                    <div className="grid grid-cols-3 gap-1.5">
                      {(['inferior', 'media', 'superior'] as const).map((pos) => {
                        const labels = { inferior: 'Abajo', media: 'Centro', superior: 'Arriba' };
                        return (
                          <button
                            key={pos}
                            type="button"
                            onClick={() =>
                              onUpdateSubtitleStyle({ ...subtitleStyle, position: pos })
                            }
                            className="rounded-xl border py-2 font-medium cursor-pointer"
                            style={{
                              borderColor:
                                subtitleStyle.position === pos
                                  ? '#f59e0b'
                                  : 'rgba(255,255,255,0.12)',
                              backgroundColor:
                                subtitleStyle.position === pos
                                  ? 'rgba(245, 158, 11, 0.14)'
                                  : 'transparent',
                            }}
                          >
                            {labels[pos]}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <div className="mb-1.5 flex items-center justify-between">
                      <span className="font-medium text-white/80">Sincronización</span>
                      <span className="font-mono-tabular text-amber-400">
                        {subtitleStyle.syncOffsetSec > 0 ? '+' : ''}
                        {subtitleStyle.syncOffsetSec.toFixed(1)} s
                      </span>
                    </div>
                    <input
                      type="range"
                      min={-5}
                      max={5}
                      step={0.1}
                      value={subtitleStyle.syncOffsetSec}
                      onChange={(e) =>
                        onUpdateSubtitleStyle({
                          ...subtitleStyle,
                          syncOffsetSec: Number(e.target.value),
                        })
                      }
                      aria-label="Sincronización de subtítulos"
                      className="visha-range w-full"
                    />
                  </div>
                </div>
              </motion.aside>
            )}
          </AnimatePresence>

          {/* Barra inferior limpia (línea blanca + MM:SS + fila única de iconos blancos) */}
          <AnimatePresence>
            {showControls && !isLocked && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                transition={{ duration: 0.14 }}
                onPointerDown={(e) => e.stopPropagation()}
                onClick={(e) => e.stopPropagation()}
                className="absolute bottom-0 inset-x-0 z-30 bg-gradient-to-t from-black/90 via-black/60 to-transparent px-4 sm:px-6 pt-8 pb-[max(1rem,env(safe-area-inset-bottom))]"
              >
                {/* Progreso blanco limpio */}
                <div>
                  <input
                    type="range"
                    min={0}
                    max={Math.max(1, duration || 1)}
                    step={0.1}
                    value={Math.min(currentTime, Math.max(1, duration || 1))}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      if (videoRef.current) videoRef.current.currentTime = val;
                      setCurrentTime(val);
                      scheduleHideControls();
                    }}
                    aria-label="Línea de tiempo del video"
                    style={{ accentColor: '#ffffff' }}
                    className="w-full h-1.5 rounded-full cursor-pointer"
                  />
                  <div className="font-mono-tabular mt-1.5 flex items-center justify-between text-xs text-white/85">
                    <span>{formatDuration(currentTime)}</span>
                    <span>{formatDuration(duration)}</span>
                  </div>
                </div>

                {/* Fila inferior única de íconos limpios (sin pantalla completa) */}
                <div className="mt-3 flex items-center justify-between sm:justify-start sm:gap-6">
                  <button
                    type="button"
                    onClick={() => setIsLocked(true)}
                    aria-label="Bloquear pantalla"
                    title="Bloquear controles"
                    className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/10 cursor-pointer"
                  >
                    <Lock className="h-5 w-5 stroke-[1.75]" aria-hidden="true" />
                  </button>

                  <button
                    type="button"
                    onClick={revealRightVolume}
                    aria-label="Volumen"
                    title={`Volumen (${volumePercent}%)`}
                    className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/10 cursor-pointer"
                  >
                    <VolumeIcon className="h-5 w-5 stroke-[1.75]" aria-hidden="true" />
                  </button>

                  {showPipAction && (
                    <button
                      type="button"
                      onClick={handleRequestPip}
                      aria-label="Ventana flotante (Imagen sobre imagen)"
                      title="Imagen sobre imagen (PiP)"
                      className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/10 cursor-pointer"
                    >
                      <PictureInPicture2 className="h-5 w-5 stroke-[1.75]" aria-hidden="true" />
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={cycleAspect}
                    aria-label="Ajustar proporción de video"
                    title={`Proporción: ${aspectMode}`}
                    className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/10 cursor-pointer"
                  >
                    <Scan className="h-5 w-5 stroke-[1.75]" aria-hidden="true" />
                  </button>

                  <button
                    type="button"
                    onClick={cycleSpeed}
                    aria-label="Velocidad de reproducción"
                    title={`Velocidad: ${playbackRate}x`}
                    className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/10 cursor-pointer"
                  >
                    <CirclePlay
                      className={`h-5 w-5 stroke-[1.75] ${playbackRate !== 1 ? 'text-amber-400' : ''}`}
                      aria-hidden="true"
                    />
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setUseEqForVideo((v) => !v);
                      showTempHud(useEqForVideo ? 'Audio directo' : 'Ecualizador activo');
                    }}
                    aria-label="Ecualizador de auriculares"
                    title={useEqForVideo ? 'Ecualizador activo' : 'Audio directo'}
                    className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/10 cursor-pointer"
                  >
                    <Headphones
                      className={`h-5 w-5 stroke-[1.75] ${useEqForVideo ? 'text-amber-400' : ''}`}
                      aria-hidden="true"
                    />
                  </button>

                  <button
                    type="button"
                    onClick={toggleOrientation}
                    aria-label="Girar video horizontal o vertical"
                    title={isLandscape ? 'Cambiar a vertical' : 'Girar a horizontal'}
                    className="flex h-10 w-10 items-center justify-center rounded-full text-white hover:bg-white/10 cursor-pointer"
                  >
                    <Smartphone
                      className={`h-5 w-5 stroke-[1.75] transition-transform ${
                        isLandscape ? 'rotate-90 text-amber-400' : ''
                      }`}
                      aria-hidden="true"
                    />
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </>
      )}
    </motion.div>
  );
}
